use vcfw;
$F1 = 'C:\bb-save\Backup\BlackBerry\ringtones\ringtones.dat';
$F2 = "c:/home/wincingdevil/public_html/ringtones/index.html";
$F1='c:\wv\newsclinks.txt';
$F2='c:\wv\newsclinks.htm';
$F1 = 'c:\db\gsfc\articlinks.txt';
$F2 = 'c:\db\gsfc\articlinks.htm';
$F1 = 'c:\gem\rules\final\i.htm';
$F2 = 'c:\gem\rules\final\i2.htm';

$F1 = 'c:\db\gsfc\Human_Health_metadata.txt';
$F2 = 'c:\db\gsfc\Human_Health_metadata.htm';

open (IN,"<$F1") || die "choke on open $F1:$!\n";
open (OUT,">$F2") || die "choke on open $F1:$!\n";
open (BAT,">C:\\db\\gsfc\\snarfall.bat") || die "choke on open snarfall.bat :$!\n";

print OUT "<UL>\n";
#Datasets	Link	Keywords/Tags	Topics
while (<IN>) {
	chomp;
	$D = $_;
    ($Verb,$Link,$KeyWds,$Topics) = split (/\t/,$D);
	$Verb = trim($Verb);
	$Link = trim($Link);
	$KeyWds = trim($KeyWds);
	$Topics = trim($Topics);
	print BAT "perl c:\\db\\gsfc\\getmeta.pl $Link\n";
	print OUT<<EOM;
<li>
<a href=\"$Link\"><B>$Verb</B></a><br>
<b>Keywords: </b>$KeyWds
<br>
<b>Topics: </b>$Topics
<hr>
</li>
EOM
}
close IN;
print OUT "</ul>\n";
close OUT;
system "c:\\progra~2\\editpl~1\\editplus.exe $F2 $F1";
