while (<DATA>) {
	chomp;
	$In = $_;
print<<EOM;
perl -pi'.b1' -e 's/SELECT s.id FROM term AS s/SELECT s.identifier FROM term AS s/g' $In
perl -pi'.b2' -e 's/term_id, relationship, gcid/term_identifier, relationship_identifier, gcid/g' $In
EOM
}

__DATA__
VB-load-term-map-crt.sql
VB-load-term-map-gcis.sql
VB-load-term-map.sql
WI-load-term-map-crt.sql
WI-load-term-map-gcis.sql
WI-load-term-map.sql
