#!/usr/bin/env perl -w
# Reads CSV output of EXCEL spreadsheet, replaces newlines with spaces, formats into SQL statement
use vcfw;
#use strict;
use warnings;
use Text::CSV_XS;
use Text::Unidecode;

#require "C:\\db\\GSFC\\DoRegions.pm";
#$MyGlob = " xxxxx virginia kansas West Virginia zzzzz alaska";
#$Region =DoRegions($MyGlob);
#print "Return =[$Region]\n[$MyGlob]\n";

my $Path = "c:\\db\\gsfc\\";
#water_illness_4_26_draft.xlsx-DOI.csv
my $FileNameRoot = "water_illness_4_26_draft.xlsx-DOI";
my $InputFile  = $Path.$FileNameRoot.".csv";
my $OutputFile = $Path.$FileNameRoot.".sql";
#my $Edit = $ENV{'ED'};
my $Edit = "c:\\progra~2\\editpl~1\\editplus.exe";

open (my $CSV_FH, "<",$InputFile) or die "choke on open input $InputFile: $!";
open (OUT_FH, ">",$OutputFile) or die "choke on open output $OutputFile: $!";
#print OUT_FH "DOI2,Region\n";
#Title	Type	Publication URI	Reference URI	DOI	PMID	"word count (highest=1036)"	Abstract	Executive summary/book summary		Keywords	MeSH Terms	Regions	Notes
#Title,Type,PubURI,RefURI,DOI,PMID,WordCount,Abstract,execsumm,Blank1,Keywords,MeSH Terms,Regions,Notes,Blank2,

#$Title=$Type=$PubURI=$RefURI=$DOI=$PMID=$WordCount=$Abstract=$ExecSumm=$Blank1=$Keywords=$MeSHTerms=$Notes="";
my $csv = Text::CSV_XS->new ( { binary => 1 } )    #binary for mulitline fields
           or die "Cannot use Text::CSV " . Text::CSV->error_diag ();

$csv->column_names ($csv->getline($CSV_FH));    #define column names from first line
while (my $rowhash = $csv->getline_hr($CSV_FH)) { # Loop thru file
	$InCount++;
#	$My_DOI = $rowhash->{'DOI'};
	$My_Abs = $My_Exec = "";
	if ($rowhash->{'Abstract'} ne "") { $My_Abs  = $rowhash->{'Abstract'} };
	if ($rowhash->{'execsumm'} ne "") {$My_Exec = $rowhash->{'execsumm'} };
	$My_Glob = $My_Abs . " " . $My_Exec;
	$My_Glob = unidecode($My_Glob);	#convert UTF chars
	$My_Glob =~ s/'/''/g;		#Escape single quotes
	$My_Glob =~ s/"/''/g;		#Double Quotes to (escaped) single quotes
	$My_Glob =~ s/\n/ /g;		#Delete newlines
	$My_Glob =~ s/\x00//g;		#Delete nulls
	$My_Glob =~ s/\x0a//g;		#Delete LF
	$My_Glob =~ s/\x0d//g;		#Delete CR
#	$OutCount++;
#	$Region =DoRegions($My_Glob);
### Extract Identifier from Publication URI field
	$My_ID = lc($rowhash->{'PubURI'});
	$TableName = "";
	if ($My_ID ne "") {
		if ($My_ID =~ s/^\/article\///) {
			$TableName = "article";
		} elsif ($My_ID =~ s/^\/book\///) {
			$TableName = "book";
		} elsif ($My_ID =~ s/^\/chapter\///) {
			$TableName = "chapter";
		} elsif ($My_ID =~ s/^\/journal\///) {
			$TableName = "journal";
		}
	}
	if (($My_ID ne "") and ($TableName ne "") and ($My_Glob ne " ")) {
		print OUT_FH "UPDATE $TableName SET description = '$My_Glob' WHERE identifier = '$My_ID';\n";
	}
}

close $CSV_FH;
close OUT_FH;
system "$Edit $InputFile $OutputFile";
