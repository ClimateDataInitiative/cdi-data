#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\load-term-map.sql";
$Relationship = "Throw this away";
$Sql1="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
while (<DATA>) 	{
	chomp;
	($Term,$Relationship,$Dataset,$URI) = split(/\t/);
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term eq "") {
		$ThisTerm = $OldTerm
	} else {
		$ThisTerm = $OldTerm = $Term;
	}
	$Dataset = trim($Dataset);
	$Dataset =~ s/'/''/g;		#Escape single quotes
	if ($Dataset eq "") {
		$Dataset= "N/A";
	}

	$URI= trim($URI);
	if ($URI eq "") {
		$URI= "N/A";
	}
	$Relationship = trim($Relationship);

$Sql1 = "INSERT INTO term_map (term_id, relationship, gcid, description) VALUES ((SELECT s.id FROM term AS s WHERE s.term = ";
	$OutLine=<<EOM;
$Sql1'$ThisTerm' and s.lexicon_identifier = 'cdi'), 'isMentionedIn', '$URI', '$Dataset');
EOM

	print OUT "$OutLine";
}
close OUT;
system "$ENV{'ED'} $F1"
#Subject	Predicate	Relationship	Object
#Term	Relationship	Datasets	extURI		
__DATA__
Health			https://catalog.data.gov/dataset?vocab_category_all=Human+Health&groups=climate5434#topic=humanhealth_navigation		
Vector Borne Disease					
Response					
Planning					
New pathogen					
Global travel					
Global trade		Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states		
Urban growth		Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states		
Mitigation					
Water management practices					
Control Methods (pesticides)					
Vector surveillance					
Land use practices					
Notification		National Weather Service County Warning Area Boundaries	http://catalog.data.gov/dataset/national-weather-service-county-warning-area-boundaries		
Human Vulnerability		CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network		
		CDC WONDER: Cancer Statistics 	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics		
		CDC WONDER: Mortality - Infant Deaths	"https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths"		
		CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"		
		CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
		Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies		
		Gridded Population of the World- Version 2 (GPWv2)	http://catalog.data.gov/dataset/gridded-population-of-the-world-version-2-gpwv2-74527		
		HCUPnet	http://catalog.data.gov/dataset/hcupnet		
		Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi		
		Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts		
		Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states		
Health Risks		CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network		
		FluView National Flu Activity Map	https://catalog.data.gov/dataset/fluview-national-flu-activity-map		
Outdoor activity					
Outdoor employment					
Population at risk		CDC WONDER: Cancer Statistics 	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics		
		CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network		
		CDC WONDER: Compressed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	"https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths"		
		CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"		
		CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
		CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates		
		CMS Statistics	"https://catalog.data.gov/dataset/cms-statistics"		
		Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas		
		FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies		
		Mental Health Treatement Facilities Locator	http://catalog.data.gov/dataset/mental-health-treatement-facilities-locator		
		National Death Index	http://catalog.data.gov/dataset/national-death-index		
		National Flood Hazard Layer (NFHL)	http://catalog.data.gov/dataset/national-flood-hazard-layer-nfhl		
		Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts		
		Supplemental Nutrition Assistance Program (SNAP) Data System	http://catalog.data.gov/dataset/supplemental-nutrition-assistance-program-snap-data-system-a2b49		
Minorities		CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"		
		CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
		CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates		
		Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi		
		Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states		
Sex/Gender		CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"		
		CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
		Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi		
		Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states		
Elderly		CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"		
		CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
		Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi		
		Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states		
Children		CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	"https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths"		
		CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"		
		CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
		Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi		
		Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states		
Socio-economic risk factors		Food Environment Atlas	https://catalog.data.gov/dataset/food-environment-atlas-f4a22		
		Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi		
		NOAA Digital Coast Sea Level Rise and Coastal Flooding Impacts Viewer	https://catalog.data.gov/dataset/noaa-digital-coast-sea-level-rise-and-coastal-flooding-impacts-viewer		
		Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts		
		Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states		
		Supplemental Nutrition Assistance Program (SNAP) Data System	https://catalog.data.gov/dataset/supplemental-nutrition-assistance-program-snap-data-system-a2b49		
Housing		Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas		
		Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states		
Poverty		Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas		
		Food Access Research Atlas	https://catalog.data.gov/dataset/food-access-research-atlas		
		Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states		
		Supplemental Nutrition Assistance Program (SNAP) Data System	http://catalog.data.gov/dataset/supplemental-nutrition-assistance-program-snap-data-system-a2b49		
Education		CDC WONDER: Mortality - Infant Deaths	https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		National Death Index	https://catalog.data.gov/dataset/national-death-index		
		Statistical Abstract of the United States	https://catalog.data.gov/dataset/statistical-abstract-of-the-united-states		
Biological Variables					
Population size					
Population density					
Survival rates					
Host Abundance					
Pathogen Reproduction rate					
Zoonotic carriers					
Habitat availability					
Host Reproduction Rates					
Habitat Range					
Migration patterns					
Infrastructure		FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies		
		National Ambulatory Medical Care Survey (NAMCS)	https://catalog.data.gov/dataset/national-ambulatory-medical-care-survey-namcs		
		USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	https://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass		
Hospital		Designated Health Professional Shortage Areas	https://catalog.data.gov/dataset/designated-health-professional-shortage-areas		
		HCUPnet	http://catalog.data.gov/dataset/hcupnet		
		National Ambulatory Medical Care Survey (NAMCS)	http://catalog.data.gov/dataset/national-ambulatory-medical-care-survey-namcs		
		National Health Expenditures - State (Provider)	https://catalog.data.gov/dataset/national-health-expenditures-state-provider		
		State Snapshots	http://catalog.data.gov/dataset/state-snapshots		
		USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	https://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass		
Dams and Reservoirs		FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies		
Irrigation 					
Airports		FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies		
Exposure		FluView National Flu Activity Map	https://catalog.data.gov/dataset/fluview-national-flu-activity-map		
Pathway					
Ticks					
Mosquitoes					
Fleas					
Source					
Birds					
Rodents					
Location		TIGER/Line Shapefile- 2014-Series Information for the Current County and Equivalent National Shapefile	http://catalog.data.gov/dataset/tiger-line-shapefile-2014series-information-for-the-current-county-and-equivalent-national-shap		
Geographic Distribution					
Proximity to water					
Urban		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
Time					
Vector Seasonal Activity		FluView National Flu Activity Map	http://catalog.data.gov/dataset/fluview-national-flu-activity-map		
Contaminants					
Pathogens		Investigation of bacterial pathogens associated with concentrated animal feeding operations (CAFOs) and their potential impacts on a National Wildlife Refuge in Oklahoma: Final report	https://catalog.data.gov/dataset/investigation-of-bacterial-pathogens-associated-with-concentrated-animal-feeding-operation		
Lyme disease		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
Spotted Fever Rickettsia		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
Babesiosis		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
Anaplasmosis/Ehrlichiosis					
Tularemia		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
St. Louis encephalitis		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
California Serogroup Viruses		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
Dengue		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
Malaria		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
West Nile Virus		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
Powassan					
Eastern Equine Encephalitis		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
Murine Typhus					
Bubonic Plague		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
Septicemic Plague		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
Pneumonic Plague		CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death		
		CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death		
		CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths		
		CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death		
		CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death		
Natural Hazard		Geographical Information System Graphical Database of Tornados 1950-2006	http://catalog.data.gov/dataset/geographical-information-system-graphical-database-of-tornados-1950-2006		
		NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database		
		NOAA Emergency Response Imagery	http://catalog.data.gov/dataset/noaa-emergency-response-imagery		
Flooding		Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper		
		FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies		
		National Flood Hazard Layer (NFHL)	http://catalog.data.gov/dataset/national-flood-hazard-layer-nfhl		
		NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database		
		NOAA Digital Coast Sea Level Rise and Coastal Flooding Impacts Viewer	http://catalog.data.gov/dataset/noaa-digital-coast-sea-level-rise-and-coastal-flooding-impacts-viewer		
		NOAA National Weather Service- Flood Inundation Map Libraries 	http://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries		
		WaterWatch -- Current Water Resources Conditions	http://catalog.data.gov/dataset/waterwatch-current-water-resources-conditions		
Drought		Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions		
		National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system		
		NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database		
		WaterWatch -- Current Water Resources Conditions	http://catalog.data.gov/dataset/waterwatch-current-water-resources-conditions		
Hurricane		FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies		
		NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database		
		NOAA Emergency Response Imagery	http://catalog.data.gov/dataset/noaa-emergency-response-imagery		
Climate Indicators		Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo		
		Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis		
		Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices		
		Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions		
		Global Climate Station Summaries	https://catalog.data.gov/dataset/global-climate-station-summaries		
		Global Historical Climatology Network - Daily (GHCN-Daily), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3		
		Global Historical Climatology Network - Monthly (GHCN-M), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3		
		Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod		
		Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data		
		NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information		
		PRISM	http://catalog.data.gov/dataset/prism-585c8		
		Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication		
		U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010		
		U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products		
		U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products		
		U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products		
		U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010		
		U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010		
		U.S. Hourly Precipitation Data	https://catalog.data.gov/dataset/u-s-hourly-precipitation-data		
		U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010		
		United States Average Annual Precipitation, 1990-2009 - Direct Download	https://catalog.data.gov/dataset/united-states-average-annual-precipitation-1990-2009-direct-download		
Temperature		CDC WONDER: Daily Air Temperatures and Heat Index	https://catalog.data.gov/dataset/cdc-wonder-daily-air-temperatures-and-heat-index		
		Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo		
		Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis		
		Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices		
		Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions		
		Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe		
		Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries		
		Global Historical Climatology Network - Daily (GHCN-Daily)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3		
		Global Historical Climatology Network - Monthly (GHCN-M)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3		
		Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod		
		Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	https://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe		
		Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data		
		National Integrated Drought Information System	http://catalog.data.gov/dataset/national-integrated-drought-information-system		
		NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database		
		NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information		
		PRISM	http://catalog.data.gov/dataset/prism-585c8		
		Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication		
		U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010		
		U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products		
		U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products		
		U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products		
		U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010		
		U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010		
		U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010		
Precipitation		Global Historical Climatology Network - Daily (GHCN-Daily)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3		
		Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data		
		National Integrated Drought Information System	http://catalog.data.gov/dataset/national-integrated-drought-information-system		
		NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database		
		NOAA Climate Data Record (CDR) of Precipitation Estimation from Remotely Sensed Information using Artificial Neural Networks (PERSIANN-CDR)- Version 1 Revision 1	http://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-precipitation-estimation-from-remotely-sensed-information-using		
		NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information		
		PRISM	http://catalog.data.gov/dataset/prism-585c8		
		Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication		
		United States Average Annual Precipitation- 1990-2009 - Direct Download	http://catalog.data.gov/dataset/united-states-average-annual-precipitation-1990-2009-direct-download		
		U.S. 15 Minute Precipitation Data	http://catalog.data.gov/dataset/u-s-15-minute-precipitation-data		
		U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010		
		U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products		
		U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products		
		U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products		
		U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010		
		U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010		
		U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010		
		Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices		
		Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions		
		Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe		
		Global Climate Station Summaries	https://catalog.data.gov/dataset/global-climate-station-summaries		
		Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod		
		Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	https://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe		
		Severe Weather Data Inventory	https://catalog.data.gov/dataset/severe-weather-data-inventory		
		U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries		
		U.S. Hourly Precipitation Data	https://catalog.data.gov/dataset/u-s-hourly-precipitation-data		
Humidity		Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries		
		Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data		
		NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties		
		Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication		
		U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products		
		U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products		
		U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products		
