#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\WI-load-term-map.sql";
$Relationship = "Throw this away";
$Sql1="";
$Skip1=$Skip2="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
	($Skip1,$Skip2,$TermIn,$Relationship,$Dataset,$URI) = split(/\t/);
	$TermIn = trim($TermIn);		# trim trailing/leading spaces
	$Term = $TermIn;
	if ($Term eq "") {
		$ThisTerm = $OldTerm
	} else {
		$ThisTerm = $OldTerm = $Term;
	}
	$Dataset = trim($Dataset);
	$Dataset =~ s/'/''/g;		# Escape single quotes
	if ($Dataset eq "") {
		$Dataset= "N/A";
	}

	$URI= trim($URI);
	if ($URI eq "") {
		$URI= "N/A";
	}
	$Relationship = trim($Relationship);

$Sql1 = "INSERT INTO term_map (term_id, relationship, gcid, description) VALUES ((SELECT s.id FROM term AS s WHERE s.term = ";
	$OutLine=<<EOM;
$Sql1'$ThisTerm' and s.lexicon_identifier = 'cdi'), 'isMentionedIn', '$URI', '$Dataset');
EOM

	print OUT "$OutLine" if ($TermIn ne "");
}
close OUT;
system "$ENV{'ED'} $F1"
#Subject	Predicate	Relationship	Object
#Term	Relationship	Datasets	extURI		
__DATA__
		Health	isMentionedIn		https://catalog.data.gov/dataset?vocab_category_all=Human+Health&groups=climate5434#topic=humanhealth_navigation
		Water Related Illnesses			
		Human Vulnerability	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
		Human Vulnerability	isMentionedIn	CDC WONDER: Cancer Statistics	http://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
		Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	"https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths"
		Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
		Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
		Human Vulnerability	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
		Human Vulnerability	isMentionedIn	Designated Health Professional Shortage Areas	http://catalog.data.gov/dataset/designated-health-professional-shortage-areas
		Human Vulnerability	isMentionedIn	Food Environment Atlas	http://catalog.data.gov/dataset/food-environment-atlas-f4a22
		Human Vulnerability	isMentionedIn	Food Security in the United States	http://catalog.data.gov/dataset/food-security-in-the-united-states
		Human Vulnerability	isMentionedIn	Global Annual Average PM2.5 Grids from MODIS and MISR Aerosol Optical Depth (AOD)	http://catalog.data.gov/dataset/global-annual-average-pm2-5-grids-from-modis-and-misr-aerosol-optical-depth-aod
		Human Vulnerability	isMentionedIn	HCUPnet	http://catalog.data.gov/dataset/hcupnet
		Human Vulnerability	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
		Human Vulnerability	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
		Human Vulnerability	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
		Human Vulnerability	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
					
		Socioeconomic Risks	isMentionedIn	Food Environment Atlas	https://catalog.data.gov/dataset/food-environment-atlas-f4a22
		Socioeconomic Risks	isMentionedIn	Food Access Research Atlas	http://catalog.data.gov/dataset/food-access-research-atlas
		Socioeconomic Risks	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
		Socioeconomic Risks	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
		Socioeconomic Risks	isMentionedIn	NOAA Digital Coast Sea Level Rise and Coastal Flooding Impacts Viewer	https://catalog.data.gov/dataset/noaa-digital-coast-sea-level-rise-and-coastal-flooding-impacts-viewer
		Socioeconomic Risks	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
					
		Social Mores			
		Health Care Access	isMentionedIn	Designated Health Professional Shortage Areas	https://catalog.data.gov/dataset/designated-health-professional-shortage-areas
		Health Care Access	isMentionedIn	HCUPnet	https://catalog.data.gov/dataset/hcupnet
		Health Care Access	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
		Health Care Access	isMentionedIn	Mental Health Treatement Facilities Locator	https://catalog.data.gov/dataset/mental-health-treatement-facilities-locator
		Health Care Access	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
					
		Employment	isMentionedIn	Statistical Abstract of the United States	https://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
		Employment	isMentionedIn	EnviroAtlas - Clean and Plentiful Water Metrics for the Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-and-plentiful-water-metrics-for-the-conterminous-united-states
					
		Poverty	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
		Poverty	isMentionedIn	Supplemental Nutrition Assistance Program (SNAP) Data System	http://catalog.data.gov/dataset/supplemental-nutrition-assistance-program-snap-data-system-a2b49
		Poverty	isMentionedIn	Designated Health Professional Shortage Areas	http://catalog.data.gov/dataset/designated-health-professional-shortage-areas
		Poverty	isMentionedIn	EnviroAtlas - Clean and Plentiful Water Metrics for the Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-and-plentiful-water-metrics-for-the-conterminous-united-states
		Poverty	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
					
		Education	isMentionedIn	Statistical Abstract of the United States	https://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
		Education	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
		Education	isMentionedIn	National Death Index	https://catalog.data.gov/dataset/national-death-index
		Education	isMentionedIn	USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	https://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass
		Education	isMentionedIn	EnviroAtlas - Clean and Plentiful Water Metrics for the Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-and-plentiful-water-metrics-for-the-conterminous-united-states
		Language			
		Housing	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
		Housing	isMentionedIn	Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas
					
		Environment			
		Transportation	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	https://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
		Transportation	isMentionedIn	Statistical Abstract of the United States	https://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
					
		Populations at Risk	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
		Populations at Risk	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
		Populations at Risk	isMentionedIn	CDC WONDER: Cancer Statistics 	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
		Populations at Risk	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
		Populations at Risk	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
		Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	"https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths"
		Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
		Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
		Populations at Risk	isMentionedIn	CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates
		Populations at Risk	isMentionedIn	Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas
		Populations at Risk	isMentionedIn	Food Environment Atlas	http://catalog.data.gov/dataset/food-environment-atlas-f4a22
		Populations at Risk	isMentionedIn	Pesticide Data Program 2008	http://catalog.data.gov/dataset/pesticide-data-program-2008
		Populations at Risk	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
		Populations at Risk	isMentionedIn	Supplemental Nutrition Assistance Program (SNAP) Data System	http://catalog.data.gov/dataset/supplemental-nutrition-assistance-program-snap-data-system-a2b49
		Populations at Risk	isMentionedIn	Fire Weather Outlooks 	http://catalog.data.gov/dataset/fire-weather-outlooks
		Populations at Risk	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	http://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
					
		Indigenous People			
		Pregnant	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
		Pregnant	isMentionedIn	VitalStats	https://catalog.data.gov/dataset/vitalstats
					
		Race/Ethnicity	isMentionedIn	CDC WONDER: Cancer Statistics	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
		Race/Ethnicity	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
		Race/Ethnicity	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
		Race/Ethnicity	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
		Race/Ethnicity	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
		Race/Ethnicity	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
		Race/Ethnicity	isMentionedIn	CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates
		Race/Ethnicity	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
		Race/Ethnicity	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
		Race/Ethnicity	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
		Race/Ethnicity	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
					
		Age	isMentionedIn	CDC WONDER: Cancer Statistics	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
		Age	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
		Age	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
		Age	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
		Age	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
		Age	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
		Age	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
		Age	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
		Age	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
		Age	isMentionedIn	CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates
		Age	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
		Age	isMentionedIn	VitalStats	https://catalog.data.gov/dataset/vitalstats
		Age	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
		Sex/Gender	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
		Sex/Gender	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
		Sex/Gender	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
		Sex/Gender	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
		Sex/Gender	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
		Sex/Gender	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
		Sex/Gender	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
					
		Response	isMentionedIn	NOAA Emergency Response Imagery	http://catalog.data.gov/dataset/noaa-emergency-response-imagery
		Response	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries	https://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
		Response	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
		Planning	isMentionedIn	Coastal Tribal Lands	https://catalog.data.gov/dataset/coastal-tribal-lands
		Planning	isMentionedIn	US Forest Service Surface Drinking Water Importance	https://catalog.data.gov/dataset/us-forest-service-surface-drinking-water-importance
		Planning	isMentionedIn	Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper
		Planning	isMentionedIn	NOAA Digital Coast Sea Level Rise and Coastal Flooding Impacts Viewer	https://catalog.data.gov/dataset/noaa-digital-coast-sea-level-rise-and-coastal-flooding-impacts-viewer
		Planning	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries	https://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
		Planning	isMentionedIn	USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	https://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass
					
		Urban Growth			
					
		Nuisance Flooding	isMentionedIn	Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper
		Nuisance Flooding	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
		Nuisance Flooding	isMentionedIn	National Flood Hazard Layer (NFHL)	http://catalog.data.gov/dataset/national-flood-hazard-layer-nfhl
		Nuisance Flooding	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
		Nuisance Flooding	isMentionedIn	NOAA Digital Coast Sea Level Rise and Coastal Flooding Impacts Viewer	http://catalog.data.gov/dataset/noaa-digital-coast-sea-level-rise-and-coastal-flooding-impacts-viewer
		Nuisance Flooding	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries 	http://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
					
		Storm Shelters			
		Mitigation	isMentionedIn	Analysis of Methane Mitigation Options using the MARKAL Model for the US: Calibration Data for Methane Emissions	https://catalog.data.gov/dataset/analysis-of-methane-mitigation-options-using-the-markal-model-for-the-us-calibration-data-for-m
		Mitigation	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries	https://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
					
		Agricultural Management Practices	isMentionedIn	Quick Stats Agricultural Database API	http://catalog.data.gov/dataset/quick-stats-agricultural-database-api
		Agricultural Management Practices	isMentionedIn	Agriculture Census of the United States - 2007 - Direct Download	http://catalog.data.gov/dataset/agriculture-census-of-the-united-states-2007-direct-download
					
		Health Surveillance System			
		Shellfish Bed Closure			
		Notification	isMentionedIn	National Weather Service County Warning Area Boundaries	http://catalog.data.gov/dataset/national-weather-service-county-warning-area-boundaries
		Reporting Capacity			
		Hydrology	isMentionedIn	National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system
		Hydrology	isMentionedIn	WaterWatch -- Current Water Resource Conditions	https://catalog.data.gov/dataset/waterwatch-current-water-resources-conditions
		Hydrology	isMentionedIn	USGS Water-Quality Data for the Nation - National Water Information System (NWIS)	https://catalog.data.gov/dataset/usgs-water-quality-data-for-the-nation-national-water-information-system-nwis
		Hydrology	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
					
		Discharge			
		Watershed	isMentionedIn	US Forest Service Surface Drinking Water Importance	https://catalog.data.gov/dataset/us-forest-service-surface-drinking-water-importance
		Watershed	isMentionedIn	Current Clean Water Act 303(d) Listed Impaired Waters and their Causes of Impairment	https://catalog.data.gov/dataset/current-clean-water-act-303d-listed-impaired-waters-and-their-causes-of-impairment
		Watershed	isMentionedIn	Investigation of bacterial pathogens associated with concentrated animal feeding operations (CAFOs) and their potential impacts on a National Wildlife Refuge in Oklahoma: Final report	https://catalog.data.gov/dataset/investigation-of-bacterial-pathogens-associated-with-concentrated-animal-feeding-operation
		Watershed	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
					
		Nutrient Loading			
		Turbidity	isMentionedIn	Current Clean Water Act 303(d) Listed Impaired Waters and their Causes of Impairment	https://catalog.data.gov/dataset/current-clean-water-act-303d-listed-impaired-waters-and-their-causes-of-impairment
		Turbidity	isMentionedIn	USGS Water-Quality Data for the Nation - National Water Information System (NWIS)	http://catalog.data.gov/dataset/usgs-water-quality-data-for-the-nation-national-water-information-system-nwis
					
		Stream Flow	isMentionedIn	USGS Water-Quality Data for the Nation - National Water Information System (NWIS)	http://catalog.data.gov/dataset/usgs-water-quality-data-for-the-nation-national-water-information-system-nwis
		Stream Flow	isMentionedIn	WaterWatch -- Current Water Resource Conditions	http://catalog.data.gov/dataset/waterwatch-current-water-resource-conditions
					
		Eutrophication			
		Residence Time			
		Harmful Algal Blooms (HABs)	isMentionedIn	NOAA NCCOS: New England Red Tide Research	https://catalog.data.gov/dataset/noaa-nccos-new-england-red-tide-research
					
		Infrastructure	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
		Infrastructure	isMentionedIn	USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	https://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass
					
		Water Purification Systems			
		Water Treatment Plants	isMentionedIn	Drinking Water Treatability Database (TDB)	http://catalog.data.gov/dataset/drinking-water-treatability-database-tdb
					
		Water Distribution Systems			
		Pipelines			
		Water Towers			
		Water Tanks			
		Wastewater System	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	https://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
		Septic Systems			
		Sanitary Sewer Systems			
		Wastewater Treatment Plant	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	https://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
		Lifts			
		Sewer Pipes			
		Wastewater Lagoons			
		Stormwater Systems			
		Combined Sewer Systems			
		Wells	isMentionedIn	Arsenic in Ground Water of the United States - Direct Download	https://catalog.data.gov/dataset/arsenic-in-ground-water-of-the-united-states-direct-download
					
		Exposure	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
		Exposure	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
		Exposure	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
		Exposure	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
		Exposure	isMentionedIn	Global Annual Average PM2.5 Grids from MODIS and MISR Aerosol Optical Depth (AOD)	https://catalog.data.gov/dataset/global-annual-average-pm2-5-grids-from-modis-and-misr-aerosol-optical-depth-aod
		Exposure	isMentionedIn	Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper
		Exposure	isMentionedIn	EnviroAtlas - Clean and Plentiful Water Metrics for the Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-and-plentiful-water-metrics-for-the-conterminous-united-states
					
		Location	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
		Location	isMentionedIn	CDC WONDER: Daily Fine Particulate Matter	http://catalog.data.gov/dataset/cdc-wonder-daily-fine-particulate-matter
		Location	isMentionedIn	Clean Air Markets - Where You Live (National and State Maps)	http://catalog.data.gov/dataset/clean-air-markets-where-you-live-national-and-state-maps
		Location	isMentionedIn	Clean Air Status and Trends Network (CASTNET)	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet
		Location	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
		Location	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
		Location	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
		Location	isMentionedIn	Fire Weather Outlooks 	http://catalog.data.gov/dataset/fire-weather-outlooks
		Location	isMentionedIn	FluView National Flu Activity Map	http://catalog.data.gov/dataset/fluview-national-flu-activity-map
		Location	isMentionedIn	National Flood Hazard Layer (NFHL)	http://catalog.data.gov/dataset/national-flood-hazard-layer-nfhl
		Location	isMentionedIn	National Integrated Drought Information System	http://catalog.data.gov/dataset/national-integrated-drought-information-system
		Location	isMentionedIn	National Weather Service County Warning Area Boundaries	http://catalog.data.gov/dataset/national-weather-service-county-warning-area-boundaries
		Location	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
		Location	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries 	http://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
		Location	isMentionedIn	USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	http://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass
					
		Geographic Distribution			
		Habitat			
		CaFOs	isMentionedIn	Investigation of bacterial pathogens associated with concentrated animal feeding operations (CAFOs) and their potential impacts on a National Wildlife Refuge in Oklahoma: Final report	https://catalog.data.gov/dataset/investigation-of-bacterial-pathogens-associated-with-concentrated-animal-feeding-operation
					
		Time			
		Seasonal Growth Window			
		Pathway			
		Recreational Water			
		Fish			
		Shellfish	isMentionedIn	NOAA NCCOS: New England Red Tide Research	https://catalog.data.gov/dataset/noaa-nccos-new-england-red-tide-research
					
		Drinking Water	isMentionedIn	Arsenic in Ground Water of the United States - Direct Download	http://catalog.data.gov/dataset/arsenic-in-ground-water-of-the-united-states-direct-download
		Drinking Water	isMentionedIn	Current Clean Water Act 303(d) Listed Impaired Waters and their Causes of Impairment	http://catalog.data.gov/dataset/current-clean-water-act-303d-listed-impaired-waters-and-their-causes-of-impairment
		Drinking Water	isMentionedIn	Drinking Water Maximum Contaminant Levels (MCLs)	http://catalog.data.gov/dataset/drinking-water-maximum-contaminant-levels-mcls
		Drinking Water	isMentionedIn	Drinking Water Treatability Database (TDB)	http://catalog.data.gov/dataset/drinking-water-treatability-database-tdb
		Drinking Water	isMentionedIn	EnviroAtlas - Clean and Plentiful Water Metrics for the Conterminous United States	http://catalog.data.gov/dataset/enviroatlas-clean-and-plentiful-water-metrics-for-the-conterminous-united-states
		Drinking Water	isMentionedIn	Pesticide Data Program 2008	http://catalog.data.gov/dataset/pesticide-data-program-2008
		Drinking Water	isMentionedIn	Safe Drinking Water Information System (SDWIS)	http://catalog.data.gov/dataset/safe-drinking-water-information-system-sdwis
		Drinking Water	isMentionedIn	USGS Water-Quality Data for the Nation - National Water Information System (NWIS)	http://catalog.data.gov/dataset/usgs-water-quality-data-for-the-nation-national-water-information-system-nwis
					
		Sources	isMentionedIn	Air Markets Program Data (AMPD)	http://catalog.data.gov/dataset/air-markets-program-data-ampd
					
		Human Waste			
		Animal Waste	isMentionedIn	Investigation of bacterial pathogens associated with concentrated animal feeding operations (CAFOs) and their potential impacts on a National Wildlife Refuge in Oklahoma: Final report	https://catalog.data.gov/dataset/investigation-of-bacterial-pathogens-associated-with-concentrated-animal-feeding-operation
					
		Agriculture	isMentionedIn	Quick Stats Agricultural Database API	https://catalog.data.gov/dataset/quick-stats-agricultural-database-api
		Agriculture	isMentionedIn	Agriculture Census of the United States - 2007 - Direct Download	https://catalog.data.gov/dataset/agriculture-census-of-the-united-states-2007-direct-download
		Agriculture	isMentionedIn	Agricultural Baseline Database	https://catalog.data.gov/dataset/agricultural-baseline-database
		Agriculture	isMentionedIn	Concentrated Animal Feeding Operations (CAFOs) per County Downloadable Package, US, 2013, US EPA	https://catalog.data.gov/dataset/concentrated-animal-feeding-operations-cafos-per-county-downloadable-package-us-2013-us-epa
		Agriculture	isMentionedIn	Statistical Abstract of the United States	https://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
					
		Fertilizers	isMentionedIn	Quick Stats Agricultural Database API	https://catalog.data.gov/dataset/quick-stats-agricultural-database-api
					
		Contaminants	isMentionedIn	Air Markets Program Data (AMPD)	http://catalog.data.gov/dataset/air-markets-program-data-ampd
		Contaminants	isMentionedIn	Analysis of Methane Mitigation Options using the MARKAL Model for the US: Calibration Data for Methane Emissions 	https://catalog.data.gov/dataset/analysis-of-methane-mitigation-options-using-the-markal-model-for-the-us-calibration-data-for-m
		Contaminants	isMentionedIn	Clean Air Markets - Where You Live (National and State Maps)	http://catalog.data.gov/dataset/clean-air-markets-where-you-live-national-and-state-maps
		Contaminants	isMentionedIn	Clean Air Status and Trends Network (CASTNET) 	http://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet
		Contaminants	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	http://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
		Contaminants	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
		Contaminants	isMentionedIn	Drainage Basins Used for Assessing Trends in Concentration of Pesticides in Streams of the United States- 1992-2010	http://catalog.data.gov/dataset/drainage-basins-used-for-assessing-trends-in-concentration-of-pesticides-in-streams-o-1992-2010
		Contaminants	isMentionedIn	Drinking Water Maximum Contaminant Levels (MCLs)	http://catalog.data.gov/dataset/drinking-water-maximum-contaminant-levels-mcls
		Contaminants	isMentionedIn	Drinking Water Treatability Database (TDB)	http://catalog.data.gov/dataset/drinking-water-treatability-database-tdb
		Contaminants	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	http://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
		Contaminants	isMentionedIn	EnviroAtlas - Clean and Plentiful Water Metrics for the Conterminous United States	http://catalog.data.gov/dataset/enviroatlas-clean-and-plentiful-water-metrics-for-the-conterminous-united-states
		Contaminants	isMentionedIn	Investigation of bacterial pathogens associated with concentrated animal feeding operations (CAFOs) and their potential impacts on a National Wildlife Refuge in Oklahoma: Final report	http://catalog.data.gov/dataset/investigation-of-bacterial-pathogens-associated-with-concentrated-animal-feeding-operation
		Contaminants	isMentionedIn	Report on U.S. Methane Emissions 1990-2020: Inventories- Projections- and Opportunities for Reductions: 2001 Updated emission and cost estimates	https://catalog.data.gov/dataset/report-on-u-s-methane-emissions-1990-2020-inventories-projections-and-opportunities-for-reducti
		Contaminants	isMentionedIn	Safe Drinking Water Information System (SDWIS)	http://catalog.data.gov/dataset/safe-drinking-water-information-system-sdwis
		Contaminants	isMentionedIn	National Status and Trends: Mussel Watch Program	https://catalog.data.gov/dataset/national-status-and-trends-mussel-watch-program
		Contaminants	isMentionedIn	Arsenic in Ground Water of the United States - Direct Download	http://catalog.data.gov/dataset/arsenic-in-ground-water-of-the-united-states-direct-download
					
		Pathogens	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
		Pathogens	isMentionedIn	Investigation of bacterial pathogens associated with concentrated animal feeding operations (CAFOs) and their potential impacts on a National Wildlife Refuge in Oklahoma: Final report	http://catalog.data.gov/dataset/investigation-of-bacterial-pathogens-associated-with-concentrated-animal-feeding-operation
		Pathogens	isMentionedIn	Safe Drinking Water Information System (SDWIS)	http://catalog.data.gov/dataset/safe-drinking-water-information-system-sdwis
		Pathogens	isMentionedIn	Current Clean Water Act 303(d) Listed Impaired Waters and their Causes of Impairment	http://catalog.data.gov/dataset/current-clean-water-act-303d-listed-impaired-waters-and-their-causes-of-impairment
		Cyanobacteria			
		Vibrio	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
					
		Cholera	isMentionedIn	Cost Estimates of Foodborne Illnesses	https://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
		Cholera	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
		Cholera	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
		Cryptosporidium			
		Giardia			
		Salmonella enterica	isMentionedIn	Cost Estimates of Foodborne Illnesses	https://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
		Salmonella enterica	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
		Salmonella enterica	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
					
		Naegleria	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
		Naegleria	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
					
		Leptospira	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
		Leptospira	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
					
		Leptonema			
		Campylobacter			
		Escherichia coli	isMentionedIn	Investigation of bacterial pathogens associated with concentrated animal feeding operations (CAFOs) and their potential impacts on a National Wildlife Refuge in Oklahoma: Final report	https://catalog.data.gov/dataset/investigation-of-bacterial-pathogens-associated-with-concentrated-animal-feeding-operation
		Escherichia coli	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
		Escherichia coli	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
		Escherichia coli	isMentionedIn	Current Clean Water Act 303(d) Listed Impaired Waters and their Causes of Impairment	http://catalog.data.gov/dataset/current-clean-water-act-303d-listed-impaired-waters-and-their-causes-of-impairment
		Escherichia coli	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
		Enteroviruses			
		Rotaviruses			
		Noroviruses	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
		Noroviruses	isMentionedIn	FluView National Flu Activity Map	https://catalog.data.gov/dataset/fluview-national-flu-activity-map
					
		Chemicals	isMentionedIn	Arsenic in Ground Water of the United States - Direct Download	http://catalog.data.gov/dataset/arsenic-in-ground-water-of-the-united-states-direct-download
		Chemicals	isMentionedIn	Current Clean Water Act 303(d) Listed Impaired Waters and their Causes of Impairment	http://catalog.data.gov/dataset/current-clean-water-act-303d-listed-impaired-waters-and-their-causes-of-impairment
		Chemicals	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
		Chemicals	isMentionedIn	National Status and Trends: Mussel Watch Program	https://catalog.data.gov/dataset/national-status-and-trends-mussel-watch-program
		Chemicals	isMentionedIn	Drinking Water Treatability Database (TDB)	https://catalog.data.gov/dataset/drinking-water-treatability-database-tdb
		Chemicals	isMentionedIn	Drinking Water Maximum Contaminant Levels (MCLs)	https://catalog.data.gov/dataset/drinking-water-maximum-contaminant-levels-mcls
					
		Mercury	isMentionedIn	Current Clean Water Act 303(d) Listed Impaired Waters and their Causes of Impairment	http://catalog.data.gov/dataset/current-clean-water-act-303d-listed-impaired-waters-and-their-causes-of-impairment
		Organohalogens			
		Organotins			
		Biotoxins			
		Ciguatoxins			
		Saxitoxins			
		Domoic Acids			
		Okadaic Acids			
		Brevetoxins			
		Natural Hazard	isMentionedIn	NOAA Emergency Response Imagery	http://catalog.data.gov/dataset/noaa-emergency-response-imagery
		Natural Hazard	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
		Natural Hazard	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
		Natural Hazard	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	https://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
		Natural Hazard	isMentionedIn	Fire Weather Outlooks	https://catalog.data.gov/dataset/fire-weather-outlooks
		Natural Hazard	isMentionedIn	Geographical Information System Graphical Database of Tornados 1950-2006	https://catalog.data.gov/dataset/geographical-information-system-graphical-database-of-tornados-1950-2006
		Natural Hazard	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
		Natural Hazard	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
		Natural Hazard	isMentionedIn	National Flood Hazard Layer (NFHL)	https://catalog.data.gov/dataset/national-flood-hazard-layer-nfhl
		Natural Hazard	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
		Natural Hazard	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries	https://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
		Natural Hazard	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
		Natural Hazard	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
		Natural Hazard	isMentionedIn	Severe Weather Data Inventory	http://catalog.data.gov/dataset/severe-weather-data-inventory
		Natural Hazard	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
		Natural Hazard	isMentionedIn	National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system
					
		Drought	isMentionedIn	National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system
		Drought	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
		Drought	isMentionedIn	WaterWatch -- Current Water Resource Conditions	http://catalog.data.gov/dataset/waterwatch-current-water-resources-conditions
		Drought	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	http://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
		Drought	isMentionedIn	Integrated Surface Global Hourly Data	https://catalog.data.gov/dataset/integrated-surface-global-hourly-data
		Drought	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
		Drought	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
					
		Runoff	isMentionedIn	WaterWatch -- Current Water Resource Conditions	https://catalog.data.gov/dataset/waterwatch-current-water-resources-conditions
		Runoff	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
					
		Flooding	isMentionedIn	Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper
		Flooding	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
		Flooding	isMentionedIn	National Flood Hazard Layer (NFHL)	http://catalog.data.gov/dataset/national-flood-hazard-layer-nfhl
		Flooding	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
		Flooding	isMentionedIn	NOAA Digital Coast Sea Level Rise and Coastal Flooding Impacts Viewer	http://catalog.data.gov/dataset/noaa-digital-coast-sea-level-rise-and-coastal-flooding-impacts-viewer
		Flooding	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries 	http://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
		Flooding	isMentionedIn	WaterWatch -- Current Water Resource Conditions	http://catalog.data.gov/dataset/waterwatch-current-water-resource-conditions
		Flooding	isMentionedIn	Integrated Surface Global Hourly Data	https://catalog.data.gov/dataset/integrated-surface-global-hourly-data
			isMentionedIn		
		Storm Surge	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
		Storm Surge	isMentionedIn	Integrated Surface Global Hourly Data	https://catalog.data.gov/dataset/integrated-surface-global-hourly-data
		Storm Surge	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
					
		Sea Level Rise	isMentionedIn	USGS Map service: Coastal Vulnerability to Sea-Level Rise	https://catalog.data.gov/dataset/usgs-map-service-coastal-vulnerability-to-sea-level-rise
		Sea Level Rise	isMentionedIn	NOAA Digital Coast Sea Level Rise and Coastal Flooding Impacts Viewer	https://catalog.data.gov/dataset/noaa-digital-coast-sea-level-rise-and-coastal-flooding-impacts-viewer
		Sea Level Rise	isMentionedIn	Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper
		Sea Level Rise	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
					
		Hurricanes	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
		Hurricanes	isMentionedIn	NOAA Emergency Response Imagery	http://catalog.data.gov/dataset/noaa-emergency-response-imagery
		Hurricanes	isMentionedIn	Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper
					
		Climate Indicators	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
		Climate Indicators	isMentionedIn	Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis
		Climate Indicators	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
		Climate Indicators	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
		Climate Indicators	isMentionedIn	Global Climate Station Summaries	https://catalog.data.gov/dataset/global-climate-station-summaries
		Climate Indicators	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
		Climate Indicators	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
		Climate Indicators	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
		Climate Indicators	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	http://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
		Climate Indicators	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
		Climate Indicators	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
		Climate Indicators	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
		Climate Indicators	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
		Climate Indicators	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
		Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
		Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
		Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
		Climate Indicators	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
		Climate Indicators	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
		Climate Indicators	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
		Climate Indicators	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
		Climate Indicators	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
		Climate Indicators	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
					
		Sea Surface Temperature	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
		Sea Surface Temperature	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	https://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
		Sea Surface Temperature	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
					
		Temperature	isMentionedIn	CDC WONDER: Daily Air Temperatures and Heat Index	https://catalog.data.gov/dataset/cdc-wonder-daily-air-temperatures-and-heat-index
		Temperature	isMentionedIn	CDC WONDER: Daily Fine Particulate Matter	https://catalog.data.gov/dataset/cdc-wonder-daily-fine-particulate-matter
		Temperature	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
		Temperature	isMentionedIn	Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis
		Temperature	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
		Temperature	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
		Temperature	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
		Temperature	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
		Temperature	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
		Temperature	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
		Temperature	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
		Temperature	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	https://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
		Temperature	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
		Temperature	isMentionedIn	MODIS/Terra+Aqua NRT value-added Aerosol Optical Depth Produc V051 NRT	http://catalog.data.gov/dataset/modis-terraaqua-nrt-value-added-aerosol-optical-depth-produc-v051-nrt
		Temperature	isMentionedIn	National Integrated Drought Information System	http://catalog.data.gov/dataset/national-integrated-drought-information-system
		Temperature	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
		Temperature	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
		Temperature	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
		Temperature	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
		Temperature	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
		Temperature	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
		Temperature	isMentionedIn	Tropospheric Emission Spectrometer (TES) Data	http://catalog.data.gov/dataset/tropospheric-emission-spectrometer-tes-data
		Temperature	isMentionedIn	U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries
		Temperature	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
		Temperature	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
		Temperature	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
		Temperature	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
		Temperature	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
		Temperature	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
		Temperature	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
					
		Precipitation	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
		Precipitation	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
		Precipitation	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
		Precipitation	isMentionedIn	Global Climate Station Summaries	https://catalog.data.gov/dataset/global-climate-station-summaries
		Precipitation	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
		Precipitation	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
		Precipitation	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	https://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
		Precipitation	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
		Precipitation	isMentionedIn	MODIS/Terra+Aqua NRT value-added Aerosol Optical Depth Produc V051 NRT	http://catalog.data.gov/dataset/modis-terraaqua-nrt-value-added-aerosol-optical-depth-produc-v051-nrt
		Precipitation	isMentionedIn	National Integrated Drought Information System	http://catalog.data.gov/dataset/national-integrated-drought-information-system
		Precipitation	isMentionedIn	NOAA Climate Data Record (CDR) of Precipitation Estimation from Remotely Sensed Information using Artificial Neural Networks (PERSIANN-CDR)- Version 1 Revision 1	http://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-precipitation-estimation-from-remotely-sensed-information-using
		Precipitation	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
		Precipitation	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
		Precipitation	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
		Precipitation	isMentionedIn	U.S. 15 Minute Precipitation Data	http://catalog.data.gov/dataset/u-s-15-minute-precipitation-data
		Precipitation	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
		Precipitation	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
		Precipitation	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
		Precipitation	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
		Precipitation	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
		Precipitation	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
		Precipitation	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
		Precipitation	isMentionedIn	U.S. Hourly Precipitation Data	https://catalog.data.gov/dataset/u-s-hourly-precipitation-data
		Precipitation	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
		Precipitation	isMentionedIn	United States Average Annual Precipitation- 1990-2009 - Direct Download	http://catalog.data.gov/dataset/united-states-average-annual-precipitation-1990-2009-direct-download
		Precipitation	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
		Precipitation	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
		Precipitation	isMentionedIn	U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries
		Precipitation	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
					
		Salinity	isMentionedIn	NOAA NCCOS: New England Red Tide Research	https://catalog.data.gov/dataset/noaa-nccos-new-england-red-tide-research
		Salinity	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
		Salinity	isMentionedIn	Current Clean Water Act 303(d) Listed Impaired Waters and their Causes of Impairment	http://catalog.data.gov/dataset/current-clean-water-act-303d-listed-impaired-waters-and-their-causes-of-impairment
