#!/usr/bin/perl
$Verz="9";        #File last modified Fri Jun 18 10:44:41 1999
$ENV{'PATH'} = "/bin:/usr/bin:/usr/ucb:/usr/lib";
$ENV{'IFS'} = "";
$loc = localtime;
print <<EOM;
Content-type: text/html

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">
<HTML>
<HEAD>
<title>Dump of form data (V.$Verz)</title>
</HEAD>
<h1>Dump of form data (V.$Verz)</h1>
<h2>$loc</h2>
<h3> Your IP: $ENV{'REMOTE_ADDR'}</h3>
***<br>
$ENV{'HTTP_USER_AGENT'}
<br>***<br>
<table border = 1>
<tr><td><B>Cell Name</B></td><td><B>Cell Contents</B></td></tr>
<tr><td></td><td></td></tr>
EOM

if (defined ($ENV{'CONTENT_LENGTH'})) {
   read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});  #Snarf STDIN ASAP
   $Method = "POST";
} else {
   $buffer = $ENV{'QUERY_STRING'};
   $Method = "GET";
}
$bufsav = $buffer;
print "Method = $Method";

@pairs = split(/&/, $buffer);

foreach $pair (@pairs) {
   ($name, $value) = split(/=/, $pair);

   # Un-Webify plus signs and %-encoding
   $value = "(NULL)" if (!$value);
   $value =~ tr/+/ /;
   $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
   $value =~ s/<!--(.|\n)*-->//g;
#   $FORM{$name} = $value;
   print "<tr><td>$name</td><td>$value</td></tr>\n";
}
#    while (($key,$value) = each %FORM) {
#      $idx++;
#      $value = "N/A" if $value eq "";
#      print "<tr><td>$idx: $key</td><td>$value</td></tr>\n";
#        }
print "</table>\n";
print "<hr><h3>Raw CGI input</h3>$bufsav<hr>\n";
print "<h3>\$ENV dump</h3>\n";
print "<table border=1>\n";
while (($key,$value) = each %ENV) {
        $value = "(N/A)" if !($value);
        print "<td>$key<td> $value<tr>\n";
    }
print "</TABLE>\n";
