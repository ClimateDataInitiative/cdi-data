#!perl -w
#binmode STDOUT, ":encoding(UTF-8)";
 use utf8;
use Text::Unidecode;
while (<DATA>) {
	chomp;
	$Ct++;
	$In = $_;
	$X = unidecode($In);
	if ($In ne $X) {
		print "\n$Ct:\n[$In]\n[$X]\n";
	}
}
__DATA__
Definition
Health is a state of complete physical, mental and social well-being and not merely the absence of disease or infirmity.
Illnesses that are transmitted by vectors. “Vector-borne diseases are illnesses caused by pathogens and parasites in human populations….Vector-borne diseases account for over 17% of all infectious diseases. Distribution of these diseases is determined by a complex dynamic of environmental and social factors.” 
Responds to vector-borne diseases include: providing the best evidence for controlling vectors and protecting people against infection; providing technical support and guidance to countries so that they can effectively manage cases and outbreaks; supporting countries to improve their reporting systems and capture the true burden of the disease; providing training on clinical management, diagnosis and vector control with some of its collaborating centres throughout the world; and developing new tools to combat the vectors and deal with the disease, for example insecticide products and spraying technologies.

Planning  is the process of thinking about and organizing the activities required to achieve a desired goal.
A biological agent that causes disease or illness to its host.



The elimination or reduction of the frequency, magnitude, or severity of exposure to risks, or minimization of the potential impact of a threat or warning.




Something that gives official information to someone : the act of notifying someone

The degree to which a socio-economic system is either susceptible or resilient to the impact of natural hazards and related technological and environmental disasters. The degree of vulnerability is determined by a combination of several factors including hazard awareness, the condition of human settlements and infrastructure, public policy and administration, and organized abilities in all fields of disaster management. Poverty is also one of the main causes of vulnerability in most parts of the world.

Degree of likelihood that one or more exposures to a hazardous substance may have damaged or will damage the health of the exposed person(s).



"Specific group or subgroup that is more likely to be exposed, or is more sensitive to a certain substance than the general
population."
A minority is anyone who is not single-race white and not Hispanic.
Gender is the relations between men and women, both perceptual and material. 
The chronological age of 60 years or older.
 A 'child' is a person below the age of 18, unless the laws of a particular country set the legal age for adulthood younger.

Risks determined by socioeconomic status, which is commonly conceptualized as the social standing or class of an individualor group. It is often measured as a combination of education, income and occupation.
A housing unit is a house, apartment, group of rooms, or single room occupied or intended for occupancy as separate living quarters.
Condition where people's basic needs for food, clothing, and shelter are not being met.
The wealth of knowledge acquired by an individual after studying particular subject matters or experiencing life lessons that provide an understanding of something.

Factors that describe an organism such as: species type and reproduction rate.
Population size is the number of individuals in a population. 
Population density is the average number of individuals in a population per unit of area or volume. 
The average probability of survival and reproduction of the organisms of each generation of a species (population). The survival rate is measured by the ratio of the number of adults that reproduce to the number born in each generation (or the number of eggs de-posited, spawn laid, seeds ripened, and so forth).
Abundance is the number of organisms in a population, combining “intensity“ (density within inhabited areas) and “prevalence“ (number and size of inhabited areas)
The average number of persons infected by a single disease source; the number of expected secondary infections resulting from a single infectious case. This rate is affected by the duration of infectivity, infectiousness of the organism, and number of susceptible people with whom the infected person comes in contact.
A zoonotic disease is a disease that can be passed between animals and humans. Zoonotic diseases can be caused by viruses, bacteria, parasites, and fungi. 
Habitat availability is the accessibility and procurability of physical and biological components of a habitat by animals. 

Range is frequently used as the geographic extent of occurrence of an organism, without regard to fragmentation, or unlivable spaces within the total range extent; thus the term range is a purely a geometric or spatial concept.


Basic physical and organizational structures and facilities needed for the operation of society and enterprise.  Examples include buildings, roads and power supplies.
A hospital is a health care institution providing patient treatment with specialized staff and equipment.
In hydrologic terms, dam is any artificial barrier which impounds or diverts water and reservoir is a manmade facility for the storage, regulation and controlled release of water.
In hydrologic terms, the controlled application of water to arable lands to supply water requirements not satisfied by rainfall.
A place from which aircraft operate that usually has paved runways and maintenance facilities and often serves as a terminal

The fact or condition of being affected by something or experiencing something : the condition of being exposed to something.
The way a person can come into contact with a hazardous substance such as: inhalation, ingestion, or direct contact.
Serves as a disease vector.
Any of a family (Culicidae) of dipteran flies with females that have a set of slender organs in the proboscis adapted to puncture the skin of animals and to suck their blood and that are in some cases vectors of serious diseases.
Any of an order (Siphonaptera) of small wingless bloodsucking insects that have a hard laterally compressed body and legs adapted to leaping and that feed on warm-blooded animals
Any thing or place from which something comes, arises,or is obtained; origin


Geography of where exposure occurs.



The measured or measurable period during which an action, process, or condition exists or continues


"Biological, chemical, physical, or radiological substance
(normally absent in the environment) which, in sufficient concentration, can adversely affect living organisms through air, water, soil, and/or food. "
A biological agent that causes disease or illness to its host.
Lyme disease is caused by the bacterium Borrelia burgdorferi and is transmitted to humans through the bite of infected blacklegged ticks. 
Tickborne infections caused from several species of Rickettsia, the agent of spotted fever. Travelers should be aware of the risks. 
A disease caused from microscopic parasites that infect red blood cells that are transmitted by ticks. Babesiosis mainly occurs in parts of the Northeast and upper Midwest U.S. peaking during warm months. Many people do not experience symptoms, however some symptoms include fever, chills, sweats, headache, body aches, loss of appetite, nausea, or fatigue. Babesiosi can be a life-threatening disease in people who don’t have a spleen, have a weakened immune system, serious health conditions, or are elderly.
A disease caused by the Anaplasma phagocytophilium bacterium that is transmitted to humans by the bite of an infected ticks.   The black-legged tick (Ixodes scapularis) is the vector of A. phagocytophilum in the northeast and upper midwestern United States and the western black-legged tick (Ixodes pacificus) in Northern California. Symptoms begin within 1-2 weeks after the infected tick bite and include fever, headache, muscle pain, chills, malaise, cough, confusion, rash, and nausea/abdominal pain. Anaplasmosis is fatal if not treated correctly. 
Tularemia, also known as “rabbit fever,” is a disease caused by the bacterium Francisella tularensis. Tularemia is typically found in animals, especially rodents, rabbits, and hares. Tularemia is usually a rural disease and has been reported in all U.S. states except Hawaii.
 Virus transmitted to humans by infected mosquitoes occurring mostly in the eastern and central United States. Initial symptoms include fever, headache, nausea, vomiting, and tiredness.   Severe neuroinvasive disease (often involving encephalitis, an inflammation of the brain) occurs more commonly in older adults, and in rare cases, long-term disability or death can result.
A group of mosquito-borne arboviral infections including California encephalitis, Keystone, La Crosse, Jamestown Canyon, snowshoe hare, and trivittatus. 
A disease transmitted by infected mosquitoes that is the leading cause of illness and death in the tropics and subtropics.  Symptoms include high fever, severe headaches, severe pain behind the eyes, joint pain, muscle and bone pain, rash, and mild bleeding. Early recognition and treatment can substantially lower risk of medical complication and death
Illness caused by the parasite called Plasmodium, which is transmitted by infected mosquitoes. The parasite multiplies in the liver, moving on to infect red blood cells in the human body. Symptoms include fever, headache, and vomiting which appear between 10-15 days after exposure.
A zoonotic arbovirus belonging to the genus Flavivirus in the family Flaviviridae.
A virus transmitted to humans by infected ticks, with most U.S. cases occurring in the Northeast and Great Lakes Region.  Symptoms include fever, headache, vomiting, weakness, confusion, seizures, and memory  loss. There is no specific treatment, however severe cases often require hospitalization.
A rare illness transmitted to humans by  the bite of an infected mosquitos, with only a few cases reported each year in the United States; most cases occur in Atlantic and Gulf Coast states.  Most persons infected with this virus have no apparent illness, however severe cases begin with sudden  onset of  headache, high fever, chills, and vomiting, which may then progress into disorientation, seizures, or coma. EEE is one of the most severe mosquito-transmitted diseases in the United States with approximately 33% mortality and significant brain damage in most survivors. There is no specific treatment for EEE; care is based on symptoms.
 Murine typhus, also known as "endemic typhus," "Mexican typhus," and "flea-borne typhus," is a flea-borne infection of humans worldwide. Symptoms are similar to those of epidemic typhus fever (transmitted by the human body louse), but typically much less severe. If untreated, patients with murine typhus can require hospitalization, but the case fatality rate is only about 2% in the U.S. However, travelers to Asia and African should note that the case fatality rate is thought to approach 70% in certain areas in which murine typhus occurs.  
Plague is a bacterial disease, caused by Yersinia pestis, which primarily affects wild rodents.Bubonic plague is the most common form of plague and is caused by the bite of an infected flea. Plague bacillus, Y. pestis, enters at the bite and travels through the lymphatic system to the nearest lymph node where it replicates itself. The lymph node then becomes inflamed, tense and painful, and is called a "bubo". At advanced stages of the infection the inflamed lymph nodes can turn into suppurating open sores. 
Septicaemic plague occurs when infection spreads directly through the bloodstream without forming a “bubo". Septicaemic plague may result from flea bites and from direct contact with infective materials through cracks in the skin. Advanced stages of the bubonic form of plague will also lead to direct spread of Y. pestis in the blood.
Pneumonic plague-or lung-based plague- is the most virulent and least common form of plague. Typically, the pneumonic form is caused by spread to the lungs from advanced bubonic plague. However, a person with secondary pneumonic plague may form aerosolized infective droplets and transmit plague via droplets to other humans. Untreated pneumonic plague has a very high case-fatality ratio. 

Natural hazards are severe and extreme weather and climate events that occur naturally in all parts of the world, although some regions are more vulnerable to certain hazards than others. Natural hazards become natural disasters when people’s lives and livelihoods are destroyed.
Any high flow, overflow, or inundation by water which causes or threatens damage.
Drought is a deficiency of moisture that results in adverse impacts on people, animals, or vegetation over a sizeable area.
A tropical cyclone in the Atlantic, Caribbean Sea, Gulf of Mexico, or eastern Pacific, which the maximum 1-minute sustained surface wind is 64 knots (74 mph) or greater.
Observations or calculations that can be used to track conditions and trends that communicates key aspects of the changing environment, point out vulnerabilities, and inform decisions about policy, planning, and resource management. Terms encompass factors that describe the land surface, atmosphere, and oceans. 
The measure of  internal energy a substance contains. 
The process where water vapor condenses in the atmosphere to form water droplets that fall to the Earth as rain, sleet, snow, hail, etc.
General measure of the water vapor content if the air, and is popularly used synonymously with relative humidity.


