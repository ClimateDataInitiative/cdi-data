#!perl -w

#  Rudimentary scheduler, ugly as a camel, but it works!

use vcfw;
$LastRun= "Never";
$Doit = "c:\\gg\\main\\snarfgcis.bat";
$Doit = $ARGV[0];		# Command to be executed
$When = $ARGV[1];		# When to Do it, HHMM format
$Delay = 55;   #Seconds between checks

if ($Doit eq "") {
   die "Format: $0 [command] [time]\n(Time in HHMM)\n";
}
if ($When eq "") {
   die "Format: $0 [command] [time]\n(Time in HHMM)\n";
}
print<<EOM;
Delay   : $Delay
Command : $Doit
When    : $When
======================================
EOM
system "title $When";
while () {	#Run til Cows come home
GenDTG();   #Gen Time Variables
$Now = $HH.$MN;
if ($Now eq $When) {
	print "$DTG2 Start executing [$Doit]\n";
	$LastRun = $DTG;
	system $Doit;
	GenDTG();
	$Snooze = 90;
	print "$DTG2 Finish executing [$Doit], sleeping $Snooze seconds\n";
	sleep($Snooze);
	} else {
	print "$DTG2: Snoozing for $Delay seconds, Last run time:[$LastRun] Next Run:[$When] \n"; 
	sleep($Delay);
	}
}
print "WTF?\n";

