while (<DATA>) {
	chomp;
	$Var = $_;
#	print<<EOM;
#my \$My_$Var = \$rowhash->{'$Var'};
#EOM
print<<EOM;
my \$My_$Var = "";
EOM
}
__DATA__
identifier
context_identifier
term
description
is_root
url
blank1
blank2
blank3
blank4
mesh_description
mesh_url
meshid
