#!perl.exe -w
$|=1;
use vcfw;
use JSON;
use Data::Dumper;
GenDTG();
$F1 = "c:\\db\\gsfc\\json.txt";
#$F1 = 'c:\temp\snarf_151020_134350.json';
#$F1 = $ARGV[0];
open (IN,"<",$F1) || die "Choke on open $F1:$!\n";
$json_text=(<IN>);
close(IN);
$json = JSON->new->allow_nonref;
$perl_scalar = $json->decode( $json_text );
@MyKeys = ${$perl_scalar}{'keyword'};
#@MyKeys = ($json->decode( $json_text )){'keyword'};
$Hit = Dumper(@MyKeys);
print "Hit= >>>$Hit<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n";
foreach (@MyKeys) {
	print "XXX [$_]\n";
}

@MyArray= split("\n",$Hit);
foreach (@MyArray) {
	chomp;
	$Hit1 = trim($_);
	if (($Hit1 ne "\$VAR1 = [" ) && ($Hit1 ne "];")) {
#		$Hit1 =~ s/'//g;
#		$Hit1 =~ s/,//g;
		$KeyStr .= $Hit1;
	}
}
#$KeyStr =~ s/,$//;
print "$DTG2\n[$KeyStr]\n\n";

