#!perl -w
use JSON;
use Data::Dumper::Names;

$F1 = "c:\\db\\gsfc\\json.txt";
open (IN,"<",$F1) || die "Choke on open $F1:$!\n";
$json_text=(<IN>);

my @decoded_json = decode_json($json_text);
print Dumper(@decoded_json),"XXX ", scalar(@decoded_json), " xxx\n";

foreach my $n (@decoded_json) {
	$X++;
#	print "$X [$n]\n";

while (($key,$value) = each %n) {
	print "<td>$key<td> $value<tr>\n";
}


}
