use vcfw;
$F1 = 'C:\bb-save\Backup\BlackBerry\ringtones\ringtones.dat';
$F2 = "c:/home/wincingdevil/public_html/ringtones/index.html";
$F1='c:\wv\newsclinks.txt';
$F2='c:\wv\newsclinks.htm';
$F1 = 'c:\db\gsfc\RFPLinks.txt';
$F2 = 'c:\db\gsfc\RFPLinks.htm';


open (IN,"<$F1") || die "choke on open $F1:$!\n";
open (OUT,">$F2") || die "choke on open $F1:$!\n";
print OUT<<EOM;
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>FB PEEPS</TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="Vince Wilding">
<META NAME="Keywords" CONTENT="peeps">
<META NAME="Description" CONTENT="FB Peeps">
</HEAD>
<BODY>
<UL>
EOM


while (<IN>) {
	chomp;
	$D = $_;
    ($Verb,$Link) = split (/\t/,$D);
	$Verb = trim($Verb);
	$Link = trim($Link);
	print OUT "<br>$Verb:  <a href=\"$Link\">$Link</B></a>\n";
}
close IN;
print OUT<<EOM;
</ul>
</BODY>
</HTML>
EOM

close OUT;
system "%ED% $F2";
