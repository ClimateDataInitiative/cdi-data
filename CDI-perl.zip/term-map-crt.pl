#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\load-term-map-crt.sql";
$Relationship = "Throw this away";
$SqlStatement="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
while (<DATA>) 	{
	chomp;
#	Term	Relationship	CaseStudy	extURI	Tools	extURI
$Ignore=<<EOM;
Health|||http://toolkit.climate.gov/taking-action?f[0]=field_parent_topic%3A116||http://toolkit.climate.gov/tools||||||||||||||||||||
Vector Borne Disease|||||||||||||||||||||||||
Response||Charting Colorado�s Vulnerability to Climate Change|http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change|Disaster Behavioral Health Information Series|http://toolkit.climate.gov/tool/disaster-behavioral-health-information-series||||||||||||||||||||
Response||||Ready Campaign|http://toolkit.climate.gov/tool/ready-campaign||||||||||||||||||||
Response||||Vermont Tick Tracker|http://toolkit.climate.gov/tool/vermont-tick-tracker||||||||||||||||||||
Response||||Community Health Resilience Guide and Toolset|http://toolkit.climate.gov/tool/community-health-resilience-guide-and-toolset||||||||||||||||||||
Response||||Sustainable and Climate-Resilient Health Care Facilities Toolkit|http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit||||||||||||||||||||
Planning||||Ready Campaign|http://toolkit.climate.gov/tool/ready-campaign||||||||||||||||||||
EOM
	($Term,$Relationship,$CaseStudy,$CS_URI,$Tools,$Tools_URI) = split(/\|/);
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term eq "") {
		$ThisTerm = $OldTerm
	} else {
		$ThisTerm = $OldTerm = $Term;
	}
	$CaseStudy = trim($CaseStudy);
	$CaseStudy =~ s/'/''/g;		#Escape single quotes
	$CaseStudy =~ s/\x92/''/g;  #Fix UTF8 quote
	$CaseStudy =~ s/\x97/\-/g;  #Fix UTF8 dash
	if ($CaseStudy eq "") {
		$CaseStudy= "N/A";
	}
	$Tools = trim($Tools);
	$Tools =~ s/'/''/g;		#Escape single quotes
	$Tools =~ s/\x92/''/g;  #Fix UTF8 quote
	$Tools =~ s/\x97/\-/g;  #Fix UTF8 dash

	if ($Tools eq "") {
		$Tools= "N/A";
	}

	$CS_URI= trim($CS_URI);
	if ($CS_URI eq "") {
		$CS_URI= "N/A";
	}

	$Tools_URI= trim($Tools_URI);
	if ($Tools_URI eq "") {
		$Tools_URI= "N/A";
	}
	if ($CaseStudy ne "N/A") {
		$SqlStatement =<<EOM;
INSERT INTO term_map (term_id, relationship, gcid, description) VALUES ((SELECT s.id FROM term AS s WHERE s.term = '$ThisTerm' and s.lexicon_identifier = 'cdi'), 'hasCaseStudy', '$CS_URI', '$CaseStudy');
EOM
		print OUT "$SqlStatement";
	}
	if ($Tools ne "N/A") {
		$SqlStatement =<<EOM;
INSERT INTO term_map (term_id, relationship, gcid, description) VALUES ((SELECT s.id FROM term AS s WHERE s.term = '$ThisTerm' and s.lexicon_identifier = 'cdi'), 'hasAnalysisTool', '$Tools_URI', '$Tools');
EOM
		print OUT "$SqlStatement";
	}
}
close OUT;
system "$ENV{'ED'} $F1"
#Subject	Predicate	Relationship	Object
#Term	Relationship	Datasets	extURI		


#Term	Relationship	CaseStudy	extURI	Tools	extURI																				
__DATA__
Health|||http://toolkit.climate.gov/taking-action?f[0]=field_parent_topic%3A116||http://toolkit.climate.gov/tools||||||||||||||||||||
Vector Borne Disease|||||||||||||||||||||||||
Response||Charting Colorado�s Vulnerability to Climate Change|http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change|Disaster Behavioral Health Information Series|http://toolkit.climate.gov/tool/disaster-behavioral-health-information-series||||||||||||||||||||
Response||||Ready Campaign|http://toolkit.climate.gov/tool/ready-campaign||||||||||||||||||||
Response||||Vermont Tick Tracker|http://toolkit.climate.gov/tool/vermont-tick-tracker||||||||||||||||||||
Response||||Community Health Resilience Guide and Toolset|http://toolkit.climate.gov/tool/community-health-resilience-guide-and-toolset||||||||||||||||||||
Response||||Sustainable and Climate-Resilient Health Care Facilities Toolkit|http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit||||||||||||||||||||
Planning||||Ready Campaign|http://toolkit.climate.gov/tool/ready-campaign||||||||||||||||||||
Planning||||Community Health Resilience Guide and Toolset|http://toolkit.climate.gov/tool/community-health-resilience-guide-and-toolset||||||||||||||||||||
Planning||||Tribal-Focused Environmental Risk and Sustainability Tool (Tribal-FERST)|http://toolkit.climate.gov/tool/tribal-focused-environmental-risk-and-sustainability-tool-tribal-ferst||||||||||||||||||||
Planning||||Social Vulnerability Index|http://toolkit.climate.gov/tool/social-vulnerability-index||||||||||||||||||||
New pathogen|||||||||||||||||||||||||
Global travel|||||||||||||||||||||||||
Global trade|||||||||||||||||||||||||
Urban growth|||||||||||||||||||||||||
Mitigation||||Metadata Access Tool for Climate and Health (MATCH)|http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match||||||||||||||||||||
Mitigation||||Tribal-Focused Environmental Risk and Sustainability Tool (Tribal-FERST)|http://toolkit.climate.gov/tool/tribal-focused-environmental-risk-and-sustainability-tool-tribal-ferst||||||||||||||||||||
Mitigation||||Vermont Tick Tracker|http://toolkit.climate.gov/tool/vermont-tick-tracker||||||||||||||||||||
Water management practices|||||||||||||||||||||||||
Control Methods (pesticides)|||||||||||||||||||||||||
Vector surveillance||||Disease Maps|http://toolkit.climate.gov/tool/disease-maps||||||||||||||||||||
Vector surveillance||||Vermont Tick Tracker|http://toolkit.climate.gov/tool/vermont-tick-tracker||||||||||||||||||||
Land use practices|||||||||||||||||||||||||
Notification||||Ready Campaign|http://toolkit.climate.gov/tool/ready-campaign||||||||||||||||||||
Human Vulnerability||Charting Colorado�s Vulnerability to Climate Change|http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change|Assessing Health Vulnerability to Climate Change: A Guide for Health Departments|http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments||||||||||||||||||||
Human Vulnerability||||Social Vulnerability Index|http://toolkit.climate.gov/tool/social-vulnerability-index||||||||||||||||||||
Health Risks||||Assessing Health Vulnerability to Climate Change: A Guide for Health Departments|http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments||||||||||||||||||||
Health Risks||||Tribal-Focused Environmental Risk and Sustainability Tool (Tribal-FERST)|http://toolkit.climate.gov/tool/tribal-focused-environmental-risk-and-sustainability-tool-tribal-ferst||||||||||||||||||||
Outdoor activity||||Lyme Disease Communications Toolkit|http://toolkit.climate.gov/tool/lyme-disease-communications-toolkit||||||||||||||||||||
Outdoor employment||||Lyme Disease Communications Toolkit|http://toolkit.climate.gov/tool/lyme-disease-communications-toolkit||||||||||||||||||||
Population at risk||Charting Colorado�s Vulnerability to Climate Change|http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change|Social Vulnerability Index|http://toolkit.climate.gov/tool/social-vulnerability-index||||||||||||||||||||
Minorities||||EJSCREEN: Environmental Justice Screening and Mapping Tool|http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool||||||||||||||||||||
Sex/Gender|||||||||||||||||||||||||
Elderly||Charting Colorado�s Vulnerability to Climate Change|http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change|EJSCREEN: Environmental Justice Screening and Mapping Tool|http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool||||||||||||||||||||
Children||||EJSCREEN: Environmental Justice Screening and Mapping Tool|http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool||||||||||||||||||||
Socio-economic risk factors||||Social Vulnerability Index|http://toolkit.climate.gov/tool/social-vulnerability-index||||||||||||||||||||
Housing||||Social Vulnerability Index|http://toolkit.climate.gov/tool/social-vulnerability-index||||||||||||||||||||
Poverty||Charting Colorado�s Vulnerability to Climate Change|http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change|Social Vulnerability Index|http://toolkit.climate.gov/tool/social-vulnerability-index||||||||||||||||||||
Education|||||||||||||||||||||||||
Biological Variables|||||||||||||||||||||||||
Population size|||||||||||||||||||||||||
Population density|||||||||||||||||||||||||
Survival rates|||||||||||||||||||||||||
Host Abundance|||||||||||||||||||||||||
Pathogen Reproduction rate|||||||||||||||||||||||||
Zoonotic carriers|||||||||||||||||||||||||
Habitat availability|||||||||||||||||||||||||
Host Reproduction Rates|||||||||||||||||||||||||
Habitat Range|||||||||||||||||||||||||
Migration patterns|||||||||||||||||||||||||
Infrastructure|||||||||||||||||||||||||
Hospital|||||||||||||||||||||||||
Dams and Reservoirs|||||||||||||||||||||||||
Irrigation|||||||||||||||||||||||||
Airports|||||||||||||||||||||||||
Exposure||||Tribal-Focused Environmental Risk and Sustainability Tool (Tribal-FERST)|http://toolkit.climate.gov/tool/tribal-focused-environmental-risk-and-sustainability-tool-tribal-ferst||||||||||||||||||||
Pathway|||||||||||||||||||||||||
Ticks||||Disease Maps|http://toolkit.climate.gov/tool/disease-maps||||||||||||||||||||
Ticks||||Vermont Tick Tracker|http://toolkit.climate.gov/tool/vermont-tick-tracker||||||||||||||||||||
Ticks||||Lyme Disease Communications Toolkit|http://toolkit.climate.gov/tool/lyme-disease-communications-toolkit||||||||||||||||||||
Mosquitoes||||Disease Maps|http://toolkit.climate.gov/tool/disease-maps||||||||||||||||||||
Fleas||||Disease Maps|http://toolkit.climate.gov/tool/disease-maps||||||||||||||||||||
Source|||||||||||||||||||||||||
Birds||||Disease Maps|http://toolkit.climate.gov/tool/disease-maps||||||||||||||||||||
Rodents|||||||||||||||||||||||||
Location||||Vermont Tick Tracker|http://toolkit.climate.gov/tool/vermont-tick-tracker||||||||||||||||||||
Geographic Distribution||||Vermont Tick Tracker|http://toolkit.climate.gov/tool/vermont-tick-tracker||||||||||||||||||||
Proximity to water|||||||||||||||||||||||||
Urban|||||||||||||||||||||||||
Time|||||||||||||||||||||||||
Vector Seasonal Activity|||||||||||||||||||||||||
Contaminants|||||||||||||||||||||||||
Pathogens||||Disease Maps|http://toolkit.climate.gov/tool/disease-maps||||||||||||||||||||
Pathogens||||Metadata Access Tool for Climate and Health (MATCH)|http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match||||||||||||||||||||
Lyme disease||||Lyme Disease Communications Toolkit|http://toolkit.climate.gov/tool/lyme-disease-communications-toolkit||||||||||||||||||||
Lyme disease||||Vermont Tick Tracker|http://toolkit.climate.gov/tool/vermont-tick-tracker||||||||||||||||||||
Spotted Fever Rickettsia||||Metadata Access Tool for Climate and Health (MATCH)|http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match||||||||||||||||||||
Babesiosis|||||||||||||||||||||||||
Anaplasmosis/Ehrlichiosis||||Metadata Access Tool for Climate and Health (MATCH)|http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match||||||||||||||||||||
Tularemia||||Metadata Access Tool for Climate and Health (MATCH)|http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match||||||||||||||||||||
St. Louis encephalitis||||Disease Maps|http://toolkit.climate.gov/tool/disease-maps||||||||||||||||||||
St. Louis encephalitis||||Metadata Access Tool for Climate and Health (MATCH)|http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match||||||||||||||||||||
California Serogroup Viruses|||||||||||||||||||||||||
Dengue||||Disease Maps|http://toolkit.climate.gov/tool/disease-maps||||||||||||||||||||
Dengue||||Metadata Access Tool for Climate and Health (MATCH)|http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match||||||||||||||||||||
Malaria||||Metadata Access Tool for Climate and Health (MATCH)|http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match||||||||||||||||||||
West Nile Virus||Charting Colorado�s Vulnerability to Climate Change|http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change|Disease Maps|http://toolkit.climate.gov/tool/disease-maps||||||||||||||||||||
West Nile Virus||||Metadata Access Tool for Climate and Health (MATCH)|http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match||||||||||||||||||||
Powassan||||Disease Maps|http://toolkit.climate.gov/tool/disease-maps||||||||||||||||||||
Powassan||||Metadata Access Tool for Climate and Health (MATCH)|http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match||||||||||||||||||||
Eastern Equine Encephalitis||||Disease Maps|http://toolkit.climate.gov/tool/disease-maps||||||||||||||||||||
Murine Typhus|||||||||||||||||||||||||
Bubonic Plague|||||||||||||||||||||||||
Septicemic Plague|||||||||||||||||||||||||
Pneumonic Plague|||||||||||||||||||||||||
Natural Hazard||||Emergency Preparedness and Response: Natural Disasters and Severe Weather|http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather||||||||||||||||||||
Natural Hazard||||NOAA's Weather and Climate Toolkit|http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit||||||||||||||||||||
Flooding|||||||||||||||||||||||||
Flooding||||Hazus-MH|http://toolkit.climate.gov/tool/hazus||||||||||||||||||||
Flooding||||FEMA Flood Map Service Center|http://toolkit.climate.gov/tool/fema-flood-map-service-center||||||||||||||||||||
Flooding||||Emergency Preparedness and Response: Natural Disasters and Severe Weather|http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather||||||||||||||||||||
Flooding||||Climate Outlooks|http://toolkit.climate.gov/tool/climate-outlooks||||||||||||||||||||
Flooding||||Disaster Behavioral Health Information Series|http://toolkit.climate.gov/tool/disaster-behavioral-health-information-series||||||||||||||||||||
Flooding||||NOAA's Weather and Climate Toolkit|http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit||||||||||||||||||||
Drought||Charting Colorado�s Vulnerability to Climate Change|http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change|NOAA's Weather and Climate Toolkit|http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit||||||||||||||||||||
Drought||||Climate at a Glance|http://toolkit.climate.gov/tool/climate-glance||||||||||||||||||||
Drought||||Climate Outlooks|http://toolkit.climate.gov/tool/climate-outlooks||||||||||||||||||||
Drought||||Disaster Behavioral Health Information Series|http://toolkit.climate.gov/tool/disaster-behavioral-health-information-series||||||||||||||||||||
Drought||||U.S. Drought Portal|http://toolkit.climate.gov/tool/us-drought-portal||||||||||||||||||||
Hurricane||||Historical Hurricane Tracks|http://toolkit.climate.gov/tool/historical-hurricane-tracks||||||||||||||||||||
Hurricane||||Emergency Preparedness and Response: Natural Disasters and Severe Weather|http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather||||||||||||||||||||
Hurricane||||Disaster Behavioral Health Information Series|http://toolkit.climate.gov/tool/disaster-behavioral-health-information-series||||||||||||||||||||
Hurricane||||Hazus-MH|http://toolkit.climate.gov/tool/hazus||||||||||||||||||||
Hurricane||||HURREVAC|http://toolkit.climate.gov/tool/hurrevac||||||||||||||||||||
Hurricane||||NOAA's Weather and Climate Toolkit|http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit||||||||||||||||||||
Climate Indicators||||Climate at a Glance|http://toolkit.climate.gov/tool/climate-glance||||||||||||||||||||
Climate Indicators||||Cal-Adapt|http://toolkit.climate.gov/tool/cal-adapt||||||||||||||||||||
Temperature||Charting Colorado�s Vulnerability to Climate Change|http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change|Climate Explorer�Visualize Climate Data in Maps and Graphs|http://toolkit.climate.gov/tools/climate-explorer||||||||||||||||||||
Temperature||||Climate at a Glance|http://toolkit.climate.gov/tool/climate-glance||||||||||||||||||||
Temperature||||Climate Outlooks|http://toolkit.climate.gov/tool/climate-outlooks||||||||||||||||||||
Temperature||||Local Climate Analysis Tool (LCAT)|http://toolkit.climate.gov/tool/local-climate-analysis-tool-lcat||||||||||||||||||||
Temperature||||Cal-Adapt|http://toolkit.climate.gov/tool/cal-adapt||||||||||||||||||||
Temperature||||Cities Impacts & Adaptation Tool (CIAT)|http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat||||||||||||||||||||
Precipitation||||Climate Explorer�Visualize Climate Data in Maps and Graphs|http://toolkit.climate.gov/tools/climate-explorer||||||||||||||||||||
Precipitation||||Climate at a Glance|http://toolkit.climate.gov/tool/climate-glance||||||||||||||||||||
Precipitation||||Climate Outlooks|http://toolkit.climate.gov/tool/climate-outlooks||||||||||||||||||||
Precipitation||||Local Climate Analysis Tool (LCAT)|http://toolkit.climate.gov/tool/local-climate-analysis-tool-lcat||||||||||||||||||||
Precipitation||||Cal-Adapt|http://toolkit.climate.gov/tool/cal-adapt||||||||||||||||||||
Precipitation||||Cities Impacts & Adaptation Tool (CIAT)|http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat||||||||||||||||||||
Humidity||||Cal-Adapt|http://toolkit.climate.gov/tool/cal-adapt||||||||||||||||||||
