#!/usr/bin/env perl -w
# Reads CSV output of EXCEL spreadsheet, replaces newlines with spaces, formats into SQL statement

use strict;
use warnings;
use Text::CSV_XS;
#my $Path = "c:\\gg\\main\\vcfw\\";
my $Path = "c:\\db\\gsfc\\";
my $DoWrite =1;
#my $FileNameRoot = "TermRelationship_vector_borne_11_20";
#my $FileNameRoot = "TermRelationship_vector_borne_12_22";
my $FileNameRoot = "Terms_12_22";

my $InputFile  = $Path.$FileNameRoot.".csv";
my $OutputFile = $Path.$FileNameRoot.".sql";
#my $Edit = $ENV{'ED'};
my $Edit = "c:\\progra~2\\editpl~1\\editplus.exe";
my $ThisValue = "";
my $ThisColumn = "";
my $Context= "theme";
#my $DeleteMe = '"","vcfw-cdi-context-id","","","","","",""';   #Delete Blank Lines
#my $DeleteMe = '"","vcfw-cdi-context-id","","","",""';
my $DeleteMe =<<EOM;
"$Context","","","",""
EOM
; #Skip termid, let it default
my $OutCount=0;
my $InputLineNumber = 1;
open (my $CSV_FH, "<",$InputFile) or die "choke on open input $InputFile: $!";
open (OUT_FH, ">",$OutputFile) or die "choke on open output $OutputFile: $!";

my $csv = Text::CSV_XS->new ( { binary => 1 } )    #binary for mulitline fields
           or die "Cannot use Text::CSV " . Text::CSV->error_diag ();

$csv->column_names ($csv->getline($CSV_FH));    #define column names from first line

while (my $rowhash = $csv->getline_hr($CSV_FH)) { # Loop thru file
	my $InsertNames = "";
	my $InsertValues = "";
	$InputLineNumber++;
	$DoWrite = 1;         #Write only if term is not blank
	foreach my $field ($csv->column_names) {      #column names in order    #Begin processing line of input
		$ThisColumn = $field;
		$ThisValue = $rowhash->{$field};
		$ThisValue =~ s/\n/ /g;
		#Special Handling for Special Columns
		if ($ThisColumn eq "contextid") {	# need to link to Context.ID
			$ThisValue = "$Context";	# PlaceHolder
		}
		if ($ThisColumn eq "definition") {
			$ThisValue =~ s/"/'/g;		#Double Quotes to single quotes
		}
		if (($ThisColumn eq "term") && ($ThisValue eq "")) {
			$DoWrite=0;
			$OutCount--;
		}
		if ($ThisColumn eq "termid") {
			$OutCount++;
			$InsertNames .= "lexicon,"; #Skip termid, let it default (was "$ThisColumn,";)
			$InsertValues .= "\"CDI\","; ; #Skip termid, let it default (was "$ThisValue,";)
				} else {
			$InsertNames .= "$ThisColumn,";
			$InsertValues .= "\"$ThisValue\",";
		}
	}	#End of processing for current row
	$InsertNames =~ s/,$//;		#delete final comma
	$InsertValues =~ s/,$//;	#delete final comma
	if ($DoWrite) {
		print OUT_FH<<EOM;
INSERT INTO TERM ($InsertNames) VALUES ($InsertValues);
EOM
	}  #-- Input Line: $InputLineNumber

}
close $CSV_FH;
close OUT_FH;
system "$Edit $InputFile $OutputFile";
