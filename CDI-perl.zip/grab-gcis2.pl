#!/usr/bin/perl -w
require "/home/content/w/i/n/wincingdevil/cgi/vcfw.pm";
$LogFile= "/home/content/w/i/n/wincingdevil/html/grab-gcis.txt";
open (LOG,">>",$LogFile) || die "Choke on open $LogFile: $!\n";
$DTG2= DTGhr();
print LOG "$DTG2 Start Log Entry***\n";
#$Recipients = "webadmin\@seawifs.gsfc.nasa.gov,systems\@seawifs.gsfc.nasa.gov";
$Recipients = "vincent.c.wilding\@nasa.gov,vince\@vincewilding.com";
while (<DATA>) {
	chomp;
	$url1 = $_;
	$DTG2= DTGhr();
	$Results = "";
	print LOG "$DTG2 $url1... ";
	$Cmd = "/usr/bin/curl -I " . $url1. " 2>/dev/null "; 
	$Results = `$Cmd`;
	if ((!($Results =~ /200 OK/)) && (!($Results =~ /301 Moved Permanently/))) {
		$DTG2= DTGhr();
		$Subject = "Server Down: $url1 [$DTG2]";
		print LOG "\n$DTG2 $url1 appears to be Down\n***\n[$Results]\n***\n";
		print "Sending Message\n";
		system "perl ~/cgi/email.pl  $Recipients \"$Subject\" \"$Subject\"";
		#system "echo \"curl -I $url1 says:\n[$Results]\"|/usr/bin/mail -t $Recipients -s $Subject";  #This failed, and the notice didn't go out.
		print "Sent Message\n";

	} else {
		print LOG "OK\n"
	}
}
$DTG2= DTGhr();
print LOG "$DTG2 All done ***\n";
close LOG;
#webadmin\@oceancolor.gsfc.nasa.gov
#oceancolordev.domain.pub/cms/
#oceandev101.domain.pub/cms/
#perl ~/cgi/email.pl daleandvince@gmail.com,vince@vincewilding.com "test of email script (subj)" "test body of message"

__DATA__
cdi-gcis-vwilding.c9.io
