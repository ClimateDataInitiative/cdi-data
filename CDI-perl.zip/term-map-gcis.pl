#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\load-term-map-gcis.sql";
$SqlStatement="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
while (<DATA>) 	{
	chomp;
	#Term	Relationship	Datasets	extURI
	($Term,$Relationship,$Dataset,$URI) = split(/\|/);
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term eq "") {
		$ThisTerm = $OldTerm
	} else {
		$ThisTerm = $OldTerm = $Term;
	}
	$Relationship = trim($Relationship);
	if ($Relationship eq "") {
		$Relationship= "N/A";
	}
	$Dataset = trim($Dataset);
	if ($Dataset eq "") {
		$Dataset= "N/A";
	}
	$Dataset =~ s/'/''/g;		#Escape single quotes
	$Dataset =~ s/\x92/''/g;  #Fix UTF8 quote
	$Dataset =~ s/\x97/\-/g;  #Fix UTF8 dash
	$Dataset =~ s/\x96/\-/g;  #Fix UTF8 hyphen

	$URI= trim($URI);
	if ($URI eq "") {
		$URI= "N/A";
	}
	$SqlStatement =<<EOM;
INSERT INTO term_map (term_id, relationship, gcid, description) VALUES ((SELECT s.id FROM term AS s WHERE s.term = '$ThisTerm' and s.lexicon_identifier='cdi'), '$Relationship', '$URI', '$Dataset');
EOM
	print OUT "$SqlStatement";
}
close OUT;
system "$ENV{'ED'} $F1"

#Term	Relationship	Datasets	extURI
__DATA__
Health|||
Vector Borne Disease|isMentionedIn|Chapter 5 : Vector-Borne Diseases|file/d6ba04bc-c9d8-4663-8d07-5887161e96b4
Response|isMentionedIn|Texas lifestyle limits transmission of dengue virus (e4eeb858)|article/10.3201/eid0901.020220
Response|isMentionedIn|Dengue outbreak in Key West, Florida, USA, 2009 (c00f6a68)|article/10.3201/eid1801.110130
Planning|||
New pathogen|isMentionedIn|Climate and Vectorborne Diseases (cc7c424e)|article/10.1016/j.amepre.2008.08.030
New pathogen|isMentionedIn|Microbial Threats to Health: Emergence, Detection, and Response (6a97bff6)|report/iom--microbial-2003
Global travel|isMentionedIn|Dengue outbreak in Key West, Florida, USA, 2009 (c00f6a68)|article/10.3201/eid1801.110130
Global trade|isMentionedIn|Dengue outbreak in Key West, Florida, USA, 2009 (c00f6a68)|article/10.3201/eid1801.110130
Urban growth|isMentionedIn|Local impact of temperature and precipitation on West Nile virus infection in Culex species mosquitoes in northeast Illinois, USA (5bd8de26)|article/10.1186/1756-3305-3-19
Mitigation|isMentionedIn|Dengue outbreak in Key West, Florida, USA, 2009 (c00f6a68)|article/10.3201/eid1801.110130
Mitigation|isMentionedIn|Assessing the roles of temperature, precipitation, and ENSO in dengue re-emergence on the Texas-Mexico border region (10d79a4e)|article/10.1590/S0036-36342008000300006
Mitigation|isMentionedIn|Epidemic dengue and dengue hemorrhagic fever at the Texas�Mexico border: Results of a household-based seroepidemiologic survey, December 2005 (10973e71)|article/pmid-18337327
Mitigation|isMentionedIn|Texas lifestyle limits transmission of dengue virus (e4eeb858)|article/10.3201/eid0901.020220
Mitigation|isMentionedIn|webpage The Noun Project|webpage/0eb8d282-b65b-436e-9649-b953bc20b60b
Mitigation|isMentionedIn|Humans|image/513fdc60-524e-468d-8ce3-9a5b4795d2a9
Mitigation|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Water management practices|isMentionedIn|Impact of climate variation on mosquito abundance in California (c3fa0d45)|article/10.3376/1081-1710(2008)33%5B89:iocvom%5D2.0.co;2
Control Methods (pesticides)|isMentionedIn|Dengue outbreak in Key West, Florida, USA, 2009 (c00f6a68)|article/10.3201/eid1801.110130
Control Methods (pesticides)|isMentionedIn|Assessing the roles of temperature, precipitation, and ENSO in dengue re-emergence on the Texas-Mexico border region (10d79a4e)|article/10.1590/S0036-36342008000300006
Control Methods (pesticides)|isMentionedIn|Epidemic dengue and dengue hemorrhagic fever at the Texas�Mexico border: Results of a household-based seroepidemiologic survey, December 2005 (10973e71)|article/pmid-18337327
Control Methods (pesticides)|isMentionedIn|Texas lifestyle limits transmission of dengue virus (e4eeb858)|article/10.3201/eid0901.020220
Control Methods (pesticides)|isMentionedIn|webpage The Noun Project|webpage/0eb8d282-b65b-436e-9649-b953bc20b60b
Control Methods (pesticides)|isMentionedIn|Humans|image/513fdc60-524e-468d-8ce3-9a5b4795d2a9
Control Methods (pesticides)|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Vector surveillance|isMentionedIn|Texas lifestyle limits transmission of dengue virus (e4eeb858)|article/10.3201/eid0901.020220
Land use practices|isMentionedIn|Regional variation of climatic influences on West Nile virus outbreaks in the United States (8a6987a1)|article/10.4269/ajtmh.14-0239
Land use practices|isMentionedIn|Hydrologic conditions describe West Nile virus risk in Colorado (56d62d2b)|article/10.3390/ijerph7020494
Notification|||
Human Vulnerability|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Human Vulnerability|isMentionedIn|Dengue outbreak in Key West, Florida, USA, 2009 (c00f6a68)|article/10.3201/eid1801.110130
Human Vulnerability|isMentionedIn|Assessing the roles of temperature, precipitation, and ENSO in dengue re-emergence on the Texas-Mexico border region (10d79a4e)|article/10.1590/S0036-36342008000300006
Human Vulnerability|isMentionedIn|Epidemic dengue and dengue hemorrhagic fever at the Texas�Mexico border: Results of a household-based seroepidemiologic survey, December 2005 (10973e71)|article/pmid-18337327
Human Vulnerability|isMentionedIn|Texas lifestyle limits transmission of dengue virus (e4eeb858)|article/10.3201/eid0901.020220
Health Risks|||
Outdoor activity|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Outdoor employment|||
Population at risk|isMentionedIn|Epidemic dengue and dengue hemorrhagic fever at the Texas�Mexico border: Results of a household-based seroepidemiologic survey, December 2005 (10973e71)|article/pmid-18337327
Population at risk|isMentionedIn|Texas lifestyle limits transmission of dengue virus (e4eeb858)|article/10.3201/eid0901.020220
Minorities|||
Sex/Gender|||
Elderly|||
Children|||
Socio-economic risk factors|isMentionedIn|Climate variability and change in the United States: Potential impacts on vector- and rodent-borne diseases (0cdb219f)|article/10.2307/3435012
Housing|isMentionedIn|Texas lifestyle limits transmission of dengue virus (e4eeb858)|
Poverty|isMentionedIn|Texas lifestyle limits transmission of dengue virus (e4eeb858)|
Education|||
Biological Variables|isMentionedIn|Impact of climate variation on mosquito abundance in California (c3fa0d45)|article/10.3376/1081-1710(2008)33%5B89:iocvom%5D2.0.co;2
Biological Variables|isMentionedIn|Temperature-dependent development and survival rates of Culex quinquefasciatus and Aedes aegypti (Diptera: Culicidae) (6cb63356)|article/10.1093/jmedent/27.5.892
Population size|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Population size|isMentionedIn|Local impact of temperature and precipitation on West Nile virus infection in Culex species mosquitoes in northeast Illinois, USA (5bd8de26)|article/10.1186/1756-3305-3-19
Population size|isMentionedIn|Drought-induced amplification of local and regional West Nile virus infection rates in New Jersey (6c4943e6)|article/10.1603/me12035
Population density|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Survival rates|isMentionedIn|Temperature-dependent development and survival rates of Culex quinquefasciatus and Aedes aegypti (Diptera: Culicidae) (6cb63356)|article/10.1093/jmedent/27.5.892
Survival rates|isMentionedIn|Epidemiology and Control of Mosquito Borne Arboviruses in California, 1943-1987 (b18cdaac)|book/d1dc2945-01c4-47c9-b59d-b4a6ef24ef55
Host Abundance|isMentionedIn|webpage West Nile virus transmission cycle|webpage/4b9649af-b944-4395-b830-2a8a3c147f80
Host Abundance|isMentionedIn|Mosquito|image/35596456-30e6-4474-9b23-2ca54983e6c9
Host Abundance|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Pathogen Reproduction rate|isMentionedIn|Impact of climate variation on mosquito abundance in California (c3fa0d45)|article/10.3376/1081-1710(2008)33%5B89:iocvom%5D2.0.co;2
Pathogen Reproduction rate|isMentionedIn|Effect of environmental temperature on the ability of Culex pipiens (Diptera: Culicidae) to transmit West Nile virus (8c5c5e1d)|article/10.1603/0022-2585-39.1.221
Pathogen Reproduction rate|isMentionedIn|Temperature, viral genetics, and the transmission of West Nile virus by Culex pipiens mosquitoes (133275d2)|article/10.1371/journal.ppat.1000092
Pathogen Reproduction rate|isMentionedIn|Effects of temperature on the transmission of West Nile virus by Culex tarsalis (Diptera: Culicidae) (2a946904)|article/10.1093/jmedent/43.2.309
Pathogen Reproduction rate|isMentionedIn|webpage West Nile virus transmission cycle|webpage/4b9649af-b944-4395-b830-2a8a3c147f80
Pathogen Reproduction rate|isMentionedIn|Mosquito|image/35596456-30e6-4474-9b23-2ca54983e6c9
Pathogen Reproduction rate|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Zoonotic carriers|isMentionedIn|Field and climate-based model for predicting the density of host-seeking nymphal Ixodes scapularis , an important vector of tick-borne disease agents in the eastern United States (77f948ec)|article/10.1111/j.1466-8238.2010.00526.x
Habitat availability|isMentionedIn|webpage West Nile virus transmission cycle|webpage/4b9649af-b944-4395-b830-2a8a3c147f80
Habitat availability|isMentionedIn|Mosquito|image/35596456-30e6-4474-9b23-2ca54983e6c9
Habitat availability|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Habitat availability|isMentionedIn|Local impact of temperature and precipitation on West Nile virus infection in Culex species mosquitoes in northeast Illinois, USA (5bd8de26)|article/10.1186/1756-3305-3-19
Habitat availability|isMentionedIn|Drought-induced amplification of local and regional West Nile virus infection rates in New Jersey (6c4943e6)|article/10.1603/me12035
Habitat availability|isMentionedIn|Impact of climate variation on mosquito abundance in California (c3fa0d45)|article/10.3376/1081-1710(2008)33%5B89:iocvom%5D2.0.co;2
Host Reproduction Rates|||
Habitat Range|isMentionedIn|webpage CDC Tick Life Cycle and Hosts|webpage/f720c0d5-ff00-4f0a-bde5-b2ffdee11342
Habitat Range|isMentionedIn|Life Cycle of Blacklegged Ticks, Ixodes scapularis|file/468fb499-7189-4bcf-a8de-d4fdb5eec09e
Migration patterns|isMentionedIn|webpage West Nile virus transmission cycle|webpage/4b9649af-b944-4395-b830-2a8a3c147f80
Migration patterns|isMentionedIn|Birds|file/0d961a0a-0bc1-495b-849a-7e214fb6679e
Migration patterns|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Infrastructure|isMentionedIn|Weather and land cover influences on mosquito populations in Sioux Falls, South Dakota (945868ae)|article/10.1603/me10246
Hospital|||
Dams and Reservoirs|isMentionedIn|Weather and land cover influences on mosquito populations in Sioux Falls, South Dakota (945868ae)|article/10.1603/me10246
Irrigation|isMentionedIn|Hydrologic conditions describe West Nile virus risk in Colorado (56d62d2b)|article/10.3390/ijerph7020494
Airports|||
Exposure|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Exposure|isMentionedIn|webpage CDC Tick Life Cycle and Hosts (f4eeeade)|webpage/f720c0d5-ff00-4f0a-bde5-b2ffdee11342
Exposure|isMentionedIn|Life Cycle of Blacklegged Ticks, Ixodes scapularis|file/468fb499-7189-4bcf-a8de-d4fdb5eec09e
Exposure|isMentionedIn|Mosquito|image/35596456-30e6-4474-9b23-2ca54983e6c9
Exposure|isMentionedIn|webpage West Nile virus transmission cycle|webpage/4b9649af-b944-4395-b830-2a8a3c147f80
Exposure|isMentionedIn|Birds|file/0d961a0a-0bc1-495b-849a-7e214fb6679e
Exposure|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Exposure|isMentionedIn|Climate variability and change in the United States: Potential impacts on vector- and rodent-borne diseases (0cdb219f)|article/10.2307/3435012
Pathway|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Pathway|isMentionedIn|webpage West Nile virus transmission cycle|webpage/4b9649af-b944-4395-b830-2a8a3c147f80
Pathway|isMentionedIn|Mosquito|image/35596456-30e6-4474-9b23-2ca54983e6c9
Pathway|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Ticks|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Ticks|isMentionedIn|webpage CDC Tick Life Cycle and Hosts (f4eeeade)|webpage/f720c0d5-ff00-4f0a-bde5-b2ffdee11342
Ticks|isMentionedIn|Life Cycle of Blacklegged Ticks, Ixodes scapularis|file/468fb499-7189-4bcf-a8de-d4fdb5eec09e
Ticks|isMentionedIn|Seasonal activity patterns of Ixodes pacificus nymphs in relation to climatic conditions (4902bb7e)|article/10.1046/j.1365-2915.2002.00372.x
Ticks|isMentionedIn|Environmentally related variability in risk of exposure to Lyme disease spirochetes in northern California: Effect of climatic conditions and habitat type (d9419ba6)|article/10.1603/0046-225X-32.5.1010
Ticks|isMentionedIn|Spatiotemporal Patterns of Host-Seeking Ixodes scapularis Nymphs (Acari: Ixodidae) in the United States (3089e09f)|article/10.1093/jmedent/43.2.166
Ticks|isMentionedIn|Field and climate-based model for predicting the density of host-seeking nymphal Ixodes scapularis , an important vector of tick-borne disease agents in the eastern United States (77f948ec)|article/10.1111/j.1466-8238.2010.00526.x
Ticks|isMentionedIn|A climate-based model predicts the spatial distribution of the Lyme disease vector Ixodes scapularis in the United States (2471c8e7)|article/10.1289/ehp.6052
Ticks|isMentionedIn|Increasing habitat suitability in the United States for the tick that transmits Lyme disease: A remote sensing approach (eb0e35fc)|article/increasing-habitat-suitability-united-states-tick-that-transmits
Ticks|isMentionedIn|Effect of Climate Change on Lyme Disease Risk in North America (c50c2ea8)|article/10.1007/s10393-004-0139-x
Ticks|isMentionedIn|A spatially-explicit model of acarological risk of exposure to Borrelia burgdorferi-infected Ixodes pacificus nymphs in northwestern California based on woodland type, temperature, and water vapor (94cb8d14)|article/10.1016/j.ttbdis.2009.12.002
Ticks|isMentionedIn|Effects of landscape fragmentation and climate on Lyme disease incidence in the northeastern United States (d35c84bd)|article/10.1007/s10393-013-0890-y
Ticks|isMentionedIn|Climatic analysis of Lyme disease in the United States (197d65cd)|article/10.3354/cr027177
Ticks|isMentionedIn|Effect of latitude on the rate of change in incidence of Lyme disease in the United States (bc29c835)|article/10.9778/cmajo.20120002
Mosquito|isMentionedIn|webpage West Nile virus transmission cycle|webpage/4b9649af-b944-4395-b830-2a8a3c147f80
Mosquito|isMentionedIn|Mosquito|image/35596456-30e6-4474-9b23-2ca54983e6c9
Mosquito|isMentionedIn|webpage The Noun Project|webpage/0eb8d282-b65b-436e-9649-b953bc20b60b
Mosquito|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Mosquito|isMentionedIn|Temperature-dependent development and survival rates of Culex quinquefasciatus and Aedes aegypti (Diptera: Culicidae) (6cb63356)|article/10.1093/jmedent/27.5.892
Mosquito|isMentionedIn|Effect of temperature on Culex tarsalis (Diptera: Culicidae) from the Coachella and San Joaquin Valleys of California (8fdde45b)|article/10.1093/jmedent/32.5.636
Mosquito|isMentionedIn|A continental risk assessment of West Nile virus under climate change (132133f3)|article/10.1111/gcb.12534
Mosquito|isMentionedIn|Regional variation of climatic influences on West Nile virus outbreaks in the United States (8a6987a1)|article/10.4269/ajtmh.14-0239
Mosquito|isMentionedIn|Hydrologic conditions describe West Nile virus risk in Colorado (56d62d2b)|article/10.3390/ijerph7020494
Mosquito|isMentionedIn|Local impact of temperature and precipitation on West Nile virus infection in Culex species mosquitoes in northeast Illinois, USA (5bd8de26)|article/10.1186/1756-3305-3-19
Mosquito|isMentionedIn|Drought-induced amplification of local and regional West Nile virus infection rates in New Jersey (6c4943e6)|article/10.1603/me12035
Mosquito|isMentionedIn|Regional and seasonal response of a West Nile virus vector to climate change (d8fa9745)|article/10.1073/pnas.1307135110
Fleas|||
Source|isMentionedIn|Life Cycle of Blacklegged Ticks, Ixodes scapularis|file/468fb499-7189-4bcf-a8de-d4fdb5eec09e
Birds|isMentionedIn|webpage West Nile virus transmission cycle|webpage/4b9649af-b944-4395-b830-2a8a3c147f80
Birds|isMentionedIn|Birds|file/0d961a0a-0bc1-495b-849a-7e214fb6679e
Birds|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Rodents|isMentionedIn|webpage CDC Tick Life Cycle and Hosts (f4eeeade)|webpage/f720c0d5-ff00-4f0a-bde5-b2ffdee11342
Rodents|isMentionedIn|Life Cycle of Blacklegged Ticks, Ixodes scapularis|file/468fb499-7189-4bcf-a8de-d4fdb5eec09e
Location|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Location|isMentionedIn|webpage Surveillance Resources: ArboNET (2eb0f9eb)|webpage/b5326ffb-91f5-4c5c-82a8-aeb2fa7a8322
Location|isMentionedIn|Incidence of West Nile Neuroinvasive Disease by County in the United States|file/bf86c96e-e2b8-4ce3-9c2b-3e63d1a6a28b
Geographic Distribution|isMentionedIn|Climate and Vectorborne Diseases (cc7c424e)|article/10.1016/j.amepre.2008.08.030
Geographic Distribution|isMentionedIn|Field and climate-based model for predicting the density of host-seeking nymphal Ixodes scapularis , an important vector of tick-borne disease agents in the eastern United States (77f948ec)|article/10.1111/j.1466-8238.2010.00526.x
Geographic Distribution|isMentionedIn|A climate-based model predicts the spatial distribution of the Lyme disease vector Ixodes scapularis in the United States (2471c8e7)|article/10.1289/ehp.6052
Geographic Distribution|isMentionedIn|Increasing habitat suitability in the United States for the tick that transmits Lyme disease: A remote sensing approach (eb0e35fc)|article/increasing-habitat-suitability-united-states-tick-that-transmits
Geographic Distribution|isMentionedIn|Effect of Climate Change on Lyme Disease Risk in North America (c50c2ea8)|article/10.1007/s10393-004-0139-x
Geographic Distribution|isMentionedIn|Effects of landscape fragmentation and climate on Lyme disease incidence in the northeastern United States (d35c84bd)|article/10.1007/s10393-013-0890-y
Geographic Distribution|isMentionedIn|Climatic analysis of Lyme disease in the United States (197d65cd)|article/10.3354/cr027177
Geographic Distribution|isMentionedIn|Effect of latitude on the rate of change in incidence of Lyme disease in the United States (bc29c835)|article/10.9778/cmajo.20120002
Geographic Distribution|isMentionedIn|webpage Surveillance Resources: ArboNET (2eb0f9eb)|webpage/b5326ffb-91f5-4c5c-82a8-aeb2fa7a8322
Geographic Distribution|isMentionedIn|Incidence of West Nile Neuroinvasive Disease by County in the United States|file/bf86c96e-e2b8-4ce3-9c2b-3e63d1a6a28b
Geographic Distribution|isMentionedIn|webpage Lyme Disease: Data and Statistics: Maps- Reported Cases of Lyme Disease � United States, 2001-2014 (6066212c)|webpage/eee6fd2b-9f99-47da-99db-7a1057e33343
Geographic Distribution|isMentionedIn|Changes in Lyme Disease Case Report Distribution|file/27d2f65d-6845-48e4-9975-0c7f649aae56
Geographic Distribution|isMentionedIn|A continental risk assessment of West Nile virus under climate change (132133f3)|article/10.1111/gcb.12534
Geographic Distribution|isMentionedIn|Impact of climate variation on mosquito abundance in California (c3fa0d45)|article/10.3376/1081-1710(2008)33%5B89:iocvom%5D2.0.co;2
Proximity to water|||
Urban|isMentionedIn|Regional variation of climatic influences on West Nile virus outbreaks in the United States (8a6987a1)|article/10.4269/ajtmh.14-0239
Urban|isMentionedIn|Hydrologic conditions describe West Nile virus risk in Colorado (56d62d2b)|article/10.3390/ijerph7020494
Urban|isMentionedIn|Local impact of temperature and precipitation on West Nile virus infection in Culex species mosquitoes in northeast Illinois, USA (5bd8de26)|article/10.1186/1756-3305-3-19
Urban|isMentionedIn|Drought-induced amplification of local and regional West Nile virus infection rates in New Jersey (6c4943e6)|article/10.1603/me12035
Time|isMentionedIn|Meteorological influences on the seasonality of Lyme disease in the United States (0360d0f9)|article/10.4269/ajtmh.13-0180
Time|isMentionedIn|webpage CDC Tick Life Cycle and Hosts (f4eeeade)|webpage/f720c0d5-ff00-4f0a-bde5-b2ffdee11342
Time|isMentionedIn|Life Cycle of Blacklegged Ticks, Ixodes scapularis|file/468fb499-7189-4bcf-a8de-d4fdb5eec09e
Time|isMentionedIn|Seasonal activity patterns of Ixodes pacificus nymphs in relation to climatic conditions (4902bb7e)|article/10.1046/j.1365-2915.2002.00372.x
Time|isMentionedIn|Environmentally related variability in risk of exposure to Lyme disease spirochetes in northern California: Effect of climatic conditions and habitat type (d9419ba6)|article/10.1603/0046-225X-32.5.1010
Time|isMentionedIn|Spatiotemporal Patterns of Host-Seeking Ixodes scapularis Nymphs (Acari: Ixodidae) in the United States (3089e09f)|article/10.1093/jmedent/43.2.166
Vector Seasonal Activity|isMentionedIn|Seasonal activity patterns of Ixodes pacificus nymphs in relation to climatic conditions (4902bb7e)|article/10.1046/j.1365-2915.2002.00372.x
Vector Seasonal Activity|isMentionedIn|Environmentally related variability in risk of exposure to Lyme disease spirochetes in northern California: Effect of climatic conditions and habitat type (d9419ba6)|article/10.1603/0046-225X-32.5.1010
Vector Seasonal Activity|isMentionedIn|Spatiotemporal Patterns of Host-Seeking Ixodes scapularis Nymphs (Acari: Ixodidae) in the United States (3089e09f)|article/10.1093/jmedent/43.2.166
Vector Seasonal Activity|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Vector Seasonal Activity|isMentionedIn|webpage CDC Tick Life Cycle and Hosts (f4eeeade)|webpage/f720c0d5-ff00-4f0a-bde5-b2ffdee11342
Vector Seasonal Activity|isMentionedIn|Life Cycle of Blacklegged Ticks, Ixodes scapularis|file/468fb499-7189-4bcf-a8de-d4fdb5eec09e
Vector Seasonal Activity|isMentionedIn|Effects of landscape fragmentation and climate on Lyme disease incidence in the northeastern United States (d35c84bd)|article/10.1007/s10393-013-0890-y
Vector Seasonal Activity|isMentionedIn|Climatic analysis of Lyme disease in the United States (197d65cd)|article/10.3354/cr027177
Vector Seasonal Activity|isMentionedIn|Effect of latitude on the rate of change in incidence of Lyme disease in the United States (bc29c835)|article/10.9778/cmajo.20120002
Contaminants|||
Pathogens|isMentionedIn|Climate variability and change in the United States: Potential impacts on vector- and rodent-borne diseases (0cdb219f)|article/10.2307/3435012
Pathogens|isMentionedIn|Dengue outbreak in Key West, Florida, USA, 2009 (c00f6a68)|article/10.3201/eid1801.110130
Pathogens|isMentionedIn|Assessing the roles of temperature, precipitation, and ENSO in dengue re-emergence on the Texas-Mexico border region (10d79a4e)|article/10.1590/S0036-36342008000300006
Pathogens|isMentionedIn|Texas lifestyle limits transmission of dengue virus (e4eeb858)|article/10.3201/eid0901.020220
Lyme disease|isMentionedIn|Effects of landscape fragmentation and climate on Lyme disease incidence in the northeastern United States (d35c84bd)|article/10.1007/s10393-013-0890-y
Lyme disease|isMentionedIn|Climatic analysis of Lyme disease in the United States (197d65cd)|article/10.3354/cr027177
Lyme disease|isMentionedIn|Effect of latitude on the rate of change in incidence of Lyme disease in the United States (bc29c835)|article/10.9778/cmajo.20120002
Lyme disease|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Lyme disease|isMentionedIn|webpage CDC Tick Life Cycle and Hosts (f4eeeade)|webpage/f720c0d5-ff00-4f0a-bde5-b2ffdee11342
Lyme disease|isMentionedIn|Life Cycle of Blacklegged Ticks, Ixodes scapularis|file/468fb499-7189-4bcf-a8de-d4fdb5eec09e
Lyme disease|isMentionedIn|Climate change influences on the annual onset of Lyme disease in the United States (953d1436)|article/10.1016/j.ttbdis.2015.05.005
Lyme disease|isMentionedIn|Projected Change in Lyme Disease Onset Week|file/45c77919-5b1c-4e8e-ae71-ff7c83e005fe
Lyme disease|isMentionedIn|webpage Lyme Disease: Data and Statistics: Maps- Reported Cases of Lyme Disease � United States, 2001-2014 (6066212c)|webpage/eee6fd2b-9f99-47da-99db-7a1057e33343
Lyme disease|isMentionedIn|webpage Interactive Lyme Disease Map|webpage/7206f315-04be-4536-9e10-70155edfada0
Lyme disease|isMentionedIn|Changes in Lyme Disease Case Report Distribution|file/27d2f65d-6845-48e4-9975-0c7f649aae56
Lyme disease|isMentionedIn|Meteorological influences on the seasonality of Lyme disease in the United States (0360d0f9)|article/10.4269/ajtmh.13-0180
Lyme disease|isMentionedIn|A spatially-explicit model of acarological risk of exposure to Borrelia burgdorferi-infected Ixodes pacificus nymphs in northwestern California based on woodland type, temperature, and water vapor (94cb8d14)|article/10.1016/j.ttbdis.2009.12.002
Spotted Fever Rickettsia|||
Babesiosis|||
Anaplasmosis/Ehrlichiosis|||
Tularemia|||
St. Louis encephalitis|||
California Serogroup Viruses|||
Dengue|isMentionedIn|Dengue outbreak in Key West, Florida, USA, 2009 (c00f6a68)|article/10.3201/eid1801.110130
Malaria|||
West Nile Virus|isMentionedIn|webpage Surveillance Resources: ArboNET (2eb0f9eb)|webpage/b5326ffb-91f5-4c5c-82a8-aeb2fa7a8322
West Nile Virus|isMentionedIn|Incidence of West Nile Neuroinvasive Disease by County in the United States|file/bf86c96e-e2b8-4ce3-9c2b-3e63d1a6a28b
West Nile Virus|isMentionedIn|webpage West Nile virus transmission cycle|webpage/4b9649af-b944-4395-b830-2a8a3c147f80
West Nile Virus|isMentionedIn|Mosquito|image/35596456-30e6-4474-9b23-2ca54983e6c9
West Nile Virus|isMentionedIn|webpage The Noun Project|webpage/0eb8d282-b65b-436e-9649-b953bc20b60b
West Nile Virus|isMentionedIn|Humans|image/513fdc60-524e-468d-8ce3-9a5b4795d2a9
West Nile Virus|isMentionedIn|Birds|file/0d961a0a-0bc1-495b-849a-7e214fb6679e
West Nile Virus|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
West Nile Virus|isMentionedIn|Temperature-dependent development and survival rates of Culex quinquefasciatus and Aedes aegypti (Diptera: Culicidae) (6cb63356)|article/10.1093/jmedent/27.5.892
West Nile Virus|isMentionedIn|Effect of temperature on Culex tarsalis (Diptera: Culicidae) from the Coachella and San Joaquin Valleys of California (8fdde45b)|article/10.1093/jmedent/32.5.636
West Nile Virus|isMentionedIn|Impact of climate variation on mosquito abundance in California (c3fa0d45)|article/10.3376/1081-1710(2008)33%5B89:iocvom%5D2.0.co;2
West Nile Virus|isMentionedIn|Local impact of temperature and precipitation on West Nile virus infection in Culex species mosquitoes in northeast Illinois, USA (5bd8de26)|article/10.1186/1756-3305-3-19
West Nile Virus|isMentionedIn|Weather and land cover influences on mosquito populations in Sioux Falls, South Dakota (945868ae)|article/10.1603/me10246
West Nile Virus|isMentionedIn|A continental risk assessment of West Nile virus under climate change (132133f3)|article/10.1111/gcb.12534
West Nile Virus|isMentionedIn|Regional variation of climatic influences on West Nile virus outbreaks in the United States (8a6987a1)|article/10.4269/ajtmh.14-0239
West Nile Virus|isMentionedIn|Hydrologic conditions describe West Nile virus risk in Colorado (56d62d2b)|article/10.3390/ijerph7020494
West Nile Virus|isMentionedIn|Drought-induced amplification of local and regional West Nile virus infection rates in New Jersey (6c4943e6)|article/10.1603/me12035
Powassan|||
Eastern Equine Encephalitis|||
Murine Typhus|||
Bubonic Plague|||
Septicemic Plague|||
Pneumonic Plague|||
Natural Hazard|isMentionedIn|webpage West Nile virus transmission cycle|webpage/4b9649af-b944-4395-b830-2a8a3c147f80
Natural Hazard|isMentionedIn|Mosquito|image/35596456-30e6-4474-9b23-2ca54983e6c9
Natural Hazard|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Natural Hazard|isMentionedIn|Impact of climate variation on mosquito abundance in California (c3fa0d45)|article/10.3376/1081-1710(2008)33%5B89:iocvom%5D2.0.co;2
Natural Hazard|isMentionedIn|Local impact of temperature and precipitation on West Nile virus infection in Culex species mosquitoes in northeast Illinois, USA (5bd8de26)|article/10.1186/1756-3305-3-19
Natural Hazard|isMentionedIn|Weather and land cover influences on mosquito populations in Sioux Falls, South Dakota (945868ae)|article/10.1603/me10246
Flooding|||
Drought|isMentionedIn|Epidemiology and Control of Mosquito Borne Arboviruses in California, 1943-1987 (b18cdaac)|book/d1dc2945-01c4-47c9-b59d-b4a6ef24ef55
Drought|isMentionedIn|Regional variation of climatic influences on West Nile virus outbreaks in the United States (8a6987a1)|article/10.4269/ajtmh.14-0239
Drought|isMentionedIn|Drought-induced amplification of local and regional West Nile virus infection rates in New Jersey (6c4943e6)|article/10.1603/me12035
Drought|isMentionedIn|Impact of climate variation on mosquito abundance in California (c3fa0d45)|article/10.3376/1081-1710(2008)33%5B89:iocvom%5D2.0.co;2
Drought|isMentionedIn|Local impact of temperature and precipitation on West Nile virus infection in Culex species mosquitoes in northeast Illinois, USA (5bd8de26)|article/10.1186/1756-3305-3-19
Drought|isMentionedIn|Weather and land cover influences on mosquito populations in Sioux Falls, South Dakota (945868ae)|article/10.1603/me10246
Drought|isMentionedIn|Hydrologic conditions describe West Nile virus risk in Colorado (56d62d2b)|article/10.3390/ijerph7020494
Hurricane|||
Climate Indicators|isMentionedIn|A spatially-explicit model of acarological risk of exposure to Borrelia burgdorferi-infected Ixodes pacificus nymphs in northwestern California based on woodland type, temperature, and water vapor (94cb8d14)|article/10.1016/j.ttbdis.2009.12.002
Climate Indicators|isMentionedIn|Effects of landscape fragmentation and climate on Lyme disease incidence in the northeastern United States (d35c84bd)|article/10.1007/s10393-013-0890-y
Climate Indicators|isMentionedIn|Climatic analysis of Lyme disease in the United States (197d65cd)|article/10.3354/cr027177
Climate Indicators|isMentionedIn|Effect of latitude on the rate of change in incidence of Lyme disease in the United States (bc29c835)|article/10.9778/cmajo.20120002
Climate Indicators|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Climate Indicators|isMentionedIn|Meteorological influences on the seasonality of Lyme disease in the United States (0360d0f9)|article/10.4269/ajtmh.13-0180
Climate Indicators|isMentionedIn|A continental risk assessment of West Nile virus under climate change (132133f3)|article/10.1111/gcb.12534
Climate Indicators|isMentionedIn|Climate and Vectorborne Diseases (cc7c424e)|article/10.1016/j.amepre.2008.08.030
Climate Indicators|isMentionedIn|Field and climate-based model for predicting the density of host-seeking nymphal Ixodes scapularis , an important vector of tick-borne disease agents in the eastern United States (77f948ec)|article/10.1111/j.1466-8238.2010.00526.x
Climate Indicators|isMentionedIn|A climate-based model predicts the spatial distribution of the Lyme disease vector Ixodes scapularis in the United States (2471c8e7)|article/10.1289/ehp.6052
Climate Indicators|isMentionedIn|Increasing habitat suitability in the United States for the tick that transmits Lyme disease: A remote sensing approach (eb0e35fc)|article/increasing-habitat-suitability-united-states-tick-that-transmits
Climate Indicators|isMentionedIn|Impact of climate variation on mosquito abundance in California (c3fa0d45)|article/10.3376/1081-1710(2008)33%5B89:iocvom%5D2.0.co;2
Climate Indicators|isMentionedIn|Effect of temperature on Culex tarsalis (Diptera: Culicidae) from the Coachella and San Joaquin Valleys of California (8fdde45b)|article/10.1093/jmedent/32.5.636
Climate Indicators|isMentionedIn|Regional and seasonal response of a West Nile virus vector to climate change (d8fa9745)|article/10.1073/pnas.1307135110
Climate Indicators|isMentionedIn|Weather and land cover influences on mosquito populations in Sioux Falls, South Dakota (945868ae)|article/10.1603/me10246
Climate Indicators|isMentionedIn|Climatic and landscape correlates for potential West Nile virus mosquito vectors in the Seattle region (68125763)|article/10.3376/1081-1710(2007)32%5B22:CALCFP%5D2.0.CO;2
Climate Indicators|isMentionedIn|Climate variability and change in the United States: Potential impacts on vector- and rodent-borne diseases (0cdb219f)|article/10.2307/3435012
Temperature|isMentionedIn|Regional and seasonal response of a West Nile virus vector to climate change (d8fa9745)|article/10.1073/pnas.1307135110
Temperature|isMentionedIn|Temperature-dependent development and survival rates of Culex quinquefasciatus and Aedes aegypti (Diptera: Culicidae) (6cb63356)|article/10.1093/jmedent/27.5.892
Temperature|isMentionedIn|Effect of temperature on Culex tarsalis (Diptera: Culicidae) from the Coachella and San Joaquin Valleys of California (8fdde45b)|article/10.1093/jmedent/32.5.636
Temperature|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Temperature|isMentionedIn|webpage West Nile virus transmission cycle|webpage/4b9649af-b944-4395-b830-2a8a3c147f80
Temperature|isMentionedIn|Mosquito|image/35596456-30e6-4474-9b23-2ca54983e6c9
Temperature|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Temperature|isMentionedIn|Field and climate-based model for predicting the density of host-seeking nymphal Ixodes scapularis , an important vector of tick-borne disease agents in the eastern United States (77f948ec)|article/10.1111/j.1466-8238.2010.00526.x
Temperature|isMentionedIn|A climate-based model predicts the spatial distribution of the Lyme disease vector Ixodes scapularis in the United States (2471c8e7)|article/10.1289/ehp.6052
Temperature|isMentionedIn|Increasing habitat suitability in the United States for the tick that transmits Lyme disease: A remote sensing approach (eb0e35fc)|article/increasing-habitat-suitability-united-states-tick-that-transmits
Temperature|isMentionedIn|Effect of Climate Change on Lyme Disease Risk in North America (c50c2ea8)|article/10.1007/s10393-004-0139-x
Temperature|isMentionedIn|Effects of landscape fragmentation and climate on Lyme disease incidence in the northeastern United States (d35c84bd)|article/10.1007/s10393-013-0890-y
Temperature|isMentionedIn|Climatic analysis of Lyme disease in the United States (197d65cd)|article/10.3354/cr027177
Temperature|isMentionedIn|Effect of latitude on the rate of change in incidence of Lyme disease in the United States (bc29c835)|article/10.9778/cmajo.20120002
Temperature|isMentionedIn|Local impact of temperature and precipitation on West Nile virus infection in Culex species mosquitoes in northeast Illinois, USA (5bd8de26)|article/10.1186/1756-3305-3-19
Temperature|isMentionedIn|Weather and land cover influences on mosquito populations in Sioux Falls, South Dakota (945868ae)|article/10.1603/me10246
Temperature|isMentionedIn|Impact of climate variation on mosquito abundance in California (c3fa0d45)|article/10.3376/1081-1710(2008)33%5B89:iocvom%5D2.0.co;2
Temperature|isMentionedIn|Regional variation of climatic influences on West Nile virus outbreaks in the United States (8a6987a1)|article/10.4269/ajtmh.14-0239
Temperature|isMentionedIn|Hydrologic conditions describe West Nile virus risk in Colorado (56d62d2b)|article/10.3390/ijerph7020494
Precipitation|isMentionedIn|climate-change-and-health-lyme-disease|file/fbbf6446-852c-42c9-aa87-940b8f010132
Precipitation|isMentionedIn|webpage West Nile virus transmission cycle|webpage/4b9649af-b944-4395-b830-2a8a3c147f80
Precipitation|isMentionedIn|Mosquito|image/35596456-30e6-4474-9b23-2ca54983e6c9
Precipitation|isMentionedIn|Climate Impacts on West Nile Virus Transmission|file/9c6a242e-59ab-43b2-950e-ac1841e28497
Precipitation|isMentionedIn|Effects of landscape fragmentation and climate on Lyme disease incidence in the northeastern United States (d35c84bd)|article/10.1007/s10393-013-0890-y
Precipitation|isMentionedIn|Climatic analysis of Lyme disease in the United States (197d65cd)|article/10.3354/cr027177
Precipitation|isMentionedIn|Effect of latitude on the rate of change in incidence of Lyme disease in the United States (bc29c835)|article/10.9778/cmajo.20120002
Precipitation|isMentionedIn|Regional variation of climatic influences on West Nile virus outbreaks in the United States (8a6987a1)|article/10.4269/ajtmh.14-0239
Precipitation|isMentionedIn|Hydrologic conditions describe West Nile virus risk in Colorado (56d62d2b)|article/10.3390/ijerph7020494
Precipitation|isMentionedIn|Regional and seasonal response of a West Nile virus vector to climate change (d8fa9745)|article/10.1073/pnas.1307135110
Humidity|isMentionedIn|Field and climate-based model for predicting the density of host-seeking nymphal Ixodes scapularis , an important vector of tick-borne disease agents in the eastern United States (77f948ec)|article/10.1111/j.1466-8238.2010.00526.x
Humidity|isMentionedIn|A climate-based model predicts the spatial distribution of the Lyme disease vector Ixodes scapularis in the United States (2471c8e7)|article/10.1289/ehp.6052
Humidity|isMentionedIn|Increasing habitat suitability in the United States for the tick that transmits Lyme disease: A remote sensing approach (eb0e35fc)|article/increasing-habitat-suitability-united-states-tick-that-transmits
Humidity|isMentionedIn|Seasonal activity patterns of Ixodes pacificus nymphs in relation to climatic conditions (4902bb7e)|article/10.1046/j.1365-2915.2002.00372.x
Humidity|isMentionedIn|Environmentally related variability in risk of exposure to Lyme disease spirochetes in northern California: Effect of climatic conditions and habitat type (d9419ba6)|article/10.1603/0046-225X-32.5.1010
Humidity|isMentionedIn|A spatially-explicit model of acarological risk of exposure to Borrelia burgdorferi-infected Ixodes pacificus nymphs in northwestern California based on woodland type, temperature, and water vapor (94cb8d14)|article/10.1016/j.ttbdis.2009.12.002