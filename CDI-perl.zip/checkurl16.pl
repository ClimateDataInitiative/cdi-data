#!c:/perl/bin/perl.exe -w
#use File::Path;
$|=1;
use LWP::UserAgent;
require vcfw;
GenDTG();
#$InitOld = "";
$ErrCt = 0;
$ErrFile =  "C:\\db\\GSFC\\errors-NoPDF.txt";
$GoodFile = "C:\\db\\GSFC\\good-NoPDF.txt";
$JunkFile = "C:\\temp\\junk.jnk";
$InFile =   "C:\\db\\GSFC\\url.csv";
#$InFile =  "C:\\db\\GSFC\\errors.txt";

open (IN,"$InFile") || die "Choke on open $InFile:$!\n";
open (GOOD,">$GoodFile") || die "Choke on open $GoodFile:$!\n";
open (OOPS,">$ErrFile") || die "Choke on open $ErrFile:$!\n";
#output database results
while (<IN>) {
	chomp;
	$Ct++;
#	print "$Ct\n";
	($Term,$URL) = split (/,/);
	trim($Term);
	trim($URL);
	if ($URL ne "") {
		$URL =~ s/ //g;
		print "[$Term]\n";
		$DownLoadTo = $JunkFile;
		GenDTG();
		print "$DTG ($Ct) Downloading: $URL\nto       :$DownLoadTo\n";
		$ua = new LWP::UserAgent;
		$ua->agent("$0/0.1 " . $ua->agent);
		$ua->agent("Vince Wilding's Snarfilator (VCFW)");
#		$ua->referer("http://joe.sent.me/");
		$req = new HTTP::Request 'GET' => "$URL";
		$req->header('Accept' => 'text/html'); #, 'application/pdf');
		# send request
		$res = $ua->request($req);
		# check the outcome
		if ($res->is_success) {
			print "$Term OK\n";
			print GOOD "$Term,$URL\n";
		} else {
			$ErrCt++;
			$Stats = $res->status_line;
			print "$Term BAD\n";
			chomp($Stats);
			GenDTG();
			print "$DTG Error: \"$Stats\" on Term:URL: $Term:$URL\n";
			print OOPS "$Term,$URL\n";
		}
	} # end of non -null URL
}
GenDTG();
close OOPS;
system "q $ErrFile $GoodFile";
#ystem "email !c:/email.me \"$ErrCt errors on ISG Mirroring\" !$ErrFile";

