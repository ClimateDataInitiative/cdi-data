#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\HI\\HI-load-cmap.sql";
$F2 = "C:\\db\\gsfc\\HI\\HI-load-rship.sql";
$Relationship = "Throw this away";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
open (OUT2,">",$F2) || die "choke on open out $F2: $!\n";
print OUT2 "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
	($Subject,$Predicate,$Relationship,$Object) = split(/\t/);
	$Subject = trim($Subject);		# trim trailing/leading spaces
	$Predicate = trim($Predicate);
	$Object= trim($Object);
	$Preds{$Predicate}++; #Count Predicates
	if ($Subject ne $Object) {
	print OUT<<EOM;
INSERT INTO term_relationship (term_subject, relationship_identifier, term_object) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = '$Subject' and s.lexicon_identifier = 'cdi'), '$Predicate', (SELECT o.identifier FROM term AS o WHERE o.term = '$Object' and o.lexicon_identifier = 'cdi' ));
EOM
	} else {
	print "*** $Subject $Predicate $Object ***\n"
}
}
foreach $key (sort keys(%Preds)){  # generate relationship statements
	$Count = $Preds{$key};
	$Tot1 += $Count;
	print OUT2 "INSERT INTO relationship (relationship) VALUES ('$key');\n";
    }
#print OUT2 " -- [$Tot1]\n";
close OUT;
close OUT2;
system "$ENV{'ED'} $F2 $F1"
#Subject	Predicate	Relationship	Object
__DATA__
Health	skos:narrower	is broader than	Heat Illness
Heat Illness	isInfluencedBy	isInfluencedBy	Human Vulnerability
Human Vulnerability	isDeterminedBy	isDeterminedBy	Adaptive Capacity
Adaptive Capacity	skos:narrower	Involves	Adaptation
Adaptive Capacity	skos:narrower	Involves	Acclimatization
Adaptive Capacity	skos:narrower	Involves	Physical Heat Tolerance
Human Vulnerability	isDeterminedBy	isDeterminedBy	Health Risks
Health Risks	skos:narrower	consistsOf	Resulting Medical Conditions
Resulting Medical Conditions	isResultOf	include	Heat Stroke
Resulting Medical Conditions	isResultOf	include	Mortality
Resulting Medical Conditions	isResultOf	include	Hyperthermia
Resulting Medical Conditions	isResultOf	include	Heat Cramps
Resulting Medical Conditions	isResultOf	include	Heat Exhaustion
Health Risks	skos:narrower	consistsOf	Existing Medical Conditions
Existing Medical Conditions	isResultOf	include	Cardiovascular Disorders
Existing Medical Conditions	isResultOf	include	Mental Illness
Existing Medical Conditions	isResultOf	include	Kidney Disorders
Existing Medical Conditions	isResultOf	include	Asthma
Existing Medical Conditions	isResultOf	include	Alzheimer's Disease
Existing Medical Conditions	isResultOf	include	Substance Abuse
Existing Medical Conditions	isResultOf	include	COPD
Existing Medical Conditions	isResultOf	include	Obesity
Existing Medical Conditions	isResultOf	include	Cardiovascular Disease
Existing Medical Conditions	isResultOf	include	Diabetes
Existing Medical Conditions	isResultOf	include	Stress
Existing Medical Conditions	isResultOf	include	Dementia
Existing Medical Conditions	isResultOf	include	Respiratory Disease
Existing Medical Conditions	isResultOf	include	Mood Disorders
Existing Medical Conditions	isResultOf	include	Functional Disabilities
Existing Medical Conditions	isResultOf	include	Renal Illness
Existing Medical Conditions	isResultOf	include	Neurosis
Human Vulnerability	isDeterminedBy	isDeterminedBy	Populations at Risk
Populations at Risk	isResultOf	include	Children
Populations at Risk	isResultOf	include	Pregnant
Populations at Risk	isResultOf	include	Elderly
Populations at Risk	isResultOf	include	Race/Ethnicity
Populations at Risk	isResultOf	include	Non-Hispanic Blacks
Populations at Risk	isResultOf	include	Occupation
Populations at Risk	isResultOf	include	Hispanics
Populations at Risk	isResultOf	include	Outdoor Workers
Populations at Risk	isResultOf	include	Highschool Football Players
Human Vulnerability	isDeterminedBy	isDeterminedBy	Socioeconomic Risks
Socioeconomic Risks	isResultOf	include	Income
Socioeconomic Risks	isResultOf	include	Housing 
Socioeconomic Risks	isResultOf	include	Education
Socioeconomic Risks	isResultOf	include	Health Care Access
Heat Illness	isInfluencedBy	isInfluencedBy	Infrastructure
Infrastructure	skos:narrower	include	Hospital
Infrastructure	skos:narrower	include	Energy Demand
Infrastructure	skos:narrower	include	Urban Development
Infrastructure	skos:narrower	include	Electricity Distribution
Infrastructure	isInfluencedBy	include	AC Use
Infrastructure	skos:narrower	include	Cooling Centers
Infrastructure	skos:narrower	include	Energy Production/Use
Heat Illness	isInfluencedBy	isInfluencedBy	Exposure
Exposure	isDeterminedBy	isDeterminedBy	Location
Location	skos:narrower	canOccur	Drought-Striken Areas
Location	skos:narrower	canOccur	Wildfire Prone Areas
Location	skos:narrower	canOccur	Low-lying Areas
Location	skos:narrower	canOccur	Urban Areas
Location	skos:narrower	canOccur	Land Cover
Heat Illness	skos:narrower	isInfluencedBy	Response
Response	skos:narrower	include	Future Projections
Response	skos:narrower	include	Historical Analysis
Response	skos:narrower	include	Data Monitoring
Heat Illness	isInfluencedBy	isInfluencedBy	Climate Indicators
Climate Indicators	skos:narrower	include	Humidity
Climate Indicators	skos:narrower	include	Local Temperature Averages
Climate Indicators	skos:narrower	include	Wet-Bulb Temperature
Climate Indicators	skos:narrower	include	Heat Index
Climate Indicators	skos:narrower	include	Temperature
Climate Indicators	skos:narrower	include	Heating/Cooling Degree Days
