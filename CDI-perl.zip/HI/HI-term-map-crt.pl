#!perl -w
##Input from __DATA__ below, GCIS tab of spreadsheet, tab seperated Term	Relationship	Datasets	extURI
use vcfw;
use Text::Unidecode;
$F1 = "C:\\db\\gsfc\\HI\\HI-load-term-map-crt.sql";
$SqlStatement="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
#Term	Relationship	Datasets	extURI
	($Term,$Relationship,$Datasets,$extURI) = split(/\t/);
	$DoWrite = 1;
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term eq "") {
		$ThisTerm = $OldTerm
	} else {
		$ThisTerm = $OldTerm = $Term;
	}
	$Datasets = trim($Datasets);
	$Datasets = unidecode($Datasets);
	$Datasets =~ s/'/''/g;		#Escape single quotes
	if ($Datasets eq "") {
		$DoWrite = 0;
	}

	$extURI= trim($extURI);
	if ($extURI eq "") {
		$DoWrite = 0;
	}
	$Relationship = trim($Relationship);
		if ($Relationship eq "") {
		$DoWrite = 0;
	}

	if ($DoWrite) {
		$SqlStatement =<<EOM;
INSERT INTO term_map (term_identifier, relationship_identifier, gcid,  description) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = '$ThisTerm' and s.lexicon_identifier = 'cdi'), '$Relationship', '$extURI', '$Datasets');
EOM
		print OUT "$SqlStatement";
	}
}
close OUT;
system "$ENV{'ED'} $F1"
#Subject	Predicate	Relationship	Object
#Term	Relationship	Datasets	extURI


#Term	Relationship	CaseStudy	extURI	Tools	extURI
__DATA__
Health	hasCaseStudy		http://toolkit.climate.gov/taking-action?f[0]=field_parent_topic%3A116
Health	hasAnalysisTool		http://toolkit.climate.gov/tools?f[0]=field_parent_topic%3A116
Heat Illness	hasAnalysisTool	Recognizing, Preventing, and Treating Heat-Related Illness	http://toolkit.climate.gov/tool/recognizing-preventing-and-treating-heat-related-illness
Heat Illness	hasAnalysisTool	Heat Safety Tool	http://toolkit.climate.gov/tool/heat-safety-tool
Human Vulnerability	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Human Vulnerability	hasAnalysisTool	Assessing Health Vulnerability to Climate Change: A Guide for Health Departments	http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments
Human Vulnerability	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Human Vulnerability	hasAnalysisTool	Excessive Heat Events Guidebook	http://toolkit.climate.gov/tool/excessive-heat-events-guidebook
Human Vulnerability	hasAnalysisTool	Great Lakes Climate Atlas	http://toolkit.climate.gov/tool/great-lakes-climate-atlas
Human Vulnerability	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Human Vulnerability	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Human Vulnerability	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit
Human Vulnerability	hasAnalysisTool	Urban Tree Canopy Assessmen	http://toolkit.climate.gov/tool/urban-tree-canopy-assessment
Adaptive Capacity			
Adaptation	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Adaptation	hasAnalysisTool	Climate Adaptation Knowledge Exchange (CAKE)	http://toolkit.climate.gov/tool/climate-adaptation-knowledge-exchange-cake
Adaptation	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Acclimatization			
Physical Heat Tolerance			
Health Risks	hasAnalysisTool	Assessing Health Vulnerability to Climate Change: A Guide for Health Departments	http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments
Health Risks	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Health Risks	hasAnalysisTool	Excessive Heat Events Guidebook	http://toolkit.climate.gov/tool/excessive-heat-events-guidebook
Health Risks	hasAnalysisTool	Heat Safety Tool	http://toolkit.climate.gov/tool/heat-safety-tool
Health Risks	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Health Risks	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Resulting Medical Conditions	hasAnalysisTool	Disaster Behavioral Health Information Series	http://toolkit.climate.gov/tool/disaster-behavioral-health-information-series
Resulting Medical Conditions	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Heat Stroke	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Mortality			
Hyperthermia			
Heat Cramps			
Heat Exhaustion			
Existing Medical Conditions	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Cardiovascular Disorders			
Mental Illness	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Kidney Disorders			
Asthma	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Alzheimer's Disease			
Substance Abuse			
COPD	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Obesity	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Cardiovascular Disease	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Diabetes	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Stress	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Stress	hasAnalysisTool	Urban Tree Canopy Assessmen	http://toolkit.climate.gov/tool/urban-tree-canopy-assessment
Dementia			
Respiratory Disease	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Mood Disorders			
Functional Disabilities			
Renal Illness			
Neurosis			
Populations at Risk	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Populations at Risk	hasAnalysisTool	Assessing Health Vulnerability to Climate Change: A Guide for Health Departments	http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments
Populations at Risk	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Populations at Risk	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Populations at Risk	hasAnalysisTool	Excessive Heat Events Guidebook	http://toolkit.climate.gov/tool/excessive-heat-events-guidebook
Populations at Risk	hasAnalysisTool	Great Lakes Climate Atlas	http://toolkit.climate.gov/tool/great-lakes-climate-atlas
Populations at Risk	hasAnalysisTool	Recognizing, Preventing, and Treating Heat-Related Illness	http://toolkit.climate.gov/tool/recognizing-preventing-and-treating-heat-related-illness
Populations at Risk	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Populations at Risk	hasAnalysisTool	Urban Tree Canopy Assessmen	http://toolkit.climate.gov/tool/urban-tree-canopy-assessment
Children	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Pregnant			
Elderly	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Elderly	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Elderly	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Elderly	hasAnalysisTool	Excessive Heat Events Guidebook	http://toolkit.climate.gov/tool/excessive-heat-events-guidebook
Elderly	hasAnalysisTool	Great Lakes Climate Atlas	http://toolkit.climate.gov/tool/great-lakes-climate-atlas
Race/Ethnicity	hasAnalysisTool	Great Lakes Climate Atlas	http://toolkit.climate.gov/tool/great-lakes-climate-atlas
Race/Ethnicity	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Non-Hispanic Blacks			
Occupation			
Hispanics			
Outdoor Workers	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Outdoor Workers	hasAnalysisTool	Heat Safety Tool	http://toolkit.climate.gov/tool/heat-safety-tool
Outdoor Workers	hasAnalysisTool	Recognizing, Preventing, and Treating Heat-Related Illness	http://toolkit.climate.gov/tool/recognizing-preventing-and-treating-heat-related-illness
Highschool Football Players	hasAnalysisTool	Recognizing, Preventing, and Treating Heat-Related Illness	http://toolkit.climate.gov/tool/recognizing-preventing-and-treating-heat-related-illness
Socioeconomic Risks	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Socioeconomic Risks	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Socioeconomic Risks	hasAnalysisTool	Great Lakes Climate Atlas	http://toolkit.climate.gov/tool/great-lakes-climate-atlas
Socioeconomic Risks	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Income	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Income	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Income	hasAnalysisTool	Excessive Heat Events Guidebook	http://toolkit.climate.gov/tool/excessive-heat-events-guidebook
Income	hasAnalysisTool	Great Lakes Climate Atlas	http://toolkit.climate.gov/tool/great-lakes-climate-atlas
Income	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Income	hasAnalysisTool	Urban Tree Canopy Assessmen	http://toolkit.climate.gov/tool/urban-tree-canopy-assessment
Housing	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Education	hasAnalysisTool	Great Lakes Climate Atlas	http://toolkit.climate.gov/tool/great-lakes-climate-atlas
Education			
Health Care Access	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit
Infrastructure	hasAnalysisTool	Great Lakes Climate Atlas	http://toolkit.climate.gov/tool/great-lakes-climate-atlas
Infrastructure	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit
Hospital	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Energy Demand			
Urban Development			
Electricity Distribution			
AC Use	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Cooling Centers			
Energy Production/Use			
Exposure	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Location	hasAnalysisTool	Assessing Health Vulnerability to Climate Change: A Guide for Health Departments	http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments
Location	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Location	hasAnalysisTool	Excessive Heat Events Guidebook	http://toolkit.climate.gov/tool/excessive-heat-events-guidebook
Drought-Striken Areas	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Drought-Striken Areas	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Drought-Striken Areas	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
Drought-Striken Areas	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Drought-Striken Areas	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Drought-Striken Areas	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Wildfire Prone Areas	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Wildfire Prone Areas	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Wildfire Prone Areas	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Wildfire Prone Areas	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Low-lying Areas			
Urban Areas	hasAnalysisTool	Urban Tree Canopy Assessmen	http://toolkit.climate.gov/tool/urban-tree-canopy-assessment
Urban Areas	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Urban Areas	hasAnalysisTool	Excessive Heat Events Guidebook	http://toolkit.climate.gov/tool/excessive-heat-events-guidebook
Land Cover	hasAnalysisTool	Great Lakes Climate Atlas	http://toolkit.climate.gov/tool/great-lakes-climate-atlas
Land Cover	hasAnalysisTool	Urban Tree Canopy Assessmen	http://toolkit.climate.gov/tool/urban-tree-canopy-assessment
Land Cover	hasAnalysisTool	Coastal Change Analysis Program (C-CAP) Land Cover Atlas	http://toolkit.climate.gov/tool/coastal-change-analysis-program-c-cap-land-cover-atlas
Response	hasAnalysisTool	Excessive Heat Events Guidebook	http://toolkit.climate.gov/tool/excessive-heat-events-guidebook
Response	hasAnalysisTool	Recognizing, Preventing, and Treating Heat-Related Illness	http://toolkit.climate.gov/tool/recognizing-preventing-and-treating-heat-related-illness
Response	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit
Response	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign
Future Projections	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Future Projections	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Future Projections	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Historical Analysis	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Historical Analysis	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Historical Analysis	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
Data Monitoring			
Climate Indicators	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Climate Indicators	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
Climate Indicators	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Humidity			
Local Temperature Averages	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Wet-Bulb Temperature	hasAnalysisTool	Recognizing, Preventing, and Treating Heat-Related Illness	http://toolkit.climate.gov/tool/recognizing-preventing-and-treating-heat-related-illness
Heat Index	hasAnalysisTool	Heat Safety Tool	http://toolkit.climate.gov/tool/heat-safety-tool
Heat Index	hasAnalysisTool	Recognizing, Preventing, and Treating Heat-Related Illness	http://toolkit.climate.gov/tool/recognizing-preventing-and-treating-heat-related-illness
Temperature	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Temperature	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Temperature	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Temperature	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
Temperature	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Temperature	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Temperature	hasAnalysisTool	Heat Safety Tool	http://toolkit.climate.gov/tool/heat-safety-tool
Temperature	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Heating/Cooling Degree Days	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Heating/Cooling Degree Days	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
