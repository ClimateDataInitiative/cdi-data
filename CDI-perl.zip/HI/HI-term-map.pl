#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
use Text::Unidecode;
$F1 = "C:\\db\\gsfc\\HI\\HI-load-term-map.sql";
$Sql1="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<DATA>) 	{
	$DoWrite = 1;
	chomp;
	($Term,$Relationship,$Dataset,$URI) = split(/\t/);
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term ne "") {
		if ($Dataset eq "") {
			$DoWrite = 0;
	}
	$Dataset = trim($Dataset);
	$Dataset = unidecode($Dataset);
	$Dataset =~ s/'/''/g;		#Escape single quotes
	$Dataset =~ s/"/''/g;		#Escape double quotes
	$Dataset =~ s/\x0a//g;  # 
	$Dataset =~ s/\x0d//g;  # 
	if ($URI eq "") {
		$DoWrite = 0;
	}
	$URI= trim($URI);
	$Dataset =~ s/'/''/g;		#Escape single quotes
	$Dataset =~ s/"/''/g;		#Escape double quotes
	$URI =~ s/\x0a//g;  # 
	$URI =~ s/\x0d//g;  # 
	$Relationship = trim($Relationship);
	if ($DoWrite) {
		$Sql1 = "INSERT INTO term_map (term_identifier, relationship_identifier, gcid, description) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = ";
		$OutLine=<<EOM;
$Sql1'$Term' and s.lexicon_identifier = 'cdi'), '$Relationship', '$URI', '$Dataset');
EOM
		print OUT "$OutLine";
		}
	}
}
close OUT;
system "$ENV{'ED'} $F1"
#Subject	Predicate	Relationship	Object
#Term	Relationship	Datasets	extURI		
#xtermid	contextid	Term	Relationship	Datasets	extURI



#Trim the two blank tabs after pasting 
__DATA__
Health	isMentionedIn		https://catalog.data.gov/dataset?vocab_category_all=Human+Health&groups=climate5434#topic=humanhealth_navigation
Heat Illness			
Human Vulnerability	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Human Vulnerability	isMentionedIn	CDC WONDER: Cancer Statistics 	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	"https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths"
Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Human Vulnerability	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
Human Vulnerability	isMentionedIn	Designated Health Professional Shortage Areas	http://catalog.data.gov/dataset/designated-health-professional-shortage-areas
Human Vulnerability	isMentionedIn	Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas
Human Vulnerability	isMentionedIn	Global Annual Average PM2.5 Grids from MODIS and MISR Aerosol Optical Depth (AOD)	http://catalog.data.gov/dataset/global-annual-average-pm2-5-grids-from-modis-and-misr-aerosol-optical-depth-aod
Human Vulnerability	isMentionedIn	Gridded Population of the World- Version 2 (GPWv2)	http://catalog.data.gov/dataset/gridded-population-of-the-world-version-2-gpwv2-74527
Human Vulnerability	isMentionedIn	HCUPnet	http://catalog.data.gov/dataset/hcupnet
Human Vulnerability	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Human Vulnerability	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
Human Vulnerability	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
Human Vulnerability	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Adaptive Capacity			
Adaptation			
Acclimatization			
Physical Heat Tolerance			
Health Risks	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Health Risks	isMentionedIn	Drinking Water Treatability Database (TDB)	https://catalog.data.gov/dataset/drinking-water-treatability-database-tdb
Health Risks	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Health Risks	isMentionedIn	FluView National Flu Activity Map	https://catalog.data.gov/dataset/fluview-national-flu-activity-map
Health Risks	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Cancer Statistics	http://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Heat Stroke			
Mortality	isMentionedIn	CDC WONDER: Cancer Statistics	http://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Mortality	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Mortality	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Mortality	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Mortality	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Mortality	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Mortality	isMentionedIn	Designated Health Professional Shortage Areas	http://catalog.data.gov/dataset/designated-health-professional-shortage-areas
Mortality	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Mortality	isMentionedIn	National Death Index	http://catalog.data.gov/dataset/national-death-index
Mortality	isMentionedIn	VitalStats	http://catalog.data.gov/dataset/vitalstats
Hyperthermia	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Hyperthermia	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Hyperthermia	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Hyperthermia	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Hyperthermia	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Heat Cramps			
Heat Exhaustion			
Existing Medical Conditions	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
Cardiovascular Disorders	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Cardiovascular Disorders	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Cardiovascular Disorders	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Cardiovascular Disorders	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Cardiovascular Disorders	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Cardiovascular Disorders	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Cardiovascular Disorders	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Cardiovascular Disorders	isMentionedIn	Global Annual Average PM2.5 Grids from MODIS and MISR Aerosol Optical Depth (AOD)	https://catalog.data.gov/dataset/global-annual-average-pm2-5-grids-from-modis-and-misr-aerosol-optical-depth-aod
Cardiovascular Disorders	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Mental Illness	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Mental Illness	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Mental Illness	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Mental Illness	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Mental Illness	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Mental Illness	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Mental Illness	isMentionedIn	Mental Health Treatement Facilities Locator	https://catalog.data.gov/dataset/mental-health-treatement-facilities-locator
Kidney Disorders	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Kidney Disorders	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Kidney Disorders	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Kidney Disorders	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Kidney Disorders	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Kidney Disorders	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Asthma	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Asthma	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Asthma	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Asthma	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Asthma	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Asthma	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Asthma	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Alzheimer's Disease	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Alzheimer's Disease	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Alzheimer's Disease	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Alzheimer's Disease	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Alzheimer's Disease	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Substance Abuse	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Substance Abuse	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Substance Abuse	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Substance Abuse	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Substance Abuse	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Substance Abuse	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Substance Abuse	isMentionedIn	Mental Health Treatement Facilities Locator	https://catalog.data.gov/dataset/mental-health-treatement-facilities-locator
COPD	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
COPD	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
COPD	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
COPD	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
COPD	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
COPD	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Obesity	isMentionedIn	Food Environment Atlas	http://catalog.data.gov/dataset/food-environment-atlas-f4a22
Obesity	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
Obesity	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Obesity	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Obesity	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Obesity	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Obesity	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Cardiovascular Disease	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Cardiovascular Disease	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Cardiovascular Disease	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Cardiovascular Disease	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Cardiovascular Disease	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Cardiovascular Disease	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Cardiovascular Disease	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Diabetes	isMentionedIn	Food Environment Atlas	http://catalog.data.gov/dataset/food-environment-atlas-f4a23
Diabetes	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Diabetes	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Diabetes	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Diabetes	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Diabetes	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Diabetes	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Diabetes	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Stress	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Stress	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Stress	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Stress	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Stress	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Dementia	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Dementia	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Dementia	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Dementia	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Dementia	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Respiratory Disease	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Respiratory Disease	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Respiratory Disease	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Respiratory Disease	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Respiratory Disease	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Respiratory Disease	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Mood Disorders	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Mood Disorders	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Mood Disorders	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Mood Disorders	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Mood Disorders	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Mood Disorders	isMentionedIn	Mental Health Treatement Facilities Locator	https://catalog.data.gov/dataset/mental-health-treatement-facilities-locator
Functional Disabilities			
Renal Illness	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Renal Illness	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Renal Illness	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Renal Illness	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Renal Illness	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Renal Illness	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Neurosis	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Neurosis	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Neurosis	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Neurosis	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Neurosis	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Populations at Risk	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Populations at Risk	isMentionedIn	CDC WONDER: Cancer Statistics 	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Populations at Risk	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	"https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths"
Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates
Populations at Risk	isMentionedIn	Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas
Populations at Risk	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Populations at Risk	isMentionedIn	Food Environment Atlas	http://catalog.data.gov/dataset/food-environment-atlas-f4a22
Populations at Risk	isMentionedIn	Pesticide Data Program 2008	http://catalog.data.gov/dataset/pesticide-data-program-2008
Populations at Risk	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
Populations at Risk	isMentionedIn	Supplemental Nutrition Assistance Program (SNAP) Data System	http://catalog.data.gov/dataset/supplemental-nutrition-assistance-program-snap-data-system-a2b49
Populations at Risk	isMentionedIn	VitalStats	http://catalog.data.gov/dataset/vitalstats
Children	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Children	isMentionedIn	CDC WONDER: Cancer Statistics	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Children	isMentionedIn	CDC WONDER: Cancer Statistics	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Children	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Children	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Children	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death#sec-dates
Children	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Children	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Children	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
Children	isMentionedIn	Pesticide Data Program 2008	http://catalog.data.gov/dataset/pesticide-data-program-2008
Children	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
Children	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Pregnant	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
Pregnant	isMentionedIn	VitalStats	https://catalog.data.gov/dataset/vitalstats
Elderly	isMentionedIn	CDC WONDER: Cancer Statistics	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Elderly	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Elderly	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Elderly	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Elderly	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Elderly	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Elderly	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
Elderly	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Race/Ethnicity	isMentionedIn	CDC WONDER: Cancer Statistics	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Race/Ethnicity	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Race/Ethnicity	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Race/Ethnicity	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Race/Ethnicity	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Race/Ethnicity	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Race/Ethnicity	isMentionedIn	CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates
Race/Ethnicity	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
Race/Ethnicity	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	https://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Race/Ethnicity	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Race/Ethnicity	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
Race/Ethnicity	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Non-Hispanic Blacks	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Occupation	isMentionedIn	Quick Stats Agricultural Database API	https://catalog.data.gov/dataset/quick-stats-agricultural-database-api
Hispanics	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Hispanics	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Hispanics	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Hispanics	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Hispanics	isMentionedIn	CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates
Hispanics	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Hispanics	isMentionedIn	Quick Stats Agricultural Database API	https://catalog.data.gov/dataset/quick-stats-agricultural-database-api
Hispanics	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
Hispanics	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Outdoor Workers			
Highschool Football Players			
Socioeconomic Risks	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Socioeconomic Risks	isMentionedIn	Food Access Research Atlas	http://catalog.data.gov/dataset/food-access-research-atlas
Socioeconomic Risks	isMentionedIn	Food Environment Atlas	https://catalog.data.gov/dataset/food-environment-atlas-f4a22
Socioeconomic Risks	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Socioeconomic Risks	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
Socioeconomic Risks	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Income	isMentionedIn	Food Security in the United States	https://catalog.data.gov/dataset/food-security-in-the-united-states
Income	isMentionedIn	Designated Health Professional Shortage Areas	http://catalog.data.gov/dataset/designated-health-professional-shortage-areas
Income	isMentionedIn	Food Access Research Atlas	https://catalog.data.gov/dataset/food-access-research-atlas
Income	isMentionedIn	Food Environment Atlas	https://catalog.data.gov/dataset/food-environment-atlas-f4a22
Income	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
Income	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Income	isMentionedIn	Supplemental Nutrition Assistance Program (SNAP) Data System	http://catalog.data.gov/dataset/supplemental-nutrition-assistance-program-snap-data-system-a2b49
Housing 	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Housing 	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
Housing 	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Housing 	isMentionedIn	Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas
Education	isMentionedIn	Statistical Abstract of the United States	https://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Education	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Education	isMentionedIn	National Death Index	https://catalog.data.gov/dataset/national-death-index
Education	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Health Care Access	isMentionedIn	Designated Health Professional Shortage Areas	https://catalog.data.gov/dataset/designated-health-professional-shortage-areas
Health Care Access	isMentionedIn	HCUPnet	https://catalog.data.gov/dataset/hcupnet
Health Care Access	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
Health Care Access	isMentionedIn	Mental Health Treatement Facilities Locator	https://catalog.data.gov/dataset/mental-health-treatement-facilities-locator
Health Care Access	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Infrastructure	isMentionedIn	USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	https://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass
Infrastructure	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Hospital	isMentionedIn	CMS Statistics	https://catalog.data.gov/dataset/cms-statistics
Hospital	isMentionedIn	Designated Health Professional Shortage Areas	https://catalog.data.gov/dataset/designated-health-professional-shortage-areas
Hospital	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	https://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Hospital	isMentionedIn	HCUPnet	http://catalog.data.gov/dataset/hcupnet
Hospital	isMentionedIn	National Health Expenditures - State (Provider)	https://catalog.data.gov/dataset/national-health-expenditures-state-provider
Hospital	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
Hospital	isMentionedIn	USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	https://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass
Hospital	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Energy Demand			
Urban Development			
Electricity Distribution			
AC Use			
Cooling Centers			
Energy Production/Use			
Exposure	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Exposure	isMentionedIn	Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper
Exposure	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Location	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Location	isMentionedIn	CDC WONDER: Daily Fine Particulate Matter	http://catalog.data.gov/dataset/cdc-wonder-daily-fine-particulate-matter
Location	isMentionedIn	Clean Air Markets - Where You Live (National and State Maps)	http://catalog.data.gov/dataset/clean-air-markets-where-you-live-national-and-state-maps
Location	isMentionedIn	Clean Air Status and Trends Network (CASTNET)	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet
Location	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Location	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Location	isMentionedIn	Fire Weather Outlooks 	http://catalog.data.gov/dataset/fire-weather-outlooks
Location	isMentionedIn	FluView National Flu Activity Map	http://catalog.data.gov/dataset/fluview-national-flu-activity-map
Location	isMentionedIn	National Flood Hazard Layer (NFHL)	http://catalog.data.gov/dataset/national-flood-hazard-layer-nfhl
Location	isMentionedIn	National Integrated Drought Information System	http://catalog.data.gov/dataset/national-integrated-drought-information-system
Location	isMentionedIn	National Weather Service County Warning Area Boundaries	http://catalog.data.gov/dataset/national-weather-service-county-warning-area-boundaries
Location	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Location	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries 	http://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
Location	isMentionedIn	Report on U.S. Methane Emissions 1990-2020: Inventories- Projections- and Opportunities for Reductions: 2001 Updated emission and cost estimates	http://catalog.data.gov/dataset/report-on-u-s-methane-emissions-1990-2020-inventories-projections-and-opportunitie
Drought-Striken Areas	isMentionedIn	National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system
Drought-Striken Areas	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Drought-Striken Areas	isMentionedIn	WaterWatch -- Current Water Resources Conditions	http://catalog.data.gov/dataset/waterwatch-current-water-resources-conditions
Drought-Striken Areas	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	http://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
Drought-Striken Areas	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
Drought-Striken Areas	isMentionedIn	Integrated Surface Global Hourly Data	https://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Drought-Striken Areas	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
Drought-Striken Areas	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Wildfire Prone Areas	isMentionedIn	LandCarbon Conterminous United States Burned Area and Severity Mosaics 2001-2050 Metadata	https://catalog.data.gov/dataset/landcarbon-conterminous-united-states-burned-area-and-severity-mosaics-2001-2050-metadata
Wildfire Prone Areas	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Wildfire Prone Areas	isMentionedIn	National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system
Wildfire Prone Areas	isMentionedIn	Fire Weather Outlooks	https://catalog.data.gov/dataset/fire-weather-outlooks
Low-lying Areas	isMentionedIn	Coastal Tribal Lands	https://catalog.data.gov/dataset/coastal-tribal-lands
Low-lying Areas	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	http://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
Low-lying Areas	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Low-lying Areas	isMentionedIn	USGS Map service: Coastal Vulnerability to Sea-Level Rise	http://catalog.data.gov/dataset/usgs-map-service-coastal-vulnerability-to-sea-level-rise
Low-lying Areas	isMentionedIn	Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper
Urban Areas	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Urban Areas	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Urban Areas	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Urban Areas	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Urban Areas	isMentionedIn	Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas
Land Cover	isMentionedIn	CropScape - Cropland Data Layer	https://catalog.data.gov/dataset/cropscape-cropland-data-layer
Land Cover	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Land Cover	isMentionedIn	EnviroAtlas - Clean and Plentiful Water Metrics for the Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-and-plentiful-water-metrics-for-the-conterminous-united-states
Land Cover	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	https://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Land Cover	isMentionedIn	LandCarbon Conterminous United States Burned Area and Severity Mosaics 2001-2050 Metadata	https://catalog.data.gov/dataset/landcarbon-conterminous-united-states-burned-area-and-severity-mosaics-2001-2050-metadata
Land Cover	isMentionedIn	NOAA Climate Data Record (CDR) of Normalized Difference Vegetation Index (NDVI), Version 4	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-normalized-difference-vegetation-index-ndvi-version-4
Land Cover	isMentionedIn	USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	https://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass
Response			
Future Projections	isMentionedIn	LandCarbon Conterminous United States Burned Area and Severity Mosaics 2001-2050 Metadata	https://catalog.data.gov/dataset/landcarbon-conterminous-united-states-burned-area-and-severity-mosaics-2001-2050-metadata
Future Projections	isMentionedIn	Methane Flux	https://catalog.data.gov/dataset/methane-flux
Future Projections	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
Future Projections	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	http://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Historical Analysis	isMentionedIn	Air Markets Program Data (AMPD)	https://catalog.data.gov/dataset/air-markets-program-data-ampd
Historical Analysis	isMentionedIn	Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis
Historical Analysis	isMentionedIn	Climate Reconstructions	http://catalog.data.gov/dataset/climate-reconstructions
Historical Analysis	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Historical Analysis	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Historical Analysis	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
Historical Analysis	isMentionedIn	Global Surface Summary of the Day - GSOD	http://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Historical Analysis	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
Historical Analysis	isMentionedIn	U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries
Historical Analysis	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Historical Analysis	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Historical Analysis	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Historical Analysis	isMentionedIn	U.S. Hourly Precipitation Data	http://catalog.data.gov/dataset/u-s-hourly-precipitation-data
Historical Analysis	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Historical Analysis	isMentionedIn	United States Average Annual Precipitation- 1990-2009 - Direct Download	http://catalog.data.gov/dataset/united-states-average-annual-precipitation-1990-2009-direct-download
Data Monitoring	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Data Monitoring	isMentionedIn	Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis
Data Monitoring	isMentionedIn	Drainage Basins Used for Assessing Trends in Concentration of Pesticides in Streams of the United States, 1992-2010	https://catalog.data.gov/dataset/drainage-basins-used-for-assessing-trends-in-concentration-of-pesticides-in-streams-o-1992-2010
Data Monitoring	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Data Monitoring	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
Data Monitoring	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	http://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Data Monitoring	isMentionedIn	LandCarbon Conterminous United States Burned Area and Severity Mosaics 2001-2050 Metadata	https://catalog.data.gov/dataset/landcarbon-conterminous-united-states-burned-area-and-severity-mosaics-2001-2050-metadata
Data Monitoring	isMentionedIn	National Animal Health Monitoring System	https://catalog.data.gov/dataset/national-animal-health-monitoring-system
Data Monitoring	isMentionedIn	National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system
Data Monitoring	isMentionedIn	National Status and Trends: Mussel Watch Program	https://catalog.data.gov/dataset/national-status-and-trends-mussel-watch-program
Data Monitoring	isMentionedIn	NOAA Climate Data Record (CDR) of Leaf Area Index (LAI) and Fraction of Absorbed Photosynthetically Active Radiation (FAPAR)- Version 4	http://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-leaf-area-index-lai-and-fraction-of-absorbed-photosynthetically
Data Monitoring	isMentionedIn	NOAA Climate Data Record (CDR) of Normalized Difference Vegetation Index (NDVI)- Version 4	http://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-normalized-difference-vegetation-index-ndvi-version-4
Data Monitoring	isMentionedIn	NOAA NCCOS: New England Red Tide Research	https://catalog.data.gov/dataset/noaa-nccos-new-england-red-tide-research
Climate Indicators	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	https://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Climate Indicators	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Climate Indicators	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Climate Indicators	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
Climate Indicators	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Climate Indicators	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Climate Indicators	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Climate Indicators	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Climate Indicators	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Climate Indicators	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
Climate Indicators	isMentionedIn	Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis
Climate Indicators	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
Climate Indicators	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Climate Indicators	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
Climate Indicators	isMentionedIn	Global Climate Station Summaries	https://catalog.data.gov/dataset/global-climate-station-summaries
Climate Indicators	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Climate Indicators	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
Climate Indicators	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Climate Indicators	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
Climate Indicators	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
Climate Indicators	isMentionedIn	United States Average Annual Precipitation, 1990-2009 - Direct Download	https://catalog.data.gov/dataset/united-states-average-annual-precipitation-1990-2009-direct-download
Climate Indicators	isMentionedIn	U.S. Hourly Precipitation Data	https://catalog.data.gov/dataset/u-s-hourly-precipitation-data
Humidity	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Humidity	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Humidity	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Humidity	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
Humidity	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Humidity	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Humidity	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Humidity	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Humidity	isMentionedIn	Fire Weather Outlooks	https://catalog.data.gov/dataset/fire-weather-outlooks
Local Temperature Averages	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
Local Temperature Averages	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Local Temperature Averages	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Local Temperature Averages	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Local Temperature Averages	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Local Temperature Averages	isMentionedIn	U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries
Local Temperature Averages	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Local Temperature Averages	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
Local Temperature Averages	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Local Temperature Averages	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Local Temperature Averages	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Wet-Bulb Temperature	isMentionedIn	Integrated Surface Global Hourly Data	https://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Wet-Bulb Temperature	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Heat Index	isMentionedIn	CDC WONDER: Daily Air Temperatures and Heat Index	https://catalog.data.gov/dataset/cdc-wonder-daily-air-temperatures-and-heat-index
Heat Index	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Temperature	isMentionedIn	CDC WONDER: Daily Air Temperatures and Heat Index	https://catalog.data.gov/dataset/cdc-wonder-daily-air-temperatures-and-heat-index
Temperature	isMentionedIn	CDC WONDER: Daily Fine Particulate Matter	https://catalog.data.gov/dataset/cdc-wonder-daily-fine-particulate-matter
Temperature	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Temperature	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
Temperature	isMentionedIn	Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis
Temperature	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
Temperature	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Temperature	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
Temperature	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Temperature	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Temperature	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
Temperature	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Temperature	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	https://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Temperature	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Temperature	isMentionedIn	National Integrated Drought Information System	http://catalog.data.gov/dataset/national-integrated-drought-information-system
Temperature	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Temperature	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
Temperature	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
Temperature	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Temperature	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
Temperature	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Temperature	isMentionedIn	U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries
Temperature	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Temperature	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Temperature	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Temperature	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Temperature	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Temperature	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Temperature	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Temperature	isMentionedIn	USGS Water-Quality Data for the Nation - National Water Information System (NWIS)	https://catalog.data.gov/dataset/usgs-water-quality-data-for-the-nation-national-water-information-system-nwis
Heating/Cooling Degree Days	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Heating/Cooling Degree Days	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Heating/Cooling Degree Days	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Heating/Cooling Degree Days	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Heating/Cooling Degree Days	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	https://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Heating/Cooling Degree Days	isMentionedIn	U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries
Heating/Cooling Degree Days	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
