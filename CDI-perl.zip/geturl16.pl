use LWP::UserAgent;

$url = $ARGV[0];    #File to Snarf
$f1  = $ARGV[1];    #Where to Stash it

if ($url eq "") {
   print "\nFormat:\n\nsnarf [file to snarf] [where to stash it (default c:\\snarf.htm)]\n\n";
   exit 1;
}

if ($f1 eq "") {
   $f1 = "c:\\temp\\snarf.htm";
}

print "Getting $url\n\n";


  $ua = new LWP::UserAgent;
  $ua->agent("$0/0.1 " . $ua->agent);
  $ua->agent("Vince Wilding's Snarfilator (VCFW)");

  $req = new HTTP::Request 'GET' => "$url";
  $req->header('Accept' => 'text/html');

  # send request
  $res = $ua->request($req);

  # check the outcome
  if ($res->is_success) {
    open (FILE,">$f1");
    print FILE $res->content;;
    close (FILE);
#    print $res->content;
#    system "Q $f1";
  } else {
     print "Error: " . $res->status_line . "\n";
  }

