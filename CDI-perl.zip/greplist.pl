while (<DATA>) {
	chomp;
	$cmd = "grep constant " . $_;
	print $_."\n";
	system $cmd;
}
__DATA__
c:\db\Home\perlarch\perl\site\lib\vcfw.pm
c:\perlarch\perl\site\lib\vcfw.pm
d:\obpg\home\vwilding\vcfwperl\Perl64\lib\vcfw.pm
d:\obpg\home\vwilding\vcfw.pm
d:\obpg\home\vwilding\bin\lib\vcfw.pm
c:\db\Home\perlstuff\lib\vcfw.pm
d:\obpg\home\vwilding\bin\vcfw.pm
c:\db\GSFC\OBPG\vcfw\bin\vcfw.pm
c:\plib\vcfw.pm
