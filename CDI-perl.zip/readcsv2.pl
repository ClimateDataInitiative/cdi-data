#!/usr/bin/env perl -w
use strict;
use warnings;

use Text::CSV_XS;
my $F1 = "c:\\db\\gsfc\\term_sample2.csv";
my $F2 = "c:\\db\\gsfc\\term_sample2a.sql";
my $Edit = $ENV{'ED'};
print "[$Edit]\n";


my $RecNo=0;
my $ThisValue = "";
my $ThisColumn = "";

open (my $CSV_FH, "<", $F1) or die "choke on open $F1: $!";
open (OUT_FH, ">", $F2) or die "choke on open $F2: $!";

my $csv = Text::CSV_XS->new ( { binary => 1 } )    #binary for mulitline fields
           or die "Cannot use Text::CSV " . Text::CSV->error_diag ();

$csv->column_names ($csv->getline($CSV_FH));    #define column names from first line

while (my $rowhash = $csv->getline_hr($CSV_FH)) {
	my $InsertNames = "";
	my $InsertValues = "";
	$RecNo++;
	foreach my $field ($csv->column_names) {      #column names in order
		$ThisColumn = $field;
		$ThisValue = $rowhash->{$field};
		$ThisValue =~ s/\n/ /g;
		if ($ThisColumn eq "xtermid") {
			$ThisValue = $RecNo;
			$InsertNames .= "$ThisColumn,";
			$InsertValues .= "$ThisValue,";
		} else {
			$InsertNames .= "$ThisColumn,";
			$InsertValues .= "\"$ThisValue\",";
		}
	}  #End of Row
	$InsertNames =~ s/,$//;  #delete final comma
	$InsertValues =~ s/,$//;  #delete final comma
	print OUT_FH<<EOM;
-- RecNo $RecNo
INSERT INTO TERM ( $InsertNames )
VALUES ( $InsertValues )
--

EOM
}
close $CSV_FH;
close OUT_FH;
system "$Edit $F1 $F2";
