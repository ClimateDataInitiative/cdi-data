#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\WI-load-term-map-crt-2.sql";

$SqlStatement="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
#Term	Relationship	Datasets	extURI
#Term	Relationship	Datasets	extURI	Regions

	 ($Term,$Relationship,$Datasets,$extURI) = split(/\t/);
	$DoWrite = 1;
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term eq "") {
		$ThisTerm = $OldTerm
	} else {
		$ThisTerm = $OldTerm = $Term;
	}
	$Datasets = trim($Datasets);
	$Datasets =~ s/'/''/g;		#Escape single quotes
	if ($Datasets eq "") {
		$DoWrite=0;
	}

	$extURI= trim($extURI);
	if ($extURI eq "") {
		$DoWrite=0;
	}

#Term	Relationship	Datasets	extURI	Regions

	if ($DoWrite) {
		$SqlStatement =<<EOM;
INSERT INTO term_map (term_id, relationship, description ,gcid) 
	VALUES ((SELECT s.id FROM term AS s WHERE s.term = '$ThisTerm' and s.lexicon_identifier = 'cdi'), 
	'$Relationship', '$Datasets', '$extURI');

EOM
		print OUT "$SqlStatement";
	}
}
close OUT;
system "$ENV{'ED'} $F1"
#Subject	Predicate	Relationship	Object
#Term	Relationship	Datasets	extURI	Regions

__DATA__
Health	hasCaseStudy		http://toolkit.climate.gov/taking-action	
Health	hasAnalysisTool		http://toolkit.climate.gov/tools?f[0]=field_parent_topic%3A116	
Water Related Illnesses				
Human Vulnerability	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall	midwest-us
Human Vulnerability	hasAnalysisTool	Assessing Health Vulnerability to Climate Change: A Guide for Health Departments	http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us
Human Vulnerability	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Human Vulnerability	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit	
Socioeconomic Risks	hasAnalysisTool	Great Lakes Climate Atlas	http://toolkit.climate.gov/tool/great-lakes-climate-atlas	midwest-us
Socioeconomic Risks	hasAnalysisTool	Hazus-MH	http://toolkit.climate.gov/tool/hazus	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us; Alaska-us
Socioeconomic Risks	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Social Mores				
Health Care Access	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit	
Employment				
Poverty				
Education				
Language				
Housing	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Environment				
Transportation	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Populations at Risk	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Indigenous People				
Pregnant				
Race/Ethnicity	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Age				
Sex/Gender				
Response	hasAnalysisTool	Arctic Adaptation Exchange	http://toolkit.climate.gov/tool/arctic-adaptation-exchange	Alaska-us
Response	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages	Alaska-us
Response	hasCaseStudy	Alaskan Tribes Join Together to Assess Harmful Algal Blooms	http://toolkit.climate.gov/taking-action/alaskan-tribes-join-together-monitor-harmful-algal-blooms	Alaska-us
Response	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change	southwest-us
Response	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign	southeast-us; northeast; southwest-us; northwest-us; midwest-us; oceans; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Response	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Response	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather	
Planning	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages	Alaska-us
Planning	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt	southwest-us
Planning	hasAnalysisTool	Hazus-MH	http://toolkit.climate.gov/tool/hazus	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us; Alaska-us
Planning	hasCaseStudy	Planning for the Future in a Floodplain	http://toolkit.climate.gov/taking-action/planning-future-floodplain	southwest-us
Planning	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat	midwest-us
Planning	hasAnalysisTool	Flood Resilience: A Basic Guide for Water and Wastewater Utilities	http://toolkit.climate.gov/tool/flood-resilience-basic-guide-water-and-wastewater-utilities	
Planning	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign	southeast-us; northeast; southwest-us; northwest-us; midwest-us; oceans; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Planning	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Planning	hasAnalysisTool	Storm Water Management Model	http://toolkit.climate.gov/tool/storm-water-management-model	
Planning	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit	
Planning	hasAnalysisTool	U.S. Drought Portal	http://toolkit.climate.gov/tool/us-drought-portal	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Planning	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Planning	hasAnalysisTool	EJSCREEN: Environmental Justice Screening and Mapping Tool	http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool	southeast-us; northeast; southwest-us; northwest-us; oceans; midwest-us; greatplains-us; hawaii-pacific-us; Alaska-us
Planning	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather	
Planning	hasAnalysisTool	Tribal-Focused Environmental Risk and Sustainability Tool (Tribal-FERST)	http://toolkit.climate.gov/tool/tribal-focused-environmental-risk-and-sustainability-tool-tribal-ferst	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us; Alaska-us
Urban Growth				
Nuisance Flooding				
Storm Shelters	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Mitigation	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall	midwest-us
Mitigation	hasAnalysisTool	Flood Resilience: A Basic Guide for Water and Wastewater Utilities	http://toolkit.climate.gov/tool/flood-resilience-basic-guide-water-and-wastewater-utilities	
Mitigation	hasAnalysisTool	Hazus-MH	http://toolkit.climate.gov/tool/hazus	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us; Alaska-us
Mitigation	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Agricultural Management Practices				
Health Surveillance System				
Shellfish Bed Closure				
Notification	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather	
Notification	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign	southeast-us; northeast; southwest-us; northwest-us; midwest-us; oceans; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Reporting Capacity				
Hydrology	hasCaseStudy	Developing and Using an Index to Guide Water Supply Decisions	http://toolkit.climate.gov/taking-action/developing-and-using-index-guide-water-supply-decisions	southeast-us
Hydrology	hasAnalysisTool	Storm Water Management Model	http://toolkit.climate.gov/tool/storm-water-management-model	
Discharge				
Watershed	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall	midwest-us
Nutrient Loading				
Turbidity				
Stream Flow	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall	midwest-us
Eutrophication				
Residence Time				
Harmful Algal Blooms (HABs)	hasCaseStudy	Alaskan Tribes Join Together to Assess Harmful Algal Blooms	http://toolkit.climate.gov/taking-action/alaskan-tribes-join-together-monitor-harmful-algal-blooms	Alaska-us
Harmful Algal Blooms (HABs)	hasCaseStudy	Keeping Toxins From Harmful Algal Blooms out of the Food Supply	http://toolkit.climate.gov/taking-action/keeping-toxins-harmful-algal-blooms-out-food-supply	
Harmful Algal Blooms (HABs)	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match	
Infrastructure	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall	midwest-us
Infrastructure	hasCaseStudy	Integrating Education and Stormwater Management for Healthy Rivers and Residents	http://toolkit.climate.gov/taking-action/integrating-education-and-stormwater-management-healthy-rivers-and-residents	midwest-us
Infrastructure	hasCaseStudy	Building Smart in the Floodplain	http://toolkit.climate.gov/taking-action/building-smart-floodplain	southwest-us
Infrastructure	hasCaseStudy	Planning for the Future in a Floodplain	http://toolkit.climate.gov/taking-action/planning-future-floodplain	southwest-us
Infrastructure	hasAnalysisTool	National Stormwater Calculator�Climate Assessment Tool	http://toolkit.climate.gov/tool/national-stormwater-calculator%E2%80%94climate-assessment-tool	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Infrastructure	hasAnalysisTool	Storm Water Management Model	http://toolkit.climate.gov/tool/storm-water-management-model	
Water Purification Systems				
Water Treatment Plants				
Water Distribution Systems	hasAnalysisTool	National Water Information System: Mapper	http://toolkit.climate.gov/tool/national-water-information-system-mapper	southeast-us; northeast; southwest-us; northwest-us; coasts-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Pipelines				
Water Towers				
Water Tanks				
Wastewater System				
Septic Systems	hasAnalysisTool	National Water Information System: Mapper	http://toolkit.climate.gov/tool/national-water-information-system-mapper	southeast-us; northeast; southwest-us; northwest-us; coasts-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Sanitary Sewer Systems	hasAnalysisTool	Storm Water Management Model	http://toolkit.climate.gov/tool/storm-water-management-model	
Wastewater Treatment Plant	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall	midwest-us
Wastewater Treatment Plant	hasAnalysisTool	National Water Information System: Mapper	http://toolkit.climate.gov/tool/national-water-information-system-mapper	southeast-us; northeast; southwest-us; northwest-us; coasts-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Lifts				
Sewer Pipes				
Wastewater Lagoons				
Stormwater Systems	hasCaseStudy	Integrating Education and Stormwater Management for Healthy Rivers and Residents	http://toolkit.climate.gov/taking-action/integrating-education-and-stormwater-management-healthy-rivers-and-residents	midwest-us
Stormwater Systems	hasAnalysisTool	National Stormwater Calculator�Climate Assessment Tool	http://toolkit.climate.gov/tool/national-stormwater-calculator%E2%80%94climate-assessment-tool	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Stormwater Systems	hasAnalysisTool	Storm Water Management Model	http://toolkit.climate.gov/tool/storm-water-management-model	
Combined Sewer Systems				
Wells				
Exposure	hasAnalysisTool	Tribal-Focused Environmental Risk and Sustainability Tool (Tribal-FERST)	http://toolkit.climate.gov/tool/tribal-focused-environmental-risk-and-sustainability-tool-tribal-ferst	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us; Alaska-us
Location	hasCaseStudy	Planning for the Future in a Floodplain	http://toolkit.climate.gov/taking-action/planning-future-floodplain	southwest-us
Geographic Distribution				
Habitat				
CaFOs				
Time				
Seasonal Growth Window				
Pathway				
Recreational Water	hasAnalysisTool	Virtual Beach	http://toolkit.climate.gov/tool/virtual-beach	
Fish				
Shellfish	hasCaseStudy	Alaskan Tribes Join Together to Assess Harmful Algal Blooms	http://toolkit.climate.gov/taking-action/alaskan-tribes-join-together-monitor-harmful-algal-blooms	Alaska-us
Drinking Water	hasCaseStudy	Developing and Using an Index to Guide Water Supply Decisions	http://toolkit.climate.gov/taking-action/developing-and-using-index-guide-water-supply-decisions	southeast-us
Drinking Water	hasCaseStudy	Integrating Education and Stormwater Management for Healthy Rivers and Residents	http://toolkit.climate.gov/taking-action/integrating-education-and-stormwater-management-healthy-rivers-and-residents	midwest-us
Sources				
Human Waste				
Animal Waste				
Agriculture				
Fertilizers				
Contaminants	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match	
Pathogens	hasAnalysisTool	Virtual Beach	http://toolkit.climate.gov/tool/virtual-beach	
Cyanobacteria				
Vibrio	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match	
Cholera	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match	
Cryptosporidium	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match	
Giardia	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match	
Salmonella enterica	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match	
Naegleria				
Leptospira				
Leptonema				
Campylobacter	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match	
Escherichia coli	hasAnalysisTool	Virtual Beach	http://toolkit.climate.gov/tool/virtual-beach	
Enteroviruses				
Rotaviruses				
Noroviruses				
Chemicals	hasCaseStudy	Keeping Toxins From Harmful Algal Blooms out of the Food Supply	http://toolkit.climate.gov/taking-action/keeping-toxins-harmful-algal-blooms-out-food-supply	
Chemicals	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match	
Mercury				
Organohalogens				
Organotins				
Biotoxins				
Ciguatoxins				
Saxitoxins				
Domoic Acids				
Okadaic Acids				
Brevetoxins				
Natural Hazards	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall	midwest-us
Natural Hazards	hasCaseStudy	Integrating Education and Stormwater Management for Healthy Rivers and Residents	http://toolkit.climate.gov/taking-action/integrating-education-and-stormwater-management-healthy-rivers-and-residents	midwest-us
Natural Hazards	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages	Alaska-us
Natural Hazards	hasAnalysisTool	Hazus-MH	http://toolkit.climate.gov/tool/hazus	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us; Alaska-us
Natural Hazards	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign	southeast-us; northeast; southwest-us; northwest-us; midwest-us; oceans; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Natural Hazards	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit	
Natural Hazards	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Natural Hazards	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather	
Natural Hazards	hasAnalysisTool	SERVIR	http://toolkit.climate.gov/tool/servir	
Drought	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages	Alaska-us
Drought	hasAnalysisTool	Advanced Hydrologic Prediction Service	http://toolkit.climate.gov/tool/advanced-hydrologic-prediction-service	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Drought	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance	northwest-us; southwest-us; northeast-us; southeast-us; midwest-us; Alaska-us; greatplains-us ; hawaii-pacific-us
Drought	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Drought	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match	
Drought	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit	
Drought	hasAnalysisTool	U.S. Drought Portal	http://toolkit.climate.gov/tool/us-drought-portal	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Drought	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Runoff	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall	midwest-us
Runoff	hasCaseStudy	Integrating Education and Stormwater Management for Healthy Rivers and Residents	http://toolkit.climate.gov/taking-action/integrating-education-and-stormwater-management-healthy-rivers-and-residents	midwest-us
Runoff	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change	southwest-us
Runoff	hasAnalysisTool	National Stormwater Calculator�Climate Assessment Tool	http://toolkit.climate.gov/tool/national-stormwater-calculator%E2%80%94climate-assessment-tool	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Runoff	hasAnalysisTool	Storm Water Management Model	http://toolkit.climate.gov/tool/storm-water-management-model	
Flooding	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall	midwest-us
Flooding	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages	Alaska-us
Flooding	hasCaseStudy	Building Smart in the Floodplain	http://toolkit.climate.gov/taking-action/building-smart-floodplain	southwest-us
Flooding	hasCaseStudy	Planning for the Future in a Floodplain	http://toolkit.climate.gov/taking-action/planning-future-floodplain	southwest-us
Flooding	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change	southwest-us
Flooding	hasAnalysisTool	Advanced Hydrologic Prediction Service	http://toolkit.climate.gov/tool/advanced-hydrologic-prediction-service	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Flooding	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Flooding	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match	
Flooding	hasAnalysisTool	National Stormwater Calculator�Climate Assessment Tool	http://toolkit.climate.gov/tool/national-stormwater-calculator%E2%80%94climate-assessment-tool	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Flooding	hasAnalysisTool	National Water Information System: Mapper	http://toolkit.climate.gov/tool/national-water-information-system-mapper	southeast-us; northeast; southwest-us; northwest-us; coasts-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Flooding	hasAnalysisTool	FEMA Flood Map Service Center	http://toolkit.climate.gov/tool/fema-flood-map-service-center	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Flooding	hasAnalysisTool	Flood Resilience: A Basic Guide for Water and Wastewater Utilities	http://toolkit.climate.gov/tool/flood-resilience-basic-guide-water-and-wastewater-utilities	
Flooding	hasAnalysisTool	Hazus-MH	http://toolkit.climate.gov/tool/hazus	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us; Alaska-us
Flooding	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign	southeast-us; northeast; southwest-us; northwest-us; midwest-us; oceans; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Flooding	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit	
Flooding	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Storm Surge				
Sea Level Rise	hasCaseStudy	Developing and Using an Index to Guide Water Supply Decisions	http://toolkit.climate.gov/taking-action/developing-and-using-index-guide-water-supply-decisions	southeast-us
Sea Level Rise	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Sea Level Rise	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match	
Hurricanes	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit	
Climate Indicators	hasAnalysisTool	Local Climate Analysis Tool (LCAT)	http://toolkit.climate.gov/tool/local-climate-analysis-tool-lcat	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Climate Indicators	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Climate Indicators	hasAnalysisTool	Storm Water Management Model	http://toolkit.climate.gov/tool/storm-water-management-model	
Sea Surface Temperature				
Temperature	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt	southwest-us
Temperature	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages	Alaska-us
Temperature	hasCaseStudy	Alaskan Tribes Join Together to Assess Harmful Algal Blooms	http://toolkit.climate.gov/taking-action/alaskan-tribes-join-together-monitor-harmful-algal-blooms	Alaska-us
Temperature	hasCaseStudy	Keeping Toxins From Harmful Algal Blooms out of the Food Supply	http://toolkit.climate.gov/taking-action/keeping-toxins-harmful-algal-blooms-out-food-supply	
Temperature	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance	northwest-us; southwest-us; northeast-us; southeast-us; midwest-us; Alaska-us; greatplains-us ; hawaii-pacific-us
Temperature	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat	midwest-us
Temperature	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Temperature	hasAnalysisTool	Local Climate Analysis Tool (LCAT)	http://toolkit.climate.gov/tool/local-climate-analysis-tool-lcat	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Temperature	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Temperature	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit	
Temperature	hasAnalysisTool	U.S. Drought Portal	http://toolkit.climate.gov/tool/us-drought-portal	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Temperature	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Precipitation	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt	southwest-us
Precipitation	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall	midwest-us
Precipitation	hasCaseStudy	Integrating Education and Stormwater Management for Healthy Rivers and Residents	http://toolkit.climate.gov/taking-action/integrating-education-and-stormwater-management-healthy-rivers-and-residents	midwest-us
Precipitation	hasCaseStudy	Planning for the Future in a Floodplain	http://toolkit.climate.gov/taking-action/planning-future-floodplain	southwest-us
Precipitation	hasAnalysisTool	Advanced Hydrologic Prediction Service	http://toolkit.climate.gov/tool/advanced-hydrologic-prediction-service	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Precipitation	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance	northwest-us; southwest-us; northeast-us; southeast-us; midwest-us; Alaska-us; greatplains-us ; hawaii-pacific-us
Precipitation	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat	midwest-us
Precipitation	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Precipitation	hasAnalysisTool	Local Climate Analysis Tool (LCAT)	http://toolkit.climate.gov/tool/local-climate-analysis-tool-lcat	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Precipitation	hasAnalysisTool	National Stormwater Calculator�Climate Assessment Tool	http://toolkit.climate.gov/tool/national-stormwater-calculator%E2%80%94climate-assessment-tool	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Precipitation	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit	
Precipitation	hasAnalysisTool	U.S. Drought Portal	http://toolkit.climate.gov/tool/us-drought-portal	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us; coasts-us
Precipitation	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks	southeast-us; northeast; southwest-us; northwest-us; midwest-us; greatplains-us; hawaii-pacific-us ; Alaska-us
Salinity				
