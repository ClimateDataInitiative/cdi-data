#!perl -w
require "C:\\db\\GSFC\\DoRegions.pm";
$MyGlob = " xxxxx virginia kansas WestVirginia zzzzz alaska";
$Region =DoRegions($MyGlob);
print "Return =[$Region]\n[$MyGlob]\n";

