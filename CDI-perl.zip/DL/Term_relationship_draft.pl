while (<DATA>) {
	chomp;
	($xtermid,$contextid,$Term,$Desciption,$isroot,$extURIverb,$extURIlink) = split (/\t/);
print<<EOM;
xtermid (UUID): $xtermid
contextid:      $contextid
Term:           $Term
Desciption:     $Desciption
is root of:     $isroot
extURIverb:     $extURIverb
extURIlink:     $extURIlink
============
EOM
}
__DATA__
* xtermid (UUID)	* contextid->context.id	Term	Desciption	is root of	extURI	
		Vector Borne Disease	Illnesses that are transmitted by vectors. Vector-borne diseases are illnesses caused by pathogens and parasites in human populations�.Vector-borne diseases account for over 17% of all infectious diseases. Distribution of these diseases is determined by a complex dynamic of environmental and social factors. http://www.who.int/mediacentre/factsheets/fs387/en/	TRUE		
		Human Vulnerability	The degree to which a socio-economic system is either susceptible or resilient to the impact of natural hazards and related technological and environmental disasters. The degree of vulnerability is determined by a combination of several factors including hazard awareness, the condition of human settlements and infrastructure, public policy and administration, and organized abilities in all fields of disaster management. Poverty is also one of the main causes of vulnerability in most parts of the world. (WHO: http://www.who.int /hac/about/definitions/en/) 	FALSE	Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
		Behavioral factors		FALSE		
		Population at risk	Specific group or subgroup that is more likely to be exposed, or is more sensitive to a certain substance than the general population. (Businessdictionary: http://www.businessdictionary.com/definition/population-at-risk.html)	FALSE	CDC WONDER: Cancer Statistics 	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
					CDC WONDER: Compressed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
					CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
					CDC WONDER: Mortality - Infant Deaths	https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
					CDC WONDER: Mortality - Multiple Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
					CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
					CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates
		Socio-economic risk factors	Risks determined by socioeconomic status, which is commonly conceptualized as the social standing or class of an individual or group. It is often measured as a combination of education, income and occupation. (APA: http://www.apa.org/topics/socioeconomic-status/) 	FALSE	CMS Statistics-	https://catalog.data.gov/dataset/cms-statistics
					Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas
					Food Access Research Atlas	https://catalog.data.gov/dataset/food-access-research-atlas
