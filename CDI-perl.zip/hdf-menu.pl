while (<DATA>) {
	chomp;
	$Which = $_;
	print "<li><a href=\"/content/$Which\">$Which</a>\n";
}
__DATA__
ARCTAS
ARMCAS
CLAMS
CLASIC
DISCOVER-AQ
ECO3D
FIREACE
intexb
Kuwait
LEADEX
SAFARI
SCAR-A
SCAR-B
SKUKUZA
TARFOX
