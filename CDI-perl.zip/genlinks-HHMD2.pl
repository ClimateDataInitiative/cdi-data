#!perl -w

use vcfw;
$F1 ="c:\\db\\GSFC\\randall-climate-data-gov-resources.txt";
$F2 ="c:\\db\\GSFC\\randall-climate-data-gov-resources.htm";

open (IN,"<$F1") || die "choke on open $F1:$!\n";
open (OUT,">$F2") || die "choke on open $F1:$!\n";
#open (BAT,">C:\\db\\gsfc\\snarfall2.bat") || die "choke on open snarfall2.bat :$!\n";

$OldGroupH2 = "*";
while (<IN>) {
	chomp;
	$DataIn = $_;
	($Group_Title,$Group_URL,$Resource_Name,$Format,$Mimetype,$data_gov_URL,$Direct_URL) = split (/\t/,$DataIn);
	$Group_Title = trim($Group_Title);
	$Group_URL = trim($Group_URL);
	$Resource_Name = trim($Resource_Name);
	$Format = trim($Format);
	$Mimetype = trim($Mimetype);
	if ($Mimetype eq "") { $Mimetype= "N/A" }
	$data_gov_URL = trim($data_gov_URL);
	$Direct_URL = trim($Direct_URL);
	$GroupH2 = "<a href=\"$Group_URL\">$Group_Title</a></h2>\n";
	if ($OldGroupH2 ne $GroupH2) {
		if ($OldGroupH2 ne "*") {
			$TotGroups++;
			$TotPage .= "<h2>(".$TotGroups . ") " . $OldGroupH2 . $GroupLinks;
			}
			$OldGroupH2 = $GroupH2;
			$GroupLinks="";
	}

	
	$GroupLinks .=<<EOM;
Resource: $Resource_Name | Format: $Format | MIME Type: $Mimetype | <a href="$data_gov_URL">DATA.gov link</a> | <a href="$Direct_URL">Direct Link</a>
<hr>
EOM
	
}
	
	

close IN;
print OUT $TotPage;
close OUT;
system "c:\\progra~2\\editpl~1\\editplus.exe $F2 $F1";
