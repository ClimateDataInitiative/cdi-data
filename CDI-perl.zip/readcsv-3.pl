#!/usr/bin/env perl -w
# Reads CSV output of EXCEL spreadsheet, replaces newlines with spaces, formats into SQL statement
use vcfw;
use strict;
use warnings;
use Text::CSV_XS;
#my $Path = "c:\\gg\\main\\vcfw\\";
my $Path = "c:\\db\\gsfc\\dl\\";
my $DoWrite =1;
#my $FileNameRoot = "TermRelationship_vector_borne_11_20";
#my $FileNameRoot = "TermRelationship_vector_borne_12_22";
my $FileNameRoot = "TermRelationship_vector_borne_2_18_160502";

my $InputFile  = $Path.$FileNameRoot.".csv";
my $OutputFile = $Path.$FileNameRoot."X.sql";
#my $Edit = $ENV{'ED'};
my $Edit = "c:\\progra~2\\editpl~1\\editplus.exe";
my $ThisValue = "";
my $ThisColumn = "";
my $Context= "theme";
#my $DeleteMe = '"","vcfw-cdi-context-id","","","","","",""';   #Delete Blank Lines
#my $DeleteMe = '"","vcfw-cdi-context-id","","","",""';
my $DeleteMe =<<EOM;
"$Context","","","",""
EOM
; #Skip termid, let it default
my $OutCount=0;
my $InputLineNumber = 1;
my $My_identifier = "";
my $My_context_identifier = "";
my $My_term = "";
my $My_description = "";
my $My_is_root = "";
my $My_url = "";
my $My_blank1 = "";
my $My_blank2 = "";
my $My_blank3 = "";
my $My_blank4 = "";
my $My_mesh_description = "";
my $My_mesh_url = "";
my $My_meshid = "";
open (my $CSV_FH, "<",$InputFile) or die "choke on open input $InputFile: $!";
open (OUT_FH, ">",$OutputFile) or die "choke on open output $OutputFile: $!";

my $csv = Text::CSV_XS->new ( { binary => 1 } )    #binary for mulitline fields
           or die "Cannot use Text::CSV " . Text::CSV->error_diag ();

$csv->column_names ($csv->getline($CSV_FH));    #define column names from first line

while (my $rowhash = $csv->getline_hr($CSV_FH)) { # Loop thru file
	my $InsertNames = "";
	my $InsertValues = "";
	$My_identifier = $rowhash->{'identifier'};
	$My_context_identifier = $rowhash->{'context_identifier'};
	$My_term = $rowhash->{'term'};
	$My_description = $rowhash->{'description'};
	$My_is_root = $rowhash->{'is_root'};
	$My_url = $rowhash->{'url'};
	$My_blank1 = $rowhash->{'blank1'};
	$My_blank2 = $rowhash->{'blank2'};
	$My_blank3 = $rowhash->{'blank3'};
	$My_blank4 = $rowhash->{'blank4'};
	$My_mesh_description = $rowhash->{'mesh_description'};
	$My_mesh_url = $rowhash->{'mesh_url'};
	$My_meshid = $rowhash->{'meshid'};
#	print "$T1\n";
	$InputLineNumber++;
	$DoWrite = 1;         #Write only if term is not blank
	foreach my $field ($csv->column_names) {      #column names in order    #Begin processing line of input
		$ThisColumn = trim($field);
		$ThisValue = $rowhash->{$field};
		$ThisValue = trim($ThisValue);
		$ThisValue =~ s/\n/ /g;		#Delete newlines
		$ThisValue =~ s/\x92/''/g;  #Fix UTF8 quote
		$ThisValue =~ s/\x97/\-/g;  #Fix UTF8 dash
		$ThisValue =~ s/\x96/\-/g;  #Fix UTF8 hyphen
		#Special Handling for Special Columns
		if ($ThisColumn eq "context_identifier") {	# need to link to Context.ID
			$ThisValue = "$Context";	# PlaceHolder
		}
		if ($ThisColumn eq "definition") {
			$ThisValue =~ s/"/'/g;		#Double Quotes to single quotes
		}
		if ($ThisColumn eq "blank1" or $ThisColumn eq "blank2" or $ThisColumn eq "blank3" or $ThisColumn eq "blank4") {
			#SkipIt, do nothing
		}

		if (($ThisColumn eq "term") && ($ThisValue eq "")) {
			$DoWrite=0;
			$OutCount--;
		}
		if ($ThisColumn eq "identifier") {
			$OutCount++;
			$InsertNames .= "lexicon_identifier,"; #Skip termid, let it default (was "$ThisColumn,";)
			$InsertValues .= "\"CDI\","; ; #Skip termid, let it default (was "$ThisValue,";)
				} elsif ($ThisColumn ne "blank1" and $ThisColumn ne "blank2" and $ThisColumn ne "blank3" and $ThisColumn ne "blank4") { #Skip Blanks, gen regex later
			$InsertNames .= "$ThisColumn,";
			$InsertValues .= "\"$ThisValue\",";
		}
	}	#End of processing for current row
	$InsertNames =~ s/,$//;		#delete final comma
	$InsertValues =~ s/,$//;	#delete final comma
	if ($DoWrite) {
		print OUT_FH<<EOM;
INSERT INTO TERM ($InsertNames) 
          VALUES ($InsertValues);
EOM
	}  #-- Input Line: $InputLineNumber

}
close $CSV_FH;
close OUT_FH;
system "$Edit $InputFile $OutputFile";
