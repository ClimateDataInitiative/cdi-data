while (<DATA>) {
	chomp;
	$Which = $_;
	print<<EOM

<?php
\$Which = "$Which";
require '/var/www/html/car-dev/listhdf.php';
?>
EOM
}
__DATA__
ARCTAS
ARMCAS
CLAMS
CLASIC
DISCOVER-AQ
ECO3D
FIREACE
intexb
Kuwait
LEADEX
SAFARI
SCAR-A
SCAR-B
SKUKUZA
TARFOX
