#!/usr/bin/env perl -w
# Reads CSV output of EXCEL spreadsheet, replaces newlines with spaces, formats into SQL statement
use vcfw;
#use strict;
use warnings;
use Text::CSV_XS;
use Text::Unidecode;

require "C:\\db\\GSFC\\DoRegions.pm";
#$MyGlob = " xxxxx virginia kansas West Virginia zzzzz alaska";
#$Region =DoRegions($MyGlob);
#print "Return =[$Region]\n[$MyGlob]\n";

my $Path = "c:\\db\\gsfc\\";

my $FileNameRoot = "WI-DOI-8";
my $InputFile  = $Path.$FileNameRoot.".csv";
my $OutputFile = $Path.$FileNameRoot."-2cols-plus2.csv";
#my $Edit = $ENV{'ED'};
my $Edit = "c:\\progra~2\\editpl~1\\editplus.exe";

open (my $CSV_FH, "<",$InputFile) or die "choke on open input $InputFile: $!";
open (OUT_FH, ">",$OutputFile) or die "choke on open output $OutputFile: $!";
print OUT_FH "DOI2,Region\n";
#$Title=$Type=$PubURI=$RefURI=$DOI=$PMID=$WordCount=$Abstract=$ExecSumm=$Blank1=$Keywords=$MeSHTerms=$Notes="";
my $csv = Text::CSV_XS->new ( { binary => 1 } )    #binary for mulitline fields
           or die "Cannot use Text::CSV " . Text::CSV->error_diag ();

$csv->column_names ($csv->getline($CSV_FH));    #define column names from first line
while (my $rowhash = $csv->getline_hr($CSV_FH)) { # Loop thru file
	$My_DOI = $rowhash->{'DOI'};
	$My_Glob = $rowhash->{'Title'} . " " . $rowhash->{'Abstract'} . " " . $rowhash->{'ExecSumm'} ;
	$My_Glob = unidecode($My_Glob);	#convert UTF chars
	$My_Glob =~ s/'/''/g;		#Escape single quotes
	$My_Glob =~ s/"/''/g;		#Double Quotes to (escaped) single quotes
	$My_Glob =~ s/\n/ /g;		#Delete newlines
	$My_Glob =~ s/\x00//g;		#Delete nulls
#	$My_Glob =~ s///g;		#Delete nulls
	$My_Glob =~ s/\x0a//g;		#Delete LF
	$My_Glob =~ s/\x0d//g;		#Delete CR
#	$OutCount++;
	$Region =DoRegions($My_Glob);
	print OUT_FH "\"$My_DOI\",\"$Region\"\n";
}	#End of file
close $CSV_FH;
close OUT_FH;
system "$Edit $InputFile $OutputFile";
