#!/usr/bin/env perl
# Reads CSV output of EXCEL spreadsheet, replaces newlines with spaces, formats into SQL statement

use strict;
use warnings;
use Text::CSV_XS;
my $InputFile = "c:\\db\\gsfc\\term_sample2.csv";
my $OutputFile = "c:\\db\\gsfc\\term_sample2.sql";
my $Edit = $ENV{'ED'};
my $RecNo=0;
my $ThisValue = "";
my $ThisColumn = "";

open (my $CSV_FH, "<",$InputFile) or die "choke on open input $InputFile: $!";
open (OUT_FH, ">",$OutputFile) or die "choke on open output $OutputFile: $!";

my $csv = Text::CSV_XS->new ( { binary => 1 } )    #binary for mulitline fields
           or die "Cannot use Text::CSV " . Text::CSV->error_diag ();

$csv->column_names ($csv->getline($CSV_FH));    #define column names from first line

while (my $rowhash = $csv->getline_hr($CSV_FH)) {
	my $InsertNames = "";
	my $InsertValues = "";
	$RecNo++;
	foreach my $field ($csv->column_names) {      #column names in order
		$ThisColumn = $field;
		$ThisValue = $rowhash->{$field};
		$ThisValue =~ s/\n/ /g;
		#Special Handling for Special Columns
		$ThisValue = "CDI.Context.ID" if ($ThisColumn eq "contextid"); #Fix Later (Famous Last Words)
		if ($ThisColumn eq "xtermid") {
			$ThisValue = $RecNo;
			$InsertNames .= "$ThisColumn,";
			$InsertValues .= "$ThisValue,"; #Numeric Value, no quotes
		} else {
			$InsertNames .= "$ThisColumn,";
			$InsertValues .= "\"$ThisValue\",";
		}
	}  #End of Row
	$InsertNames =~ s/,$//;  #delete final comma
	$InsertValues =~ s/,$//;  #delete final comma
	print OUT_FH<<EOM;
INSERT INTO TERM ( $InsertNames )
VALUES ( $InsertValues )
--
EOM
}
close $CSV_FH;
close OUT_FH;
system "$Edit $InputFile $OutputFile";
