#!perl -w
srand;
$Tab[0]=0;
$Tab[1]=0;
for ($x=0;$x<1000000 ;$x++) {
	$random = int (rand (2));
	$Tab[$random]++;
}
print "0= $Tab[0]; 1 = $Tab[1]\n";
print $Tab[0] -$Tab[1]."\n";
if ($Tab[0] < $Tab[1]) {
	print "Heads\n";
} elsif ($Tab[0] > $Tab[1]) {
	print "Tails\n";
} else {
	print "***EDGE***\n"
}

