#!perl -w
$|=1;
use POSIX qw(strftime);
use vcfw;
$Max=22;
$TotCtr1 = $TotCtr2 =0;
$Ctr=0;
$OldSS="";
for ($Loop = 0;$Loop <= $Max ;) {
	#print "$Loop\n";
	GenDTG();
	$Ctr++;
	if ($OldSS ne $SS) {
		$Loop++;
		print "($Loop:$Ctr) $DTG | $YYYY | $YY | $MM | $DD | - | $HH | $MN | $SS |\n";
		$TotCtr1 += $Ctr;
		$Ctr=0;
		$OldSS = $SS;
	}
}
print "=============\n";

$Ctr=0;
$OldSS="";
for ($Loop = 0;$Loop <= $Max ;) {
	#print "$Loop\n";
	Gen2();
	$Ctr++;
	if ($OldSS ne $SS) {
		$Loop++;
		print "($Loop:$Ctr) $DTG | $YYYY | $YY | $MM | $DD | - | $HH | $MN | $SS |\n";
		$TotCtr2 += $Ctr;
		$Ctr=0;
		$OldSS = $SS;
	}
}
$Avg1 = ($TotCtr1 / $Max);
$Avg2 = ($TotCtr2 / $Max);
print "Avg 1 = $Avg1\nAvg 2 = $Avg2\n";

sub Gen2 {
	$T=time;
	$DTG = strftime "%y%m%d_%H%M%S", localtime($T);
	$YYYY = strftime "%Y", localtime($T);
	$YY = strftime "%y", localtime($T);
	$MM = strftime "%m", localtime($T);
	$DD = strftime "%d", localtime($T);

	$HH = strftime "%H", localtime($T);
	$MN = strftime "%M", localtime($T);
	$SS = strftime "%S", localtime($T);
}