#!/usr/local/bin/perl
$|=1;
use vcfw;
$date_command = "c:\\cygwin\\bin\\date.exe";
$shortdate = `$date_command +"%D %T %Z"`; chop($shortdate);
print "[$shortdate]\n";
srand (time);
GenDTG();
$OldSS = $SS;
while ($OldSS == $SS) {
	GenDTG();
	$SecCt++;
#	print "$SecCt --\n";
	} # Wait for change of second
	print "$SecCt --\n";
GenDTG();
$OldSS = $SS;

while ($OldSS == $SS) {
	$t = time;
	$Loup++;
	print $Loup." ";
	GenDTG($t);
	print $DTG2;
	$t1 = $t - int($t);
	print " [$t:$t1]  \n";
#	print "$$\n";
	for ($i =1;$i < 5;$i++) {
		$random = (int (rand (8999))+1000);
#		print "Iteration: $i Rand# = $random\n";
	}
#sleep(1);
}
exit (0);
