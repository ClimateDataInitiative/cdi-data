#!c:\perl\bin\perl
$Path = $ENV{'PATH'};
$Path =~ s/;/\n/g;
print $Path;
