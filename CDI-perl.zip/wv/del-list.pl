use vcfw;
while (<DATA>) {
	chomp;
	$Kill= trim($_);
	$Cmd1= "del \"$Kill\"";
	print "[$Cmd1]\n";
	system $Cmd1;
}

__DATA__
c:\db\GSFC\DL\20160328_100916.jpg                                                                  
c:\db\GSFC\DL\drupal-7.42.tar.gz                                                                   
c:\db\GSFC\DL\Brochure.pdf                                                                         
c:\db\Vince-Sig.jpg                                                                                
c:\db\GSFC\DL\20160414_104211.jpg                                                                  
c:\db\Home\refsel-tuunz.txt                                                                        
c:\db\Home\refsel-tuunz.txt.bak                                                                    
c:\db\GSFC\DL\S043Cubes.jpg                                                                        
c:\db\GSFC\DL\gcisdata.zip                                                                         
c:\db\Home\perlstuff\fix3.pl                                                                       
c:\db\Home\perlstuff\fix4.pl                                                                       
c:\db\.dropbox.cache\2016-04-19\ChildhoodJoysRelived (deleted d44dd085bd3377f493d4ef0fb417f710).wmv
