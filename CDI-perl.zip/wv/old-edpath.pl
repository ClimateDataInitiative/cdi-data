$F1 = "C:\\belfry\\setpath.bat";
open (BAT,">$F1")|| die "choke on open $F1:$!\n";
$Path = $ENV{'PATH'};
print BAT "rem $Path\n";
$Path =~s/\;\;/\;/g;
$Path =~s/\;/\nset path=%PATH%;/g;
$Path = "set path=$Path";
print BAT $Path."\npath\n";
close BAT;
system "c:\\progra~1\\editpl~2\\editplus $F1";

