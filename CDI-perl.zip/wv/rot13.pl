#!perl -w
require "c:\\perl\\site\\lib\\vcfw.pm";
#$ARGV[0] = "xyzzy";
if (!$ARGV[0]) {
	die "A hollow voice says \"CYHTU\".\n";
}
for ($x=0;$x<=$#ARGV;$x++) {
  $Garble .= $ARGV[$x]." ";
}
$Clear = trim(rot13($Garble));
#$Clear = trim($Clear);
print "$Clear\n";
