#perl -w
for ($JHB=1;$JHB<=65 ;$JHB++) {
	print "Birthy Happday!\n";
}
