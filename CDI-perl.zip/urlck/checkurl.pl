#!c:/perl/bin/perl.exe -w
$|=1;
use LWP::UserAgent;
require vcfw;
GenDTG();
print "Starting $0  \@ $DTG2\nn";
chdir "c:\\db\\gsfc\\urlck";
$ErrFile = "errors.txt";	#Bad URLs
$GoodFile = "good.txt";	#Good URLs
$InFile = "allurls.txt";	#List of URLs, 1 per line
open (IN,"$InFile") || die "Choke on open $InFile:$!\n";
open (GOOD,">$GoodFile") || die "Choke on open $GoodFile:$!";
open (OOPS,">$ErrFile") || die "Choke on open $ErrFile:$!";
while (<IN>) {
  chomp;
  $Ct++;
  $URL = $_;
  GenDTG();
  print "$DTG2 ($Ct) Checking $URL ";
  $ua = new LWP::UserAgent;
  $ua->agent("Vince Wilding's Snarfilator (VCFW)");
  $req = new HTTP::Request 'HEAD' => "$URL";
  $req->header('Accept' => '*/*');
  # send request
  $res = $ua->request($req);
  # check the outcome
  if ($res->is_success) {
	print "Ok\n";
    print GOOD "$URL\n";
  } else {
	print "Bad!\n\n";
    $Stats = $res->status_line;
    chomp($Stats);
    GenDTG();
    print "$DTG2 Error: \"$Stats\" on URL: $URL\n";
    print OOPS "$URL | $Stats\n";
  }
}
GenDTG();
close IN;
close GOOD;
close OOPS;
system "edit $ErrFile $GoodFile";

