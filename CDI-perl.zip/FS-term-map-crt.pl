#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\FS-load-term-map-crt.sql";
$Relationship = "Throw this away";
$SqlStatement="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
#Term	Relationship	Datasets	extURI
     ($Term,$Relationship,$Datasets,$extURI) = split(/\t/);
	$DoWrite = 1;
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term eq "") {
		$ThisTerm = $OldTerm
	} else {
		$ThisTerm = $OldTerm = $Term;
	}
	$Datasets = trim($Datasets);
	$Datasets =~ s/'/''/g;		#Escape single quotes
	if ($Datasets eq "") {
		$DoWrite=0;
	}

	$extURI= trim($extURI);
	if ($extURI eq "") {
		$DoWrite=0;
	}


	if ($DoWrite) {
		$SqlStatement =<<EOM;
INSERT INTO term_map (term_id, relationship, gcid, description) VALUES ((SELECT s.id FROM term AS s WHERE s.term = '$ThisTerm' and s.lexicon_identifier = 'cdi'), 'hasCaseStudy', '$Datasets', '$extURI');
EOM
		print OUT "$SqlStatement";
	}
}
close OUT;
system "$ENV{'ED'} $F1"
#Subject	Predicate	Relationship	Object
#Term	Relationship	Datasets	extURI


#Term	Relationship	CaseStudy	extURI	Tools	extURI
__DATA__
Health	hasCaseStudy		http://toolkit.climate.gov/taking-action
Health	hasAnalysisTool		http://toolkit.climate.gov/tools?f[0]=field_parent_topic%3A116
Food Safety, Nutrition and Distribution	hasCaseStudy	Keeping Toxins From Harmful Algal Blooms out of the Food Supply	http://toolkit.climate.gov/taking-action/keeping-toxins-harmful-algal-blooms-out-food-supply
Food Safety, Nutrition and Distribution	hasCaseStudy	Alaskan Tribes Join Together to Assess Harmful Algal Blooms	http://toolkit.climate.gov/taking-action/alaskan-tribes-join-together-monitor-harmful-algal-blooms
Food Safety, Nutrition and Distribution	hasAnalysisTool	SERVIR	http://toolkit.climate.gov/tool/servir
Food Safety, Nutrition and Distribution	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Human Vulnerability	hasAnalysisTool	Food Access Research Atlas	http://toolkit.climate.gov/tool/food-access-research-atlas
Human Vulnerability	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Population at Risks	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Pregnant
Agricultural workers
Elderly	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Young Children	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Infants
Socioeconomic Risks	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Socioeconomic Risks	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Low income	hasAnalysisTool	Food Access Research Atlas	http://toolkit.climate.gov/tool/food-access-research-atlas
Low income	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Health Risks
Resulting Medical Conditions
Cognitive Development
Malnutrition
Body Composition
Obesity	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Allergic Sensitivity
Maturation
Hidden Hunger
Metabolism
Weakened Immune Systems
Concerns
Nutritional Quality	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Protein
Carb-Protein Ratio
Nutritional Value
Micronutrients
Trace elements
Macronutrients
Minerals
Food Security	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages
Food Security	hasAnalysisTool	Climate Adaptation Knowledge Exchange (CAKE)	http://toolkit.climate.gov/tool/climate-adaptation-knowledge-exchange-cake
Food Security	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Food Security	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Food Access	hasAnalysisTool	Food Access Research Atlas	http://toolkit.climate.gov/tool/food-access-research-atlas
Food Price	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Food Availability	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Pests
Crop Yields	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Decline Livestock
Weeds
Decline Fish
Food Safety
Biological variables
Pesticide Resistance
Age
Pest Range
Species
Size
Distribution
Infestation Rate
Host Susceptibility
Infrastructures
Transport Routes
Transport Barriers
Food Distribution	hasAnalysisTool	Food Access Research Atlas	http://toolkit.climate.gov/tool/food-access-research-atlas
Food Distribution	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Food Production	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Food Production	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Food Production	hasAnalysisTool	National Water Information System: Mapper	http://toolkit.climate.gov/tool/national-water-information-system-mapper
Food Production	hasAnalysisTool	U.S. Drought Portal	http://toolkit.climate.gov/tool/us-drought-portal
Power Outage
Delayed Shipping
Water Treatment
Water Irrigation
Food Storage
Storage Facilities
Super Markets	hasAnalysisTool	Food Access Research Atlas	http://toolkit.climate.gov/tool/food-access-research-atlas
Response	hasAnalysisTool	Arctic Adaptation Exchange	http://toolkit.climate.gov/tool/arctic-adaptation-exchange
Consumer Food Choices	hasAnalysisTool	Food Environment Atlas	http://toolkit.climate.gov/tool/food-environment-atlas
Agricultural practices
Disease Surveillance
Climate Indicators
CO2 Concentrations
Humidity
Sea Surface Temperature	hasCaseStudy	Keeping Toxins From Harmful Algal Blooms out of the Food Supply	http://toolkit.climate.gov/taking-action/keeping-toxins-harmful-algal-blooms-out-food-supply
Water Temperature
Weather Extremes
Precipitation	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Precipitation	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
Precipitation	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Precipitation	hasAnalysisTool	Local Climate Analysis Tool (LCAT)	http://toolkit.climate.gov/tool/local-climate-analysis-tool-lcat
Precipitation	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Stream Flow
Precipitation patterns
Snow Melt
Temperature	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Temperature	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
Temperature	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Temperature	hasAnalysisTool	Local Climate Analysis Tool (LCAT)	http://toolkit.climate.gov/tool/local-climate-analysis-tool-lcat
Temperature	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Extreme Weather	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Extreme Weather	hasAnalysisTool	Food Access Research Atlas	http://toolkit.climate.gov/tool/food-access-research-atlas
Extreme Weather	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Storm Surge
Drought	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Drought	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
Drought	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Drought	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Drought	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Drought	hasAnalysisTool	U.S. Drought Portal	http://toolkit.climate.gov/tool/us-drought-portal
Drought	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Heat Events	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Heat Events	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Flooding	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages
Flooding	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Flooding	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Flooding	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Exposure
Pathways
Deposition
Inhalation
Ingestion
Contaminants	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Biotoxins	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Phycotoxins
Mycotoxins
Ciguatoxin
Chemicals	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Pesticides	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Herbicides
Methylmercury
PCBs
Heavy Metals
Pathogen
Salmonella enterica
Vibrio parahaemolyticus
Toxoplasma gondii
Dionflagellate
Campylobacter
Norovirus
E. coli	hasAnalysisTool	Virtual Beach	http://toolkit.climate.gov/tool/virtual-beach
Vibrio vulnificus
Salmonella bongori
Listeria
Illness
Toxoplasmosis
Zoonosis
Ciguatera Fish Poisoning
Salmonella
Zoonotic Disease
Location
Sources
Drinking Water
Molds
Crops	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Crops	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Oysters
Food Processing
Dairy
Freshwater/marine algae
Sea Food	hasCaseStudy	Keeping Toxins From Harmful Algal Blooms out of the Food Supply	http://toolkit.climate.gov/taking-action/keeping-toxins-harmful-algal-blooms-out-food-supply
Sea Food	hasCaseStudy	Alaskan Tribes Join Together to Assess Harmful Algal Blooms	http://toolkit.climate.gov/taking-action/alaskan-tribes-join-together-monitor-harmful-algal-blooms
Vegetables
Cross contamination
Eggs
Eggs
Ground beef
Recreational Water
Tropical Reef Fish
Fecal Matter
Poultry
Meat
