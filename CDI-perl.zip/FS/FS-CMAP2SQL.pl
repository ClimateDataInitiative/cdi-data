#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\FS\\FS-load-cmap.sql";
$F2 = "C:\\db\\gsfc\\FS\\FS-load-rship.sql";
$Relationship = "Throw this away";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
open (OUT2,">",$F2) || die "choke on open out $F2: $!\n";
print OUT2 "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
	($Subject,$Predicate,$Relationship,$Object) = split(/\t/);
	$Subject = trim($Subject);		# trim trailing/leading spaces
	$Predicate = trim($Predicate);
	$Object= trim($Object);
	$Preds{$Predicate}++; #Count Predicates
	if ($Subject ne $Object) {
	print OUT<<EOM;
INSERT INTO term_relationship (term_subject, relationship_identifier, term_object) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = '$Subject' and s.lexicon_identifier = 'cdi'), '$Predicate', (SELECT o.identifier FROM term AS o WHERE o.term = '$Object' and o.lexicon_identifier = 'cdi' ));
EOM
	} else {
	print "*** $Subject $Predicate $Object ***\n"
}
}
foreach $key (sort keys(%Preds)){  # generate relationship statements
	$Count = $Preds{$key};
	$Tot1 += $Count;
	print OUT2 "INSERT INTO relationship (relationship) VALUES ('$key');\n";
    }
#print OUT2 " -- [$Tot1]\n";
close OUT;
close OUT2;
system "$ENV{'ED'} $F2 $F1"
#Subject	Predicate	Relationship	Object
__DATA__
Health	skos:narrower	is broader than	Food Safety, Nutrition and Distribution
Food Safety, Nutrition and Distribution	isInfluencedBy	isInfluencedBy	Human Vulnerability
Human Vulnerability	isDeterminedBy	isDeterminedBy	Populations at Risk
Populations at Risk	isResultOf	include	Pregnant
Populations at Risk	isResultOf	include	Agricultural workers
Populations at Risk	isResultOf	include	Elderly
Populations at Risk	isResultOf	include	Young Children
Populations at Risk	isResultOf	include	Infants
Human Vulnerability	isDeterminedBy	isDeterminedBy	Socioeconomic Risks
Socioeconomic Risks	isResultOf	include	Low income
Human Vulnerability	isDeterminedBy	isDeterminedBy	Health Risks
Health Risks	skos:narrower	consistOf	Resulting Medical Conditions
Resulting Medical Conditions	isResultOf	include	Cognitive Development
Resulting Medical Conditions	isResultOf	include	Malnutrition
Resulting Medical Conditions	isResultOf	include	Body Composition
Resulting Medical Conditions	isResultOf	include	Obesity
Resulting Medical Conditions	isResultOf	include	Allergic Sensitivity
Resulting Medical Conditions	isResultOf	include	Maturation
Resulting Medical Conditions	isResultOf	include	Hidden Hunger
Resulting Medical Conditions	isResultOf	include	Metabolism
Health Risks	skos:narrower	consistOf	Existing Medical Conditions
Existing Medical Conditions	isResultOf	include	Weakened Immune Systems
Food Safety, Nutrition and Distribution	isInfluencedBy	isInfluencedBy	Concerns
Concerns	isResultOf	includes	Nutritional Quality
Nutritional Quality	isResultOf	involves	Protein
Nutritional Quality	isResultOf	involves	Carb-Protein Ratio
Nutritional Quality	isResultOf	involves	Nutritional Value
Nutritional Quality	isResultOf	involves	Micronutrients
Nutritional Quality	isResultOf	involves	Trace elements
Nutritional Quality	isResultOf	involves	Macronutrients
Nutritional Quality	isResultOf	involves	Minerals
Concerns	isResultOf	includes	Food Security
Food Security	isResultOf	involves	Food Access
Food Access	isResultOf	isAffectedBy	Food Price
Food Security	isResultOf	involves	Food Use
Food Security	isResultOf	involves	Food Availability
Food Availability	isResultOf	isAffectedBy	Pests
Food Availability	isResultOf	isAffectedBy	Crop Yields
Food Availability	isResultOf	isAffectedBy	Decline Livestock
Food Availability	isResultOf	isAffectedBy	Weeds
Food Availability	isResultOf	isAffectedBy	Decline Fish
Concerns	isResultOf	includes	Food Safety
Food Safety, Nutrition and Distribution	isInfluencedBy	isInfluencedBy	Biological variables
Biological variables	skos:narrower	include	Pesticide Resistance
Biological variables	skos:narrower	include	Age
Biological variables	skos:narrower	include	Pest Range
Biological variables	skos:narrower	include	Species
Biological variables	skos:narrower	include	Size
Biological variables	skos:narrower	include	Distribution
Biological variables	skos:narrower	include	Infestation Rate
Biological variables	skos:narrower	include	Host Susceptibility
Food Safety, Nutrition and Distribution	isInfluencedBy	isInfluencedBy	Infrastructure
Infrastructure	skos:narrower	include	Transport Routes
Infrastructure	skos:narrower	include	Transport Barriers
Infrastructure	skos:narrower	include	Food Distribution
Infrastructure	skos:narrower	include	Food Production
Infrastructure	skos:narrower	include	Power Outage
Infrastructure	skos:narrower	include	Delayed Shipping
Infrastructure	skos:narrower	include	Water Treatment
Infrastructure	skos:narrower	include	Water Irrigation
Infrastructure	skos:narrower	include	Food Storage
Infrastructure	skos:narrower	include	Storage Facilities
Infrastructure	skos:narrower	include	Super Markets
Food Safety, Nutrition and Distribution	isInfluencedBy	isInfluencedBy	Response
Response	isDoneFor	include	Consumer Food Choices
Response	isDoneFor	include	Agricultural practices
Response	isDoneFor	include	Disease Surveillance
Food Safety, Nutrition and Distribution	isInfluencedBy	isInfluencedBy	Climate Indicators
Climate Indicators	skos:narrower	include	CO2 Concentrations
Climate Indicators	skos:narrower	include	Humidity
Climate Indicators	skos:narrower	include	Sea Surface Temperature
Climate Indicators	skos:narrower	include	Water Temperature
Climate Indicators	skos:narrower	include	Weather Extremes
Climate Indicators	skos:narrower	include	Precipitation
Climate Indicators	skos:narrower	include	Stream Flow
Climate Indicators	skos:narrower	include	Precipitation patterns
Climate Indicators	skos:narrower	include	Snow Melt
Climate Indicators	skos:narrower	include	Temperature
Food Safety, Nutrition and Distribution	isInfluencedBy	isInfluencedBy	Extreme Weather
Extreme Weather	skos:narrower	include	Storm Surge
Extreme Weather	skos:narrower	include	Drought
Extreme Weather	skos:narrower	include	Heat Events
Extreme Weather	skos:narrower	include	Flooding
Food Safety, Nutrition and Distribution	isInfluencedBy	isInfluencedBy	Exposure
Exposure	isDeterminedBy	isDeterminedBy	Pathway
Pathway	skos:narrower	include	Deposition
Pathway	skos:narrower	include	Inhalation
Pathway	skos:narrower	include	Ingestion
Exposure	isDeterminedBy	isDeterminedBy	Contaminants
Contaminants	skos:narrower	canBe	Biotoxins
Biotoxins	skos:narrower	include	Phycotoxins
Biotoxins	skos:narrower	include	Mycotoxins
Biotoxins	skos:narrower	include	Ciguatoxins
Contaminants	skos:narrower	canBe	Chemicals
Chemicals	skos:narrower	include	Pesticides
Chemicals	skos:narrower	include	Herbicides
Chemicals	skos:narrower	include	Methylmercury
Chemicals	skos:narrower	include	PCBs
Chemicals	skos:narrower	include	Heavy Metals
Contaminants	skos:narrower	canBe	Pathogens
Pathogens	skos:narrower	include	Salmonella enterica
Pathogens	skos:narrower	include	Vibrio parahaemolyticus
Pathogens	skos:narrower	include	Toxoplasma gondii
Pathogens	skos:narrower	include	Dionflagellate
Pathogens	skos:narrower	include	Campylobacter
Pathogens	skos:narrower	include	Noroviruses
Pathogens	skos:narrower	include	E. coli
Pathogens	skos:narrower	include	Vibrio vulnificus
Pathogens	skos:narrower	include	Salmonella bongori
Pathogens	skos:narrower	include	Listeria
Contaminants	skos:narrower	canBe	Illness
Illness	skos:narrower	include	Toxoplasmosis
Illness	skos:narrower	include	Zoonosis
Illness	skos:narrower	include	Ciguatera Fish Poisoning
Illness	skos:narrower	include	Salmonella
Illness	skos:narrower	include	Zoonotic Disease
Exposure	isDeterminedBy	isDeterminedBy	Location
Exposure	isDeterminedBy	isDeterminedBy	Sources
Sources	skos:narrower	include	Crops
Sources	skos:narrower	include	Drinking Water
Sources	skos:narrower	include	Mold
Sources	skos:narrower	include	Oysters
Sources	skos:narrower	include	Food Processing
Sources	skos:narrower	include	Dairy
Sources	skos:narrower	include	Freshwater/marine algae
Sources	skos:narrower	include	Sea Food
Sources	skos:narrower	include	Vegetables
Sources	skos:narrower	include	Cross contamination
Sources	skos:narrower	include	Eggs
Sources	skos:narrower	include	Ground beef
Sources	skos:narrower	include	Recreational Water
Sources	skos:narrower	include	Tropical Reef Fish
Sources	skos:narrower	include	Fecal Matter
Sources	skos:narrower	include	Poultry
Sources	skos:narrower	include	Meat
