#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
use Text::Unidecode;
$F1 = "C:\\db\\gsfc\\FS\\FS-load-term-map.sql";
$Sql1="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<DATA>) 	{
	$DoWrite = 1;
	chomp;
	($Term,$Relationship,$Dataset,$URI) = split(/\t/);
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term ne "") {
		if ($Dataset eq "") {
			$DoWrite = 0;
	}
	$Dataset = trim($Dataset);
	$Dataset =~ s/'/''/g;		#Escape single quotes
	$Dataset =~ s/"/''/g;		#Escape double quotes
	$Dataset =~ s/\x0a//g;  # 
	$Dataset =~ s/\x0d//g;  # 
	if ($URI eq "") {
		$DoWrite = 0;
	}
	$URI= trim($URI);
	$Dataset =~ s/'/''/g;		#Escape single quotes
	$Dataset =~ s/"/''/g;		#Escape double quotes
	$URI =~ s/\x0a//g;  # 
	$URI =~ s/\x0d//g;  # 
	$Relationship = trim($Relationship);
	if ($DoWrite) {
		$Sql1 = "INSERT INTO term_map (term_identifier, relationship_identifier, gcid, description) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = ";
		$OutLine=<<EOM;
$Sql1'$Term' and s.lexicon_identifier = 'cdi'), '$Relationship', '$URI', '$Dataset');
EOM
		print OUT "$OutLine";
		}
	}
}
close OUT;
system "$ENV{'ED'} $F1"
#Subject	Predicate	Relationship	Object
#Term	Relationship	Datasets	extURI		
#xtermid	contextid	Term	Relationship	Datasets	extURI




__DATA__
Health	isMentionedIn		https://catalog.data.gov/dataset?vocab_category_all=Human+Health&groups=climate5434#topic=humanhealth_navigation
Food Safety, Nutrition and Distribution	isMentionedIn		
Human Vulnerability	isMentionedIn	Food Environment Atlas	http://catalog.data.gov/dataset/food-environment-atlas-f4a22
Human Vulnerability	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Human Vulnerability	isMentionedIn	CDC WONDER: Cancer Statistics	http://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Human Vulnerability	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
Human Vulnerability	isMentionedIn	Designated Health Professional Shortage Areas	http://catalog.data.gov/dataset/designated-health-professional-shortage-areas
Human Vulnerability	isMentionedIn	Food Security in the United States	http://catalog.data.gov/dataset/food-security-in-the-united-states
Human Vulnerability	isMentionedIn	HCUPnet	http://catalog.data.gov/dataset/hcupnet
Human Vulnerability	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Human Vulnerability	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
Human Vulnerability	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
Human Vulnerability	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Populations at Risk	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	National Death Index	http://catalog.data.gov/dataset/national-death-index
Populations at Risk	isMentionedIn	VitalStats	http://catalog.data.gov/dataset/vitalstats
Populations at Risk	isMentionedIn	Food Environment Atlas	http://catalog.data.gov/dataset/food-environment-atlas-f4a22
Populations at Risk	isMentionedIn	International Food Security	http://catalog.data.gov/dataset/international-food-security
Populations at Risk	isMentionedIn	Pesticide Data Program 2008	http://catalog.data.gov/dataset/pesticide-data-program-2008
Populations at Risk	isMentionedIn	Supplemental Nutrition Assistance Program (SNAP) Data System	http://catalog.data.gov/dataset/supplemental-nutrition-assistance-program-snap-data-system-a2b49
Populations at Risk	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Populations at Risk	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
Pregnant	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
Pregnant	isMentionedIn	VitalStats	https://catalog.data.gov/dataset/vitalstats
Agricultural workers			
Elderly	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Elderly	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Elderly	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Elderly	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Elderly	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Elderly	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Young Children	isMentionedIn	Pesticide Data Program 2008	http://catalog.data.gov/dataset/pesticide-data-program-2008
Young Children	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Young Children	isMentionedIn	CDC WONDER: Cancer Statistics	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Young Children	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Young Children	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Young Children	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death#sec-dates
Young Children	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Young Children	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
Young Children	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Young Children	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Infants	isMentionedIn	Pesticide Data Program 2008	http://catalog.data.gov/dataset/pesticide-data-program-2008
Infants	isMentionedIn	VitalStats	https://catalog.data.gov/dataset/vitalstats
Infants	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Infants	isMentionedIn	CDC WONDER: Cancer Statistics	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Infants	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Infants	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Infants	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death#sec-dates
Infants	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Infants	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
Socioeconomic Risks	isMentionedIn	Food Environment Atlas	https://catalog.data.gov/dataset/food-environment-atlas-f4a22
Socioeconomic Risks	isMentionedIn	Food Access Research Atlas	http://catalog.data.gov/dataset/food-access-research-atlas
Socioeconomic Risks	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Socioeconomic Risks	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
Socioeconomic Risks	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Low income	isMentionedIn	Designated Health Professional Shortage Areas	http://catalog.data.gov/dataset/designated-health-professional-shortage-areas
Low income	isMentionedIn	Food Access Research Atlas	https://catalog.data.gov/dataset/food-access-research-atlas
Low income	isMentionedIn	Food Environment Atlas	https://catalog.data.gov/dataset/food-environment-atlas-f4a22
Low income	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Low income	isMentionedIn	Supplemental Nutrition Assistance Program (SNAP) Data System	http://catalog.data.gov/dataset/supplemental-nutrition-assistance-program-snap-data-system-a2b49
Health Risks	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Health Risks	isMentionedIn	FluView National Flu Activity Map	https://catalog.data.gov/dataset/fluview-national-flu-activity-map
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Cancer Statistics	http://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Cognitive Development			
Malnutrition	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Malnutrition	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Malnutrition	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Malnutrition	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Malnutrition	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Body Composition			
Obesity	isMentionedIn	Food Environment Atlas	https://catalog.data.gov/dataset/food-environment-atlas-f4a22
Obesity	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Obesity	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Obesity	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Obesity	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Obesity	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Obesity	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
Allergic Sensitivity			
Maturation			
Hidden Hunger			
Metabolism			
Existing Medical Conditions			
Weakened Immune Systems			
Concerns			
Nutritional Quality	isMentionedIn	Food Availability (Per Capita) Data System	http://catalog.data.gov/dataset/food-availability-per-capita-data-system
Nutritional Quality	isMentionedIn	MyPyramid Food Raw Data	http://catalog.data.gov/dataset/mypyramid-food-raw-data-f9ed6
Protein			
Carb-Protein Ratio			
Nutritional Value	isMentionedIn	Food Availability (Per Capita) Data System	http://catalog.data.gov/dataset/food-availability-per-capita-data-system
Nutritional Value	isMentionedIn	MyPyramid Food Raw Data	http://catalog.data.gov/dataset/mypyramid-food-raw-data-f9ed6
Micronutrients			
Trace elements			
Macronutrients			
Minerals			
Food Security	isMentionedIn	Agriculture Census of the United States - 2007 - Direct Download	https://catalog.data.gov/dataset/agriculture-census-of-the-united-states-2007-direct-download
Food Security	isMentionedIn	Concentrated Animal Feeding Operations (CAFOs) per County Downloadable Package, US, 2013, US EPA	https://catalog.data.gov/dataset/concentrated-animal-feeding-operations-cafos-per-county-downloadable-package-us-2013-us-epa
Food Security	isMentionedIn	CropScape - Cropland Data Layer	https://catalog.data.gov/dataset/cropscape-cropland-data-layer
Food Security	isMentionedIn	Feed Grains Database	https://catalog.data.gov/dataset/feed-grains-database
Food Security	isMentionedIn	Food Access Research Atlas	https://catalog.data.gov/dataset/food-access-research-atlas
Food Security	isMentionedIn	Food Availability (Per Capita) Data System	https://catalog.data.gov/dataset/food-availability-per-capita-data-system
Food Security	isMentionedIn	Food Environment Atlas	https://catalog.data.gov/dataset/food-environment-atlas-f4a22
Food Security	isMentionedIn	Food Safety Information RSS feed	https://catalog.data.gov/dataset/food-safety-information-rss-feed
Food Security	isMentionedIn	Food Security in the United States	https://catalog.data.gov/dataset/food-security-in-the-united-states
Food Security	isMentionedIn	International Food Security	https://catalog.data.gov/dataset/international-food-security
Food Security	isMentionedIn	Livestock And Meat Domestic Data	http://catalog.data.gov/dataset/livestock-and-meat-domestic-data
Food Security	isMentionedIn	National Animal Health Monitoring System	http://catalog.data.gov/dataset/national-animal-health-monitoring-system
Food Security	isMentionedIn	Quick Stats Agricultural Database API	http://catalog.data.gov/dataset/quick-stats-agricultural-database-api
Food Access	isMentionedIn	Food Access Research Atlas	https://catalog.data.gov/dataset/food-access-research-atlas
Food Price	isMentionedIn	Food Price Outlook	https://catalog.data.gov/dataset/food-price-outlook
Food Price	isMentionedIn	Food Environment Atlas	https://catalog.data.gov/dataset/food-environment-atlas-f4a22
Food Price	isMentionedIn	Feed Grains Database	https://catalog.data.gov/dataset/feed-grains-database
Food Price	isMentionedIn	Livestock And Meat Domestic Data	https://catalog.data.gov/dataset/livestock-and-meat-domestic-data
Food Price	isMentionedIn	Food Expenditures	https://catalog.data.gov/dataset/food-expenditures
Food Use	isMentionedIn	Food Availability (Per Capita) Data System	http://catalog.data.gov/dataset/food-availability-per-capita-data-system
Food Use	isMentionedIn	International Food Security	http://catalog.data.gov/dataset/international-food-security
Food Use	isMentionedIn	MyPyramid Food Raw Data	http://catalog.data.gov/dataset/mypyramid-food-raw-data-f9ed6
Food Availability	isMentionedIn	Food Availability (Per Capita) Data System	https://catalog.data.gov/dataset/food-availability-per-capita-data-system
Food Availability	isMentionedIn	International Food Security	http://catalog.data.gov/dataset/international-food-security
Food Availability	isMentionedIn	Livestock And Meat Domestic Data	http://catalog.data.gov/dataset/livestock-and-meat-domestic-data
Pests			
Crop Yields	isMentionedIn	Agricultural Baseline Database	http://catalog.data.gov/dataset/agricultural-baseline-database
Crop Yields	isMentionedIn	Agriculture Census of the United States - 2007 - Direct Download	http://catalog.data.gov/dataset/agriculture-census-of-the-united-states-2007-direct-download
Crop Yields	isMentionedIn	Feed Grains Database	http://catalog.data.gov/dataset/feed-grains-database
Crop Yields	isMentionedIn	International Food Security	http://catalog.data.gov/dataset/international-food-security
Crop Yields	isMentionedIn	Quick Stats Agricultural Database API	http://catalog.data.gov/dataset/quick-stats-agricultural-database-api
Decline Livestock	isMentionedIn	National Animal Health Monitoring System	http://catalog.data.gov/dataset/national-animal-health-monitoring-system
Weeds			
Decline Fish			
Food Safety	isMentionedIn	Adoption of Genetically Engineered Crops in the U.S.	http://catalog.data.gov/dataset/adoption-of-genetically-engineered-crops-in-the-us
Food Safety	isMentionedIn	Food Safety Information RSS feed	http://catalog.data.gov/dataset/food-safety-information-rss-feed
Food Safety	isMentionedIn	Pesticide Data Program 2008	http://catalog.data.gov/dataset/pesticide-data-program-2008
Biological variables			
Pesticide Resistance			
Age			
Pest Range			
Species			
Size			
Distribution			
Infestation Rate			
Host Susceptibility			
Infrastructure	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Infrastructure	isMentionedIn	USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	http://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass
Transport Routes			
Transport Barriers			
Food Distribution	isMentionedIn	Food Environment Atlas	http://catalog.data.gov/dataset/food-environment-atlas-f4a22
Food Distribution	isMentionedIn	Livestock And Meat Domestic Data	http://catalog.data.gov/dataset/livestock-and-meat-domestic-data
Food Production	isMentionedIn	International Food Security	http://catalog.data.gov/dataset/international-food-security
Food Production	isMentionedIn	National Animal Health Monitoring System	http://catalog.data.gov/dataset/national-animal-health-monitoring-system
Food Production	isMentionedIn	Livestock And Meat Domestic Data	http://catalog.data.gov/dataset/livestock-and-meat-domestic-data
Food Production	isMentionedIn	Agricultural Baseline Database	https://catalog.data.gov/dataset/agricultural-baseline-database
Power Outage			
Delayed Shipping			
Water Treatment	isMentionedIn	Drinking Water Treatability Database (TDB)	http://catalog.data.gov/dataset/drinking-water-treatability-database-tdb
Water Irrigation			
Food Storage			
Storage Facilities			
Super Markets	isMentionedIn	Food Environment Atlas	http://catalog.data.gov/dataset/food-environment-atlas-f4a22
Response	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
Consumer Food Choices	isMentionedIn	Food Availability (Per Capita) Data System	http://catalog.data.gov/dataset/food-availability-per-capita-data-system
Agricultural practices	isMentionedIn	Adoption of Genetically Engineered Crops in the U.S.	http://catalog.data.gov/dataset/adoption-of-genetically-engineered-crops-in-the-us
Agricultural practices	isMentionedIn	Quick Stats Agricultural Database API	http://catalog.data.gov/dataset/quick-stats-agricultural-database-api
Agricultural practices	isMentionedIn	Agriculture Census of the United States - 2007 - Direct Download	http://catalog.data.gov/dataset/agriculture-census-of-the-united-states-2007-direct-download
Disease Surveillance	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
Disease Surveillance	isMentionedIn	National Animal Health Monitoring System	http://catalog.data.gov/dataset/national-animal-health-monitoring-system
Climate Indicators	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
Climate Indicators	isMentionedIn	Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis
Climate Indicators	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
Climate Indicators	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Climate Indicators	isMentionedIn	Global Climate Station Summaries	https://catalog.data.gov/dataset/global-climate-station-summaries
Climate Indicators	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Climate Indicators	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
Climate Indicators	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Climate Indicators	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Climate Indicators	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Climate Indicators	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
Climate Indicators	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Climate Indicators	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Climate Indicators	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Climate Indicators	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Climate Indicators	isMentionedIn	U.S. Hourly Precipitation Data	https://catalog.data.gov/dataset/u-s-hourly-precipitation-data
Climate Indicators	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Climate Indicators	isMentionedIn	United States Average Annual Precipitation, 1990-2009 - Direct Download	https://catalog.data.gov/dataset/united-states-average-annual-precipitation-1990-2009-direct-download
CO2 Concentrations	isMentionedIn	Tropospheric Emission Spectrometer (TES) Data	https://catalog.data.gov/dataset/tropospheric-emission-spectrometer-tes-data
CO2 Concentrations	isMentionedIn	Air Markets Program Data (AMPD)	https://catalog.data.gov/dataset/air-markets-program-data-ampd
CO2 Concentrations	isMentionedIn	ISLSCP II EDGAR 3 Gridded Greenhouse and Ozone Precursor Gas Emissions	https://catalog.data.gov/dataset/islscp-ii-edgar-3-gridded-greenhouse-and-ozone-precursor-gas-emissions
Humidity	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Humidity	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Humidity	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
Humidity	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Humidity	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Humidity	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Humidity	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Humidity	isMentionedIn	Fire Weather Outlooks	https://catalog.data.gov/dataset/fire-weather-outlooks
Sea Surface Temperature	isMentionedIn	Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis
Sea Surface Temperature	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
Sea Surface Temperature	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	https://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Water Temperature	isMentionedIn	USGS Water-Quality Data for the Nation - National Water Information System (NWIS)	https://catalog.data.gov/dataset/usgs-water-quality-data-for-the-nation-national-water-information-system-nwis
Weather Extremes	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
Weather Extremes	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Weather Extremes	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	https://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Weather Extremes	isMentionedIn	U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries
Weather Extremes	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	https://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Weather Extremes	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	https://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Weather Extremes	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Weather Extremes	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
Weather Extremes	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Weather Extremes	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Weather Extremes	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Weather Extremes	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Weather Extremes	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Precipitation	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
Precipitation	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Precipitation	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
Precipitation	isMentionedIn	Global Climate Station Summaries	https://catalog.data.gov/dataset/global-climate-station-summaries
Precipitation	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Precipitation	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Precipitation	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	https://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Precipitation	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Precipitation	isMentionedIn	National Integrated Drought Information System	http://catalog.data.gov/dataset/national-integrated-drought-information-system
Precipitation	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Precipitation	isMentionedIn	NOAA Climate Data Record (CDR) of Precipitation Estimation from Remotely Sensed Information using Artificial Neural Networks (PERSIANN-CDR)- Version 1 Revision 1	http://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-precipitation-estimation-from-remotely-sensed-information-using
Precipitation	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
Precipitation	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Precipitation	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
Precipitation	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Precipitation	isMentionedIn	Severe Weather Data Inventory	https://catalog.data.gov/dataset/severe-weather-data-inventory
Precipitation	isMentionedIn	U.S. 15 Minute Precipitation Data	http://catalog.data.gov/dataset/u-s-15-minute-precipitation-data
Precipitation	isMentionedIn	U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries
Precipitation	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Precipitation	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Precipitation	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Precipitation	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Precipitation	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Precipitation	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Precipitation	isMentionedIn	U.S. Hourly Precipitation Data	https://catalog.data.gov/dataset/u-s-hourly-precipitation-data
Precipitation	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Precipitation	isMentionedIn	United States Average Annual Precipitation- 1990-2009 - Direct Download	http://catalog.data.gov/dataset/united-states-average-annual-precipitation-1990-2009-direct-download
Precipitation	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Stream Flow	isMentionedIn	USGS Water-Quality Data for the Nation - National Water Information System (NWIS)	http://catalog.data.gov/dataset/usgs-water-quality-data-for-the-nation-national-water-information-system-nwis
Stream Flow	isMentionedIn	WaterWatch -- Current Water Resources Conditions	http://catalog.data.gov/dataset/waterwatch-current-water-resources-conditions
Precipitation patterns			
Snow Melt	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Snow Melt	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Snow Melt	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Snow Melt	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
Snow Melt	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Temperature	isMentionedIn	CDC WONDER: Daily Air Temperatures and Heat Index	https://catalog.data.gov/dataset/cdc-wonder-daily-air-temperatures-and-heat-index
Temperature	isMentionedIn	CDC WONDER: Daily Fine Particulate Matter	https://catalog.data.gov/dataset/cdc-wonder-daily-fine-particulate-matter
Temperature	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
Temperature	isMentionedIn	Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis
Temperature	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
Temperature	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Temperature	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
Temperature	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Temperature	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Temperature	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
Temperature	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Temperature	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	https://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Temperature	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Temperature	isMentionedIn	National Integrated Drought Information System	http://catalog.data.gov/dataset/national-integrated-drought-information-system
Temperature	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Temperature	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
Temperature	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
Temperature	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Temperature	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
Temperature	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Temperature	isMentionedIn	U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries
Temperature	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Temperature	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Temperature	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Temperature	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Temperature	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Temperature	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Temperature	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Temperature	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Extreme Weather	isMentionedIn	Geographical Information System Graphical Database of Tornados 1950-2006	http://catalog.data.gov/dataset/geographical-information-system-graphical-database-of-tornados-1950-2006
Extreme Weather	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Extreme Weather	isMentionedIn	NOAA Emergency Response Imagery	http://catalog.data.gov/dataset/noaa-emergency-response-imagery
Extreme Weather	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Extreme Weather	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
Extreme Weather	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Extreme Weather	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	https://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Extreme Weather	isMentionedIn	Severe Weather Data Inventory	https://catalog.data.gov/dataset/severe-weather-data-inventory
Extreme Weather	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries	https://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
Extreme Weather	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Extreme Weather	isMentionedIn	National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system
Extreme Weather	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Extreme Weather	isMentionedIn	Fire Weather Outlooks 	http://catalog.data.gov/dataset/fire-weather-outlooks
Storm Surge	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Drought	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Drought	isMentionedIn	National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system
Drought	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Drought	isMentionedIn	WaterWatch -- Current Water Resources Conditions	http://catalog.data.gov/dataset/waterwatch-current-water-resources-conditions
Heat Events	isMentionedIn		
Flooding	isMentionedIn	Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper
Flooding	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Flooding	isMentionedIn	National Flood Hazard Layer (NFHL)	http://catalog.data.gov/dataset/national-flood-hazard-layer-nfhl
Flooding	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Flooding	isMentionedIn	NOAA Digital Coast Sea Level Rise and Coastal Flooding Impacts Viewer	http://catalog.data.gov/dataset/noaa-digital-coast-sea-level-rise-and-coastal-flooding-impacts-viewer
Flooding	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries 	http://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
Flooding	isMentionedIn	WaterWatch -- Current Water Resources Conditions	http://catalog.data.gov/dataset/waterwatch-current-water-resources-conditions
Exposure	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Exposure	isMentionedIn	FluView National Flu Activity Map	https://catalog.data.gov/dataset/fluview-national-flu-activity-map
Pathway			
Deposition			
Inhalation			
Ingestion			
Contaminants	isMentionedIn	Investigation of bacterial pathogens associated with concentrated animal feeding operations (CAFOs) and their potential impacts on a National Wildlife Refuge in Oklahoma: Final report	https://catalog.data.gov/dataset/investigation-of-bacterial-pathogens-associated-with-concentrated-animal-feeding-operation
Contaminants	isMentionedIn	Safe Drinking Water Information System (SDWIS)	http://catalog.data.gov/dataset/safe-drinking-water-information-system-sdwis
Contaminants	isMentionedIn	Drinking Water Maximum Contaminant Levels (MCLs)	https://catalog.data.gov/dataset/drinking-water-maximum-contaminant-levels-mcls
Biotoxins			
Phycotoxins			
Mycotoxins			
Ciguatoxins			
Chemicals			
Pesticides	isMentionedIn	Pesticide Data Program 2008	http://catalog.data.gov/dataset/pesticide-data-program-2008
Pesticides	isMentionedIn	Drainage Basins Used for Assessing Trends in Concentration of Pesticides in Streams of the United States, 1992-2010	https://catalog.data.gov/dataset/drainage-basins-used-for-assessing-trends-in-concentration-of-pesticides-in-streams-o-1992-2010
Pesticides	isMentionedIn	National Status and Trends: Mussel Watch Program	https://catalog.data.gov/dataset/national-status-and-trends-mussel-watch-program
Pesticides	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Herbicides	isMentionedIn	Adoption of Genetically Engineered Crops in the U.S.	http://catalog.data.gov/dataset/adoption-of-genetically-engineered-crops-in-the-us
Methylmercury			
PCBs			
Heavy Metals	isMentionedIn	Arsenic in Ground Water of the United States - Direct Download	http://catalog.data.gov/dataset/arsenic-in-ground-water-of-the-united-states-direct-download
Pathogens	isMentionedIn	Safe Drinking Water Information System (SDWIS)	https://catalog.data.gov/dataset/safe-drinking-water-information-system-sdwis
Pathogens	isMentionedIn	Cost Estimates of Foodborne Illnesses	https://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
Pathogens	isMentionedIn	Investigation of bacterial pathogens associated with concentrated animal feeding operations (CAFOs) and their potential impacts on a National Wildlife Refuge in Oklahoma: Final report	https://catalog.data.gov/dataset/investigation-of-bacterial-pathogens-associated-with-concentrated-animal-feeding-operation
Salmonella enterica	isMentionedIn	Cost Estimates of Foodborne Illnesses	https://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
Salmonella enterica	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Vibrio parahaemolyticus	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
Vibrio parahaemolyticus	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	
Toxoplasma gondii	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
Dionflagellate			
Campylobacter	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
Noroviruses	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
Noroviruses	isMentionedIn	FluView National Flu Activity Map	https://catalog.data.gov/dataset/fluview-national-flu-activity-map
E. coli	isMentionedIn	Investigation of bacterial pathogens associated with concentrated animal feeding operations (CAFOs) and their potential impacts on a National Wildlife Refuge in Oklahoma: Final report	https://catalog.data.gov/dataset/investigation-of-bacterial-pathogens-associated-with-concentrated-animal-feeding-operation
E. coli	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
E. coli	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Vibrio vulnificus	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
Salmonella bongori			
Listeria	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Listeria	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
Illness	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
Illness	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Toxoplasmosis			
Zoonosis			
Ciguatera Fish Poisoning			
Salmonella	isMentionedIn	Cost Estimates of Foodborne Illnesses	http://catalog.data.gov/dataset/cost-estimates-of-foodborne-illnesses
Salmonella	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Zoonotic Disease			
Location			
Sources			
Drinking Water	isMentionedIn	Arsenic in Ground Water of the United States - Direct Download	http://catalog.data.gov/dataset/arsenic-in-ground-water-of-the-united-states-direct-download
Drinking Water	isMentionedIn	Drinking Water Maximum Contaminant Levels (MCLs)	http://catalog.data.gov/dataset/drinking-water-maximum-contaminant-levels-mcls
Drinking Water	isMentionedIn	Drinking Water Treatability Database (TDB)	http://catalog.data.gov/dataset/drinking-water-treatability-database-tdb
Drinking Water	isMentionedIn	EnviroAtlas - Clean and Plentiful Water Metrics for the Conterminous United States	http://catalog.data.gov/dataset/enviroatlas-clean-and-plentiful-water-metrics-for-the-conterminous-united-states
Drinking Water	isMentionedIn	Safe Drinking Water Information System (SDWIS)	http://catalog.data.gov/dataset/safe-drinking-water-information-system-sdwis
Mold			
Crops	isMentionedIn	Quick Stats Agricultural Database API	https://catalog.data.gov/dataset/quick-stats-agricultural-database-api
Oysters			
Food Processing			
Dairy	isMentionedIn	Agricultural Baseline Database	http://catalog.data.gov/dataset/agricultural-baseline-database
Dairy	isMentionedIn	National Animal Health Monitoring System	http://catalog.data.gov/dataset/national-animal-health-monitoring-system
Dairy	isMentionedIn	Food Availability (Per Capita) Data System	https://catalog.data.gov/dataset/food-availability-per-capita-data-system
Dairy	isMentionedIn	Quick Stats Agricultural Database API	https://catalog.data.gov/dataset/quick-stats-agricultural-database-api
Freshwater/marine algae	isMentionedIn		
Sea Food			
Vegetables	isMentionedIn	Food Availability (Per Capita) Data System	https://catalog.data.gov/dataset/food-availability-per-capita-data-system
Cross contamination			
Eggs	isMentionedIn	Agricultural Baseline Database	http://catalog.data.gov/dataset/agricultural-baseline-database
Eggs	isMentionedIn	Food Availability (Per Capita) Data System	https://catalog.data.gov/dataset/food-availability-per-capita-data-system
Ground beef	isMentionedIn	Agricultural Baseline Database	http://catalog.data.gov/dataset/agricultural-baseline-database
Ground beef	isMentionedIn	Livestock And Meat Domestic Data	http://catalog.data.gov/dataset/livestock-and-meat-domestic-data
Recreational Water	isMentionedIn	Investigation of bacterial pathogens associated with concentrated animal feeding operations (CAFOs) and their potential impacts on a National Wildlife Refuge in Oklahoma: Final report	https://catalog.data.gov/dataset/investigation-of-bacterial-pathogens-associated-with-concentrated-animal-feeding-operation
Tropical Reef Fish			
Fecal Matter			
Poultry	isMentionedIn	Livestock And Meat Domestic Data	http://catalog.data.gov/dataset/livestock-and-meat-domestic-data
Poultry	isMentionedIn	National Animal Health Monitoring System	http://catalog.data.gov/dataset/national-animal-health-monitoring-system
Poultry	isMentionedIn	Food Availability (Per Capita) Data System	https://catalog.data.gov/dataset/food-availability-per-capita-data-system
Poultry	isMentionedIn	Quick Stats Agricultural Database API	https://catalog.data.gov/dataset/quick-stats-agricultural-database-api
Meat	isMentionedIn	Agricultural Baseline Database	http://catalog.data.gov/dataset/agricultural-baseline-database
Meat	isMentionedIn	Livestock And Meat Domestic Data	http://catalog.data.gov/dataset/livestock-and-meat-domestic-data
Meat	isMentionedIn	Food Availability (Per Capita) Data System	https://catalog.data.gov/dataset/food-availability-per-capita-data-system
