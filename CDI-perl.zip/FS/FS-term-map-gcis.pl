#!perl -w
#Input from __DATA__ below, GCIS tab of spreadsheet, tab seperated Term	Relationship	Datasets	extURI
use vcfw;
use Text::Unidecode;
$F1 = "C:\\db\\gsfc\\FS\\FS-load-term-map-gcis.sql";
$FileIn = "C:\\db\\GSFC\\FS\\FS-term-map-gcis.txt";

$SqlStatement="";
open (IN,"<",$FileIn) || die "choke on open input $FileIn: $!\n";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<IN>) 	{
	chomp;
	$DoWrite = 1;
	#Term	Relationship	Datasets	extURI
	($Term,$Relationship,$Dataset,$URI) = split(/\t/);
	$Term = trim($Term);		# trim trailing/leading spaces
	$Term = unidecode($Term);
	if ($Term ne "") {
		$Relationship = trim($Relationship);
		if ($Relationship eq "") {
			$DoWrite = 0;
		}
		$Dataset = trim($Dataset);
		if ($Dataset eq "") {
			$DoWrite = 0;
		}
		$Dataset = unidecode($Dataset);
		$Dataset =~ s/'/''/g;		#Escape single quotes
		$URI= trim($URI);
		if ($URI eq "") {
			$DoWrite = 0;
		}
		if ($DoWrite) {
			$SqlStatement =<<EOM;
INSERT INTO term_map (term_identifier, relationship_identifier, gcid, description) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = '$Term' and s.lexicon_identifier='cdi'), '$Relationship', '$URI', '$Dataset');
EOM
			print OUT "$SqlStatement";
		}
	}
}
close OUT;
system "$ENV{'ED'} $F1"

#Term	Relationship	Datasets	extURI
# __DATA__
