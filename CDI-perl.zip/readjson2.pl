#!perl.exe -w
use vcfw;
use JSON;
use Data::Dumper;
GenDTG();
$F1 = "c:\\db\\gsfc\\json.txt";
$F1 = 'c:\temp\snarf_151020_134350.json';
$F1 = $ARGV[0];
$OrgUrl = $ARGV[1];
$KeysFile= "c:\\db\\gsfc\\allkeys.txt";
open (IN,"<",$F1) || die "Choke on open $F1:$!\n";
$json_text=(<IN>);
#print "[$json_text]\n";
$json = JSON->new->allow_nonref;

$perl_scalar = $json->decode( $json_text );
 
#print "Bingo \n";

for my $key (keys %{$perl_scalar}) {
	if ($key eq "keyword") { #
#	print "Found it!\n";
		@MyKeys = ${$perl_scalar}{'keyword'};
		foreach $n (@MyKeys) {
			$Hit = Dumper($n);
		}
		#print "Hit= >>>$Hit<<<\n";
		@MyArray= split("\n",$Hit);
		foreach (@MyArray) {
			chomp;
			$Hit1 = trim($_);
			#$HitCt++;
			#print "$HitCt:>>>>>>>>$Hit1<\n";
			if (($Hit1 ne "\$VAR1 = [" ) && ($Hit1 ne "];")) {
				$KeyStr .= $Hit1;
			}
		}
		open (KEYS,">>",$KeysFile) || die "choke on open KEYS file $!\n";
		print KEYS "$DTG2\n$KeyStr\n$OrgUrl\n\n";
		close KEYS;
		print "$DTG2\n$KeyStr\n$OrgUrl\n\n";
		
	}
}
#print " Bongo\n";
