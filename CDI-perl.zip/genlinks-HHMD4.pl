#!perl -w
use vcfw;
$F1 ="c:\\db\\GSFC\\randall-climate-data-gov-resources.txt";
$F2 ="c:\\db\\GSFC\\randall-climate-data-gov-resources.htm";
open (IN,"<$F1") || die "choke on open $F1:$!\n";
open (OUT,">$F2") || die "choke on open $F1:$!\n";
#open (BAT,">C:\\db\\gsfc\\snarfall2.bat") || die "choke on open snarfall2.bat :$!\n";
print OUT "<a name=\"TOP\"></a><table border=1>\n";
$OldGroupHeader = "*";
$TotGroups = 0;
while (<IN>) {
	chomp;
	$DataIn = $_;
	($Group_Title,$Group_URL,$Resource_Name,$Format,$Mimetype,$data_gov_URL,$Direct_URL) = split (/\t/,$DataIn);
	$Group_Title = trim($Group_Title);
	$Group_URL = trim($Group_URL);
	$Resource_Name = trim($Resource_Name);
	$Format = trim($Format);
	if ($Format eq "") { $Format = "N/A" }
	$Mimetype = trim($Mimetype);
	if ($Mimetype eq "") { $Mimetype= "N/A" }
	$data_gov_URL = trim($data_gov_URL);
	$Direct_URL = trim($Direct_URL);
	$GroupHeader ="<tr><td colspan=5>";
	if ($TotGroups > 0) {
		$GroupHeader .= "(<a href=\"#TOP\">Top</a>)<br>";
	}			
	$GroupHeader .= "<h2><a href=\"$Group_URL\">$Group_Title</a></h2></td></tr><tr><td><b>Resource</b></td><td><b>Format</td><td><b>MIME Type</td><td><b>DATA.gov</td><td><b>Direct</td></tr>";
	if ($OldGroupHeader ne $GroupHeader) {
		if ($OldGroupHeader ne "*") {
			$TotGroups++;
			$TotPage .= $OldGroupHeader . $GroupLinks;
			}
			$OldGroupHeader = $GroupHeader;
			$GroupLinks="";
	}

	
	$GroupLinks .="<tr><td>$Resource_Name</td><td>$Format</td><td>$Mimetype</td><td><a href=\"$data_gov_URL\"><center><img src=\"/files/link.gif\"></a></td><td><a href=\"$Direct_URL\"><center><img src=\"/files/link.gif\"></a></td><tr>\n";
}
close IN;
print OUT "$TotPage\n</table>\n";
close OUT;
system "c:\\progra~2\\editpl~1\\editplus.exe $F1 $F2";
