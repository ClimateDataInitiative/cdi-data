#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
use Text::Unidecode;
$InFile = "C:\\db\\GSFC\\DL\\WI-Term-map-GCIS.tsv";
$F1 = "C:\\db\\gsfc\\WI-load-term-map-gcis.sql";
$SqlStatement="";
open (IN,"<",$InFile) || die "choke on open out $F1: $!\n";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<IN>) {
	chomp;
	$DoWrite = 1;
	#Term	Relationship	Datasets	extURI
	($Term,$Relationship,$Dataset,$URI) = split(/\t/);
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term eq "") {
		$ThisTerm = $OldTerm
	} else {
		$ThisTerm = $OldTerm = $Term;
	}
	$Relationship = trim($Relationship);
	if ($Relationship eq "") {
		$Relationship= "N/A";
		$DoWrite = 0;
	}
	$Dataset = trim($Dataset);
	if ($Dataset eq "") {
		$Dataset= "N/A";
		$DoWrite = 0;
	}
	$Dataset = unidecode($Dataset);
	$Dataset =~ s/'/''/g;		#Escape single quotes
	$Dataset =~ s/\x92/''/g;  #Fix UTF8 quote
	$Dataset =~ s/\x97/\-/g;  #Fix UTF8 dash
	$Dataset =~ s/\x96/\-/g;  #Fix UTF8 hyphen

	$URI= trim($URI);
	if ($URI eq "") {
		$URI= "N/A";
		$DoWrite = 0;
	}
	$SqlStatement =<<EOM;
INSERT INTO term_map (term_id, relationship, gcid, description) VALUES ((SELECT s.id FROM term AS s WHERE s.term = '$ThisTerm' and s.lexicon_identifier='cdi'), '$Relationship', '$URI', '$Dataset');
EOM
	if ($DoWrite) {print OUT "$SqlStatement";}
}
close OUT;
system "$ENV{'ED'} $F1"

#Term	Relationship	Datasets	extURI
