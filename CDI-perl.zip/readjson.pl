#!perl.exe -w
use JSON;
$F1 = "C:\\temp\\xyzzy.json";
open (IN,"<",$F1) || die "Choke on open $F1:$!\n";

print "<table border=1>\n";
$JSON_text=(<IN>);
print "===\n$JSON_text\n===\n";
$JSON_Hash = decode_json $JSON_text;
print $JSON_Hash;
while (($key,$value) = each %JSON_Hash) {
#	$value = "(N/A)" if !($value);
	print "<td>$key<td> $value<tr>\n";
}
print "</table>\n";
