#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\WI-load-cmap.sql";
$F2 = "C:\\db\\gsfc\\WI-load-rship.sql";
$Relationship = "Throw this away";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
open (OUT2,">",$F2) || die "choke on open out $F2: $!\n";
print OUT2 "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
	($Subject,$Predicate,$Relationship,$Object) = split(/\t/);
	$Subject = trim($Subject);		# trim trailing/leading spaces
	$Predicate = trim($Predicate);
	$Object= trim($Object);
	$Preds{$Predicate}++; #Count Predicates
#print OUT<<EOM;
#INSERT INTO term_rel (term_subject, relationship, term_object) ((SELECT s.id 
#                                                       FROM term AS s
#                                                       WHERE s.term = '$Subject' and s.lexicon_identifier = 'cdi'
#                                                      ), '$Predicate',
#                                                       (SELECT o.id
#                                                        FROM term AS o
#                                                        WHERE o.term = '$Object'  and o.lexicon_identifier = 'cdi'
#                                                       ));#
#
#EOM
print OUT<<EOM;
INSERT INTO term_rel (term_subject, relationship, term_object) VALUES ((SELECT s.id FROM term AS s WHERE s.term = '$Subject' and s.lexicon_identifier = 'cdi'), '$Predicate', (SELECT o.id FROM term AS o WHERE o.term = '$Object' and o.lexicon_identifier = 'cdi' ));
EOM
}
foreach $key (sort keys(%Preds)){  # generate relationship statements
	$Count = $Preds{$key};
	$Tot1 += $Count;
	print OUT2 "INSERT INTO relationship (relationship) VALUES ('$key');\n";
    }
#print OUT2 " -- [$Tot1]\n";
close OUT;
close OUT2;
system "$ENV{'ED'} $F2 $F1"
#Subject	Predicate	Relationship	Object
__DATA__
Health	skos:narrower	is broader than	Water Related Illnesses
Water Related Illnesses	isInfluencedBy	isInfluencedBy	Human Vulnerability
Human Vulnerability	isDeterminedBy	isDeterminedBy	Socioeconomic Risks
Socioeconomic Risks	isResultOf	Include	Social Mores
Socioeconomic Risks	isResultOf	Include	Health Care Access
Socioeconomic Risks	isResultOf	Include	Employment
Socioeconomic Risks	isResultOf	Include	Poverty
Socioeconomic Risks	isResultOf	Include	Education
Socioeconomic Risks	isDeterminedBy	isDeterminedBy	Language
Socioeconomic Risks	isDeterminedBy	isDeterminedBy	Housing
Socioeconomic Risks	isDeterminedBy	isDeterminedBy	Environment
Socioeconomic Risks	isDeterminedBy	isDeterminedBy	Transportation
Human Vulnerability	isDeterminedBy	isDeterminedBy	Populations at Risk
Populations at Risk	isResultOf	Include	Indigenous People
Populations at Risk	isResultOf	Include	Pregnant
Populations at Risk	isResultOf	Include	Race/Ethnicity
Populations at Risk	isResultOf	Include	Age
Populations at Risk	isResultOf	Include	Sex/Gender
Water Related Illnesses	isInfluencedBy	isInfluencedBy	Response
Response	skos:narrower	Include	Planning
Planning	isDoneFor	Include	Urban Growth
Planning	isDoneFor	Include	Nuisance Flooding
Planning	isDoneFor	Include	Storm Shelters
Response	isDoneFor	Include	Mitigation
Mitigation	skos:narrower	Include	Agricultural Management Practices
Mitigation	isDoneFor	Include	Health Surveillance System
Mitigation	isDoneFor	Include	Shellfish Bed Closure
Response	skos:narrower	Include	Notification
Notification	skos:narrower	Include	Reporting Capacity
Water Related Illnesses	isInfluencedBy	isInfluencedBy	Hydrology
Hydrology	skos:narrower	Include	Discharge
Hydrology	skos:narrower	Include	Watershed
Hydrology	skos:narrower	Include	Nutrient Loading
Hydrology	skos:narrower	Include	Turbidity
Hydrology	skos:narrower	Include	Stream Flow
Hydrology	skos:narrower	Include	Eutrophication
Hydrology	skos:narrower	Include	Residence Time
Hydrology	skos:narrower	Include	Harmful Algal Blooms (HABs)
Water Related Illnesses	isInfluencedBy	isInfluencedBy	Infrastructure
Infrastructure	skos:narrower	Include	Water Purification Systems
Water Purification Systems	skos:narrower	Include	Water Treatment Plants
Water Purification Systems	skos:narrower	Include	Water Distribution Systems
Water Purification Systems	skos:narrower	Include	Pipelines
Water Purification Systems	skos:narrower	Include	Water Towers
Water Purification Systems	skos:narrower	Include	Water Tanks
Infrastructure	skos:narrower	Include	Wastewater System
Wastewater System	skos:narrower	Include	Septic Systems
Wastewater System	skos:narrower	Include	Sanitary Sewer Systems
Wastewater System	skos:narrower	Include	Wastewater Treatment Plant
Wastewater System	skos:narrower	Include	Lifts
Wastewater System	skos:narrower	Include	Sewer Pipes
Wastewater System	skos:narrower	Include	Wastewater Lagoons
Infrastructure	skos:narrower	Include	Stormwater Systems
Infrastructure	skos:narrower	Include	Combined Sewer Systems
Infrastructure	skos:narrower	Include	Wells
Water Related Illnesses	isInfluencedBy	isInfluencedBy	Exposure
Exposure	isDeterminedBy	isDeterminedBy	Location
Location	skos:narrower	canOccur	Geographic Distribution
Location	skos:narrower	canOccur	Habitat
Location	skos:narrower	canOccur	CaFOs
Exposure	isDeterminedBy	isDeterminedBy	Time
Time	skos:narrower	Include	Seasonal Growth Window
Exposure	isDeterminedBy	isDeterminedBy	Pathway
Pathway	skos:narrower	Include	Recreational Water
Pathway	skos:narrower	Include	Fish
Pathway	skos:narrower	Include	Shellfish
Pathway	skos:narrower	Include	Drinking Water
Exposure	isDeterminedBy	isDeterminedBy	Sources
Sources	skos:narrower	Include	Human Waste
Sources	skos:narrower	Include	Animal Waste
Sources	skos:narrower	Include	Agriculture
Sources	skos:narrower	Include	Fertilizers
Exposure	isDeterminedBy	isDeterminedBy	Contaminants
Contaminants	skos:narrower	canBe	Pathogens
Pathogens	skos:narrower	Include	Cyanobacteria
Pathogens	skos:narrower	Include	Vibrio
Pathogens	skos:narrower	Include	Cholera
Pathogens	skos:narrower	Include	Cryptosporidium
Pathogens	skos:narrower	Include	Giardia
Pathogens	skos:narrower	Include	Salmonella enterica
Pathogens	skos:narrower	Include	Naegleria
Pathogens	skos:narrower	Include	Leptospira
Pathogens	skos:narrower	Include	Leptonema
Pathogens	skos:narrower	Include	Campylobacter
Pathogens	skos:narrower	Include	Escherichia coli
Pathogens	skos:narrower	Include	Enteroviruses
Pathogens	skos:narrower	Include	Rotaviruses
Pathogens	skos:narrower	Include	Noroviruses
Contaminants	skos:narrower	canBe	Chemicals
Chemicals	skos:narrower	Include	Mercury
Chemicals	skos:narrower	Include	Organohalogens
Chemicals	skos:narrower	Include	Organotins
Contaminants	skos:narrower	canBe	Biotoxins
Biotoxins	skos:narrower	Include	Ciguatoxins
Biotoxins	skos:narrower	Include	Saxitoxins
Biotoxins	skos:narrower	Include	Domoic Acids
Biotoxins	skos:narrower	Include	Okadaic Acids
Biotoxins	skos:narrower	Include	Brevetoxins
Water Related Illnesses	isInfluencedBy	isInfluencedBy	Natural Hazard
Natural Hazard	skos:narrower	Include	Drought
Natural Hazard	skos:narrower	Include	Runoff
Natural Hazard	skos:narrower	Include	Flooding
Natural Hazard	skos:narrower	Include	Storm Surge
Natural Hazard	skos:narrower	Include	Sea Level Rise
Natural Hazard	skos:narrower	Include	Hurricanes
Water Related Illnesses	isInfluencedBy	isInfluencedBy	Climate Indicators
Climate Indicators	skos:narrower	Include	Sea Surface Temperature
Climate Indicators	skos:narrower	Include	Temperature
Climate Indicators	skos:narrower	Include	Precipitation
Climate Indicators	skos:narrower	Include	Salinity
