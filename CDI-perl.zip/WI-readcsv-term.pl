#!/usr/bin/env perl -w
# Reads CSV output of EXCEL spreadsheet, replaces newlines with spaces, formats into SQL statement
use vcfw;
use strict;
use warnings;
use Text::CSV_XS;
use Text::Unidecode;
my $Path = "c:\\db\\gsfc\\";
my $DoWrite =1;

my $ThisValue = "";
my $ThisColumn = "";
my $InsertNames = "";
my $InsertValues = "";

my $Insert1 = "INSERT INTO TERM (lexicon_identifier,context_identifier,term,description,is_root,url) ";
my $FileNameRoot = "WI-term";
my $InputFile  = $Path.$FileNameRoot.".csv";
my $OutputFile = $Path.$FileNameRoot.".sql";
#my $Edit = $ENV{'ED'};
my $Edit = "c:\\progra~2\\editpl~1\\editplus.exe";
my $Context= "waterIllness";
my $OutCount=0;
my $InputLineNumber = 1;

my $My_identifier = "";
my $My_context_identifier = "";
my $My_term = "";
my $My_description = "";
my $My_is_root = "";
my $My_url = "";
my $My_blank1 = "";
my $My_blank2 = "";
my $My_blank3 = "";
my $My_blank4 = "";
my $My_mesh_description = "";
my $My_mesh_url = "";
my $My_meshid = "";
open (my $CSV_FH, "<",$InputFile) or die "choke on open input $InputFile: $!";
open (OUT_FH, ">",$OutputFile) or die "choke on open output $OutputFile: $!";
print OUT_FH "-- O/P of $0\n";

my $csv = Text::CSV_XS->new ( { binary => 1 } )    #binary for mulitline fields
           or die "Cannot use Text::CSV " . Text::CSV->error_diag ();

$csv->column_names ($csv->getline($CSV_FH));    #define column names from first line
while (my $rowhash = $csv->getline_hr($CSV_FH)) { # Loop thru file

#	$My_identifier = $rowhash->{'identifier'};
#	$My_context_identifier = $rowhash->{'context_identifier'};
	$My_term = $rowhash->{'term'};
	$My_description = $rowhash->{'description'};
	$My_description = $rowhash->{'description'};
	$My_description = unidecode($My_description);	#convert UTF chars
	$My_description =~ s/'/''/g;		#Escape single quotes
	$My_description =~ s/"/''/g;		#Double Quotes to (escaped) single quotes
	$My_description =~ s/\n/ /g;		#Delete newlines
	$My_description =~ s/\x00//g;		#Delete nulls
	$My_description =~ s/\r//g;			#Delete CR (1)
	$My_description =~ s/\x0a//g;		#Delete LF
	$My_description =~ s/\x0d//g;		#Delete CR

	$My_is_root = $rowhash->{'is_root'};
	if ($My_is_root eq "") { $My_is_root = "FALSE"}
	$My_url = $rowhash->{'url'};
	$My_url =~ s/ \x0a//g;		#Delete LF
	$My_url =~ s/ \x0d//g;		#Delete CR
	$My_url =~ s/\x0a//g;		#Delete LF
	$My_url =~ s/\x0d//g;		#Delete CR

	$My_mesh_description = $rowhash->{'mesh_description'};
	$My_mesh_description = unidecode($My_mesh_description);	#convert UTF chars
	$My_mesh_description =~ s/'/''/g;		#Escape single quotes
	$My_mesh_description =~ s/"/''/g;		#Double Quotes to (escaped) single quotes
	$My_mesh_description =~ s/\n/ /g;		#Delete newlines
	$My_mesh_description =~ s/\x00//g;		#Delete nulls
	$My_mesh_description =~ s/\r//g;		#Delete nulls
	$My_mesh_description =~ s/\x0a//g;		#Delete LF
	$My_mesh_description =~ s/\x0d//g;		#Delete CR


	$My_mesh_url = $rowhash->{'mesh_url'};
	$My_mesh_url =~ s/ \x0a//g;		#Delete LF
	$My_mesh_url =~ s/ \x0d//g;		#Delete CR
	$My_mesh_url =~ s/\x0a//g;		#Delete LF
	$My_mesh_url =~ s/\x0d//g;		#Delete CR


	$My_meshid = $rowhash->{'meshid'};
	$InputLineNumber++;
	if ($My_term ne "") { #$My_is_root ne "") {  #Do actual Writes
		$OutCount++;
		print OUT_FH<<EOM;
INSERT INTO TERM (lexicon_identifier,context_identifier,term,description,is_root,url) VALUES ('cdi','health','$My_term','$My_description','$My_is_root','$My_url');
INSERT INTO TERM (lexicon_identifier,context_identifier,term,description,is_root,url) VALUES ('concept-map','$Context','$My_term','$My_description','$My_is_root','$My_url');
EOM
		if ($My_meshid ne ""){ # and $My_is_root ne "") {  #Handle entries with MeSHid's
			print OUT_FH<<EOM;
INSERT INTO TERM (lexicon_identifier,context_identifier,term,description,is_root,url) VALUES ('mesh','resource','$My_term','$My_mesh_description ($My_meshid)','$My_is_root','$My_mesh_url');
EOM
		}
	}
}	#End of file
close $CSV_FH;
close OUT_FH;
system "$Edit $InputFile $OutputFile";
