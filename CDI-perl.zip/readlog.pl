#!/usr/local/bin/perl

while (<STDIN>) {
    $d = $_;
 $l++;
 print "$l: $d";
 }
$Out = $d;
$Out =~ s/\[/\n\[/g;

print "EOF on STDIN: $l lines encountered\n";
print STDOUT "This message is going to STDOUT\n";
print STDERR "This message is going to STDERR\n";
print $Out;
