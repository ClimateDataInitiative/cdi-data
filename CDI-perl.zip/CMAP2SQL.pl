#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\gg\\AWSEC2~1\\VCFW\\load-cmap.sql";
$F2 = "C:\\gg\\AWSEC2~1\\VCFW\\load-rship.sql";
$Relationship = "Throw this away";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
open (OUT2,">",$F2) || die "choke on open out $F2: $!\n";
while (<DATA>) 	{
	chomp;
	($Subject,$Predicate,$Relationship,$Object) = split(/\t/);
	$Subject = trim($Subject);		# trim trailing/leading spaces
	$Predicate = trim($Predicate);
	$Object= trim($Object);
	$Preds{$Predicate}++; #Count Predicates
#print OUT<<EOM;
#INSERT INTO term_rel (term_subject, relationship, term_object) ((SELECT s.id 
#                                                       FROM term AS s
#                                                       WHERE s.term = '$Subject' and s.lexicon_identifier = 'cdi'
#                                                      ), '$Predicate',
#                                                       (SELECT o.id
#                                                        FROM term AS o
#                                                        WHERE o.term = '$Object'  and o.lexicon_identifier = 'cdi'
#                                                       ));#
#
#EOM
print OUT<<EOM;
INSERT INTO term_rel (term_subject, relationship, term_object) VALUES ((SELECT s.id FROM term AS s WHERE s.term = '$Subject' and s.lexicon_identifier = 'cdi'), '$Predicate', (SELECT o.id FROM term AS o WHERE o.term = '$Object' and o.lexicon_identifier = 'cdi' ));
EOM
}
foreach $key (sort keys(%Preds)){  # generate relationship statements
	$Count = $Preds{$key};
	$Tot1 += $Count;
	print OUT2 "INSERT INTO relationship (relationship) VALUES ('$key');\n";
    }
#print OUT2 " -- [$Tot1]\n";
close OUT;
close OUT2;
system "$ENV{'ED'} $F2 $F1"
#Subject	Predicate	Relationship	Object
__DATA__
Health	skos:narrower	isBroaderThan	Vector Borne Disease
Vector Borne Disease	isInfluencedBy	isInfluencedBy	Response
Response	skos:narrower	isComponentOf	Planning 
Planning	isDoneFor	For	New pathogen
Planning 	isDoneFor	For	Global travel
Planning 	isDoneFor	For	Global trade
Planning 	isDoneFor	For	Urban growth
Response	skos:narrower	isComponentOf	Mitigation
Mitigation 	isDoneFor	anActivityOf	Water management practices
Mitigation 	isDoneFor	anActivityOf	Control Methods (pesticides)
Mitigation 	isDoneFor	anActivityOf	Vector surveillance
Mitigation 	isDoneFor	anActivityOf	Land use practices
Response	skos:narrower	isComponentOf	Notification
Vector Borne Disease	isInfluencedBy	isInfluencedBy	Human Vulnerability
Human Vulnerability	isDeterminedBy	isDeterminedBy	Health Risks
Health Risks	isResultOf	includes	Outdoor activity
Health Risks	isResultOf	includes	Outdoor employment
Human Vulnerability	isDeterminedBy	isDeterminedBy	Population at risk
Population at risk	isResultOf	includes	Minorities
Population at risk	isResultOf	includes	Sex/Gender
Population at risk	isResultOf	includes	Elderly
Population at risk	isResultOf	includes	Children
Human Vulnerability	isDeterminedBy	isDeterminedBy	Socio-economic risk factors
Socio-economic risk factors	isResultOf	includes	Housing
Socio-economic risk factors	isResultOf	includes	Poverty
Socio-economic risk factors	isResultOf	includes	Education
Vector Borne Disease	isInfluencedBy	isInfluencedBy	Biological Variables
Biological Variables	skos:narrower	includes	Population size
Biological Variables	skos:narrower	includes	Population density
Biological Variables	skos:narrower	includes	Survival rates
Biological Variables	skos:narrower	includes	Host Abundance
Biological Variables	skos:narrower	includes	Pathogen Reproduction rate
Biological Variables	skos:narrower	includes	Zoonotic carriers
Biological Variables	skos:narrower	includes	Habitat availability
Biological Variables	skos:narrower	includes	Host Reproduction Rates
Biological Variables	skos:narrower	includes	Habitat Range
Biological Variables	skos:narrower	includes	Migration patterns
Vector Borne Disease	isInfluencedBy	isInfluencedBy	Infrastructure
Infrastructure	skos:narrower	includes	Hospital
Infrastructure	skos:narrower	includes	Dams and Reservoirs
Infrastructure	skos:narrower	includes	Irrigation 
Infrastructure	skos:narrower	includes	Airports
Vector Borne Disease	isInfluencedBy	isInfluencedBy	Exposure
Exposure	isDeterminedBy	isDeterminedBy	Pathway
Pathway	skos:narrower	includes	Ticks
Pathway	skos:narrower	includes	Mosquito
Pathway	skos:narrower	includes	Fleas
Exposure	isDeterminedBy	isDeterminedBy	Source
Source	skos:narrower	includes	Birds
Source	skos:narrower	includes	Rodents
Exposure	isDeterminedBy	isDeterminedBy	Location
Location	skos:narrower	canOccur	Geographic Distribution
Location	skos:narrower	canOccur	Proximity to water
Location	skos:narrower	canOccur	Urban
Exposure	isDeterminedBy	isDeterminedBy	Time
Time	skos:narrower	includes	Vector Seasonal Activity
Exposure	isDeterminedBy	isDeterminedBy	Contaminants
Contaminants	skos:narrower	CanBe	Pathogens
Pathogens	skos:narrower	includes	Bubonic Plague
Pathogens	skos:narrower	includes	Septicemic Plague
Pathogens	skos:narrower	includes	Pneumonic Plague
Pathogens	skos:narrower	includes	Lyme disease
Pathogens	skos:narrower	includes	Spotted Fever Rickettsia
Pathogens	skos:narrower	includes	Babesiosis
Pathogens	skos:narrower	includes	Anaplasmosis/Ehrlichiosis
Pathogens	skos:narrower	includes	Tularemia
Pathogens	skos:narrower	includes	St. Louis encephalitis
Pathogens	skos:narrower	includes	California Serogroup Viruses
Pathogens	skos:narrower	includes	Dengue
Pathogens	skos:narrower	includes	Malaria
Pathogens	skos:narrower	includes	West Nile Virus
Pathogens	skos:narrower	includes	Powassan
Pathogens	skos:narrower	includes	Eastern Equine Encephalitis
Pathogens	skos:narrower	includes	Murine Typhus
Vector Borne Disease	isInfluencedBy	isInfluencedBy	Natural Hazard
Natural Hazard	skos:narrower	includes	Flooding
Natural Hazard	skos:narrower	includes	Drought
Natural Hazard	skos:narrower	includes	Hurricane
Vector Borne Disease	isInfluencedBy	isInfluencedBy	Climate Indicators
Climate Indicators	skos:narrower	includes	Temperature
Climate Indicators	skos:narrower	includes	Precipitation
Climate Indicators	skos:narrower	include	Humidity
