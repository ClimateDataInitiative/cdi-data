#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\AQ\\AQ-load-term-map.sql";
$Relationship = "Throw this away";
$Sql1="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
	($Term,$Relationship,$Dataset,$URI) = split(/\t/);
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term eq "") {
		$ThisTerm = $OldTerm
	} else {
		$ThisTerm = $OldTerm = $Term;
	}
	$Dataset = trim($Dataset);
	$Dataset =~ s/'/''/g;		#Escape single quotes
	if ($Dataset eq "") {
		$Dataset= "N/A";
	}

	$URI= trim($URI);
	if ($URI eq "") {
		$URI= "N/A";
	}
	$Relationship = trim($Relationship);

$Sql1 = "INSERT INTO term_map (term_identifier, relationship_identifier, gcid, description) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = ";
	$OutLine=<<EOM;
$Sql1'$ThisTerm' and s.lexicon_identifier = 'cdi'), 'isMentionedIn', '$URI', '$Dataset');
EOM

	print OUT "$OutLine";
}
close OUT;
system "$ENV{'ED'} $F1"
#Subject	Predicate	Relationship	Object
#Term	Relationship	Datasets	extURI		
#xtermid	contextid	Term	Relationship	Datasets	extURI

__DATA__
Health	isMentionedIn		https://catalog.data.gov/dataset?vocab_category_all=Human+Health&groups=climate5434#topic=humanhealth_navigation
Air Quality	isMentionedIn		https://catalog.data.gov/dataset?q=air+quality&sort=none&vocab_category_all=Human+Health&groups=climate5434&ext_location=&ext_bbox=&ext_prev_extent=-142.03125%2C8.754794702435605%2C-59.0625%2C61.77312286453148#topic=humanhealth_navigation
Air Quality	isMentionedIn	Air Markets Program Data (AMPD)	http://catalog.data.gov/dataset/air-markets-program-data-ampd
Air Quality	isMentionedIn	Analysis of Methane Mitigation Options using the MARKAL Model for the US: Calibration Data for Methane Emissions	http://catalog.data.gov/dataset/analysis-of-methane-mitigation-options-using-the-markal-model-for-the-us-calibrati
Air Quality	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Air Quality	isMentionedIn	CDC WONDER: Daily Fine Particulate Matter	http://catalog.data.gov/dataset/cdc-wonder-daily-fine-particulate-matter
Air Quality	isMentionedIn	Clean Air Markets - Data and Maps Web Application	http://catalog.data.gov/dataset/clean-air-markets-data-and-maps-web-application-9ed43
Air Quality	isMentionedIn	Clean Air Markets - Where You Live (National and State Maps)	http://catalog.data.gov/dataset/clean-air-markets-where-you-live-national-and-state-maps
Air Quality	isMentionedIn	Clean Air Status and Trends Network (CASTNET)	http://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet
Air Quality	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	http://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Air Quality	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	http://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Air Quality	isMentionedIn	Global Annual Average PM2.5 Grids from MODIS and MISR Aerosol Optical Depth (AOD)	http://catalog.data.gov/dataset/global-annual-average-pm2-5-grids-from-modis-and-misr-aerosol-optical-depth-aod
Air Quality	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Air Quality	isMentionedIn	Global Surface Summary of the Day - GSOD	http://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Air Quality	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Air Quality	isMentionedIn	ISLSCP II EDGAR 3 Gridded Greenhouse and Ozone Precursor Gas Emissions	http://catalog.data.gov/dataset/islscp-ii-edgar-3-gridded-greenhouse-and-ozone-precursor-gas-emissions
Air Quality	isMentionedIn	Methane Flux	http://catalog.data.gov/dataset/methane-flux
Air Quality	isMentionedIn	MODIS/Terra+Aqua NRT value-added Aerosol Optical Depth Produc V051 NRT	http://catalog.data.gov/dataset/modis-terraaqua-nrt-value-added-aerosol-optical-depth-produc-v051-nrt
Air Quality	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Air Quality	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Air Quality	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	https://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Air Quality	isMentionedIn	Report on U.S. Methane Emissions 1990-2020: Inventories, Projections, and Opportunities for Reductions: 2001 Updated emission and cost estimates	http://catalog.data.gov/dataset/report-on-u-s-methane-emissions-1990-2020-inventories-projections-and-opportunitie
Air Quality	isMentionedIn	Tropospheric Emission Spectrometer (TES) Data	http://catalog.data.gov/dataset/tropospheric-emission-spectrometer-tes-data
Climate Indicators	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
Climate Indicators	isMentionedIn	Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis
Climate Indicators	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
Climate Indicators	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Climate Indicators	isMentionedIn	Global Climate Station Summaries	https://catalog.data.gov/dataset/global-climate-station-summaries
Climate Indicators	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Climate Indicators	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
Climate Indicators	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Climate Indicators	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	http://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Climate Indicators	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Climate Indicators	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Climate Indicators	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
Climate Indicators	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Climate Indicators	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Climate Indicators	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Climate Indicators	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Climate Indicators	isMentionedIn	U.S. Hourly Precipitation Data	https://catalog.data.gov/dataset/u-s-hourly-precipitation-data
Climate Indicators	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Climate Indicators	isMentionedIn	United States Average Annual Precipitation, 1990-2009 - Direct Download	https://catalog.data.gov/dataset/united-states-average-annual-precipitation-1990-2009-direct-download
Length of growing season	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Vertical mixing			
Temperature	isMentionedIn	CDC WONDER: Daily Air Temperatures and Heat Index	https://catalog.data.gov/dataset/cdc-wonder-daily-air-temperatures-and-heat-index
Temperature	isMentionedIn	CDC WONDER: Daily Fine Particulate Matter	https://catalog.data.gov/dataset/cdc-wonder-daily-fine-particulate-matter
Temperature	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
Temperature	isMentionedIn	Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis
Temperature	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
Temperature	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Temperature	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
Temperature	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Temperature	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Temperature	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
Temperature	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Temperature	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	https://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Temperature	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Temperature	isMentionedIn	MODIS/Terra+Aqua NRT value-added Aerosol Optical Depth Produc V051 NRT	http://catalog.data.gov/dataset/modis-terraaqua-nrt-value-added-aerosol-optical-depth-produc-v051-nrt
Temperature	isMentionedIn	National Integrated Drought Information System	http://catalog.data.gov/dataset/national-integrated-drought-information-system
Temperature	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Temperature	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
Temperature	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
Temperature	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Temperature	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
Temperature	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Temperature	isMentionedIn	Tropospheric Emission Spectrometer (TES) Data	http://catalog.data.gov/dataset/tropospheric-emission-spectrometer-tes-data
Temperature	isMentionedIn	U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries
Temperature	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Temperature	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Temperature	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Temperature	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Temperature	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Temperature	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Temperature	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Wind	isMentionedIn	Climate Data Online (CDO)	http://catalog.data.gov/dataset/climate-data-online-cdo
Wind	isMentionedIn	Geographical Information System Graphical Database of Tornados 1950-2006	http://catalog.data.gov/dataset/geographical-information-system-graphical-database-of-tornados-1950-2006
Wind	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Wind	isMentionedIn	Global Surface Summary of the Day - GSOD	http://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Wind	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Wind	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Wind	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
Wind	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Wind	isMentionedIn	PRISM	https://catalog.data.gov/dataset/prism-585c8
Wind	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	https://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Wind	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Wind	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Cloud Cover	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Cloud Cover	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Cloud Cover	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	https://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Cloud Cover	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Latitudinal Effects			
Precipitation	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	https://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
Precipitation	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Precipitation	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
Precipitation	isMentionedIn	Global Climate Station Summaries	https://catalog.data.gov/dataset/global-climate-station-summaries
Precipitation	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Precipitation	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Precipitation	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	https://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Precipitation	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Precipitation	isMentionedIn	MODIS/Terra+Aqua NRT value-added Aerosol Optical Depth Produc V051 NRT	http://catalog.data.gov/dataset/modis-terraaqua-nrt-value-added-aerosol-optical-depth-produc-v051-nrt
Precipitation	isMentionedIn	National Integrated Drought Information System	http://catalog.data.gov/dataset/national-integrated-drought-information-system
Precipitation	isMentionedIn	NOAA Climate Data Record (CDR) of Precipitation Estimation from Remotely Sensed Information using Artificial Neural Networks (PERSIANN-CDR)- Version 1 Revision 1	http://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-precipitation-estimation-from-remotely-sensed-information-using
Precipitation	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Precipitation	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
Precipitation	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Precipitation	isMentionedIn	U.S. 15 Minute Precipitation Data	http://catalog.data.gov/dataset/u-s-15-minute-precipitation-data
Precipitation	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Precipitation	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Precipitation	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Precipitation	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Precipitation	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Precipitation	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Precipitation	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Precipitation	isMentionedIn	U.S. Hourly Precipitation Data	https://catalog.data.gov/dataset/u-s-hourly-precipitation-data
Precipitation	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Precipitation	isMentionedIn	United States Average Annual Precipitation- 1990-2009 - Direct Download	http://catalog.data.gov/dataset/united-states-average-annual-precipitation-1990-2009-direct-download
Precipitation	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Precipitation	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
Precipitation	isMentionedIn	U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries
Precipitation	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Humidity	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Humidity	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Humidity	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
Humidity	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Humidity	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Humidity	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Extreme Weather	isMentionedIn	NOAA Emergency Response Imagery	http://catalog.data.gov/dataset/noaa-emergency-response-imagery
Extreme Weather	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
Extreme Weather	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Extreme Weather	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
Extreme Weather	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	https://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Extreme Weather	isMentionedIn	Fire Weather Outlooks	https://catalog.data.gov/dataset/fire-weather-outlooks
Extreme Weather	isMentionedIn	Geographical Information System Graphical Database of Tornados 1950-2006	https://catalog.data.gov/dataset/geographical-information-system-graphical-database-of-tornados-1950-2006
Extreme Weather	isMentionedIn	Global Climate Station Summaries	https://catalog.data.gov/dataset/global-climate-station-summaries
Extreme Weather	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Extreme Weather	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
Extreme Weather	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Extreme Weather	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Extreme Weather	isMentionedIn	National Flood Hazard Layer (NFHL)	https://catalog.data.gov/dataset/national-flood-hazard-layer-nfhl
Extreme Weather	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Extreme Weather	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries	https://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
Extreme Weather	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Extreme Weather	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Extreme Weather	isMentionedIn	Severe Weather Data Inventory	http://catalog.data.gov/dataset/severe-weather-data-inventory
Extreme Weather	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
Extreme Weather	isMentionedIn	U.S. Annual Climatological Summaries	https://catalog.data.gov/dataset/u-s-annual-climatological-summaries
Extreme Weather	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Extreme Weather	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Extreme Weather	isMentionedIn	United States Average Annual Precipitation, 1990-2009 - Direct Download	https://catalog.data.gov/dataset/united-states-average-annual-precipitation-1990-2009-direct-download
Extreme Weather	isMentionedIn	USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	http://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass
Wildfires	isMentionedIn	Fire Weather Outlooks	https://catalog.data.gov/dataset/fire-weather-outlooks
Wildfires	isMentionedIn	LandCarbon Conterminous United States Burned Area and Severity Mosaics 2001-2050 Metadata	https://catalog.data.gov/dataset/landcarbon-conterminous-united-states-burned-area-and-severity-mosaics-2001-2050-metadata
Wildfires	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Exposure	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Exposure	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Exposure	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Exposure	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Contaminants	isMentionedIn	Air Markets Program Data (AMPD)	https://catalog.data.gov/dataset/air-markets-program-data-ampd
Contaminants	isMentionedIn	Analysis of Methane Mitigation Options using the MARKAL Model for the US: Calibration Data for Methane Emissions	https://catalog.data.gov/dataset/analysis-of-methane-mitigation-options-using-the-markal-model-for-the-us-calibration-data-for-m
Contaminants	isMentionedIn	Clean Air Markets - Where You Live (National and State Maps)	https://catalog.data.gov/dataset/clean-air-markets-where-you-live-national-and-state-maps
Contaminants	isMentionedIn	Clean Air Status and Trends Network (CASTNET)	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet
Contaminants	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Contaminants	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Contaminants	isMentionedIn	Report on U.S. Methane Emissions 1990-2020: Inventories, Projections, and Opportunities for Reductions: 2001 Updated emission and cost estimates	https://catalog.data.gov/dataset/report-on-u-s-methane-emissions-1990-2020-inventories-projections-and-opportunities-for-reducti
Contaminants	isMentionedIn	Safe Drinking Water Information System (SDWIS)	https://catalog.data.gov/dataset/safe-drinking-water-information-system-sdwis
Gases and Particulates	isMentionedIn	MODIS/Terra+Aqua NRT value-added Aerosol Optical Depth Produc V051 NRT	http://catalog.data.gov/dataset/modis-terraaqua-nrt-value-added-aerosol-optical-depth-produc-v051-nrt
Gases and Particulates	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Gases and Particulates	isMentionedIn	Report on U.S. Methane Emissions 1990-2020: Inventories, Projections, and Opportunities for Reductions: 2001 Updated emission and cost estimates	https://catalog.data.gov/dataset/report-on-u-s-methane-emissions-1990-2020-inventories-projections-and-opportunities-for-reducti
Gases and Particulates	isMentionedIn	Tropospheric Emission Spectrometer (TES) Data	http://catalog.data.gov/dataset/tropospheric-emission-spectrometer-tes-data
Pollen	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Pollen	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Pollen	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Pollen	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Pollen	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Pollen	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Sulfates			
Sulfur Dioxide	isMentionedIn	ISLSCP II EDGAR 3 Gridded Greenhouse and Ozone Precursor Gas Emissions	http://catalog.data.gov/dataset/islscp-ii-edgar-3-gridded-greenhouse-and-ozone-precursor-gas-emissions
Sulfur Dioxide	isMentionedIn	MODIS/Terra+Aqua NRT value-added Aerosol Optical Depth Produc V051 NRT	http://catalog.data.gov/dataset/modis-terraaqua-nrt-value-added-aerosol-optical-depth-produc-v051-nrt
Sulfur Dioxide	isMentionedIn	Air Markets Program Data (AMPD)	http://catalog.data.gov/dataset/air-markets-program-data-ampd
Sulfur Dioxide	isMentionedIn	Clean Air Markets - Where You Live (National and State Maps)	http://catalog.data.gov/dataset/clean-air-markets-where-you-live-national-and-state-maps
Sulfur Dioxide	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Ammonium	isMentionedIn	Tropospheric Emission Spectrometer (TES) Data	http://catalog.data.gov/dataset/tropospheric-emission-spectrometer-tes-data
Ammonium	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Sea Salt			
Nitrates	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Nitrogen Oxides	isMentionedIn	Air Markets Program Data (AMPD)	http://catalog.data.gov/dataset/air-markets-program-data-ampd
Nitrogen Oxides	isMentionedIn	Clean Air Markets - Where You Live (National and State Maps)	http://catalog.data.gov/dataset/clean-air-markets-where-you-live-national-and-state-maps
Nitrogen Oxides	isMentionedIn	ISLSCP II EDGAR 3 Gridded Greenhouse and Ozone Precursor Gas Emissions	http://catalog.data.gov/dataset/islscp-ii-edgar-3-gridded-greenhouse-and-ozone-precursor-gas-emissions
Nitrogen Oxides	isMentionedIn	Methane Flux	http://catalog.data.gov/dataset/methane-flux
Nitrogen Oxides	isMentionedIn	MODIS/Terra+Aqua NRT value-added Aerosol Optical Depth Produc V051 NRT	http://catalog.data.gov/dataset/modis-terraaqua-nrt-value-added-aerosol-optical-depth-produc-v051-nrt
Nitrogen Oxides	isMentionedIn	Tropospheric Emission Spectrometer (TES) Data	http://catalog.data.gov/dataset/tropospheric-emission-spectrometer-tes-data
Nitrogen Oxides	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Particulate Matter	isMentionedIn	CDC WONDER: Daily Fine Particulate Matter	http://catalog.data.gov/dataset/cdc-wonder-daily-fine-particulate-matter
Particulate Matter	isMentionedIn	Global Annual Average PM2.5 Grids from MODIS and MISR Aerosol Optical Depth (AOD)	https://catalog.data.gov/dataset/global-annual-average-pm2-5-grids-from-modis-and-misr-aerosol-optical-depth-aod
Particulate Matter	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Ozone	isMentionedIn	Air Markets Program Data (AMPD)	http://catalog.data.gov/dataset/air-markets-program-data-ampd
Ozone	isMentionedIn	MODIS/Terra+Aqua NRT value-added Aerosol Optical Depth Produc V051 NRT	http://catalog.data.gov/dataset/modis-terraaqua-nrt-value-added-aerosol-optical-depth-produc-v051-nrt
Ozone	isMentionedIn	Tropospheric Emission Spectrometer (TES) Data	http://catalog.data.gov/dataset/tropospheric-emission-spectrometer-tes-data
Ozone	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Allergic Proteins			
Dust Mites			
Dust			
Mold Spores			
Animal Dander			
Aeroallergens			
Carbon	isMentionedIn	Air Markets Program Data (AMPD)	http://catalog.data.gov/dataset/air-markets-program-data-ampd
Carbon	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	http://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Carbon	isMentionedIn	ISLSCP II EDGAR 3 Gridded Greenhouse and Ozone Precursor Gas Emissions	http://catalog.data.gov/dataset/islscp-ii-edgar-3-gridded-greenhouse-and-ozone-precursor-gas-emissions
Carbon	isMentionedIn	Methane Flux	http://catalog.data.gov/dataset/methane-flux
Carbon	isMentionedIn	Tropospheric Emission Spectrometer (TES) Data	http://catalog.data.gov/dataset/tropospheric-emission-spectrometer-tes-data
Volatile Organic Compounds	isMentionedIn	ISLSCP II EDGAR 3 Gridded Greenhouse and Ozone Precursor Gas Emissions	http://catalog.data.gov/dataset/islscp-ii-edgar-3-gridded-greenhouse-and-ozone-precursor-gas-emissions
Location	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Location	isMentionedIn	CDC WONDER: Daily Fine Particulate Matter	http://catalog.data.gov/dataset/cdc-wonder-daily-fine-particulate-matter
Location	isMentionedIn	Clean Air Markets - Where You Live (National and State Maps)	http://catalog.data.gov/dataset/clean-air-markets-where-you-live-national-and-state-maps
Location	isMentionedIn	Clean Air Status and Trends Network (CASTNET)	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet
Location	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Location	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Location	isMentionedIn	Report on U.S. Methane Emissions 1990-2020: Inventories, Projections, and Opportunities for Reductions: 2001 Updated emission and cost estimates	https://catalog.data.gov/dataset/report-on-u-s-methane-emissions-1990-2020-inventories-projections-and-opportunities-for-reducti
Outdoor	isMentionedIn	CDC WONDER: Daily Fine Particulate Matter	http://catalog.data.gov/dataset/cdc-wonder-daily-fine-particulate-matter
Outdoor	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Indoor			
Urban Areas	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Urban Areas	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Sources	isMentionedIn	Air Markets Program Data (AMPD)	http://catalog.data.gov/dataset/air-markets-program-data-ampd
Pets			
Motor Vehicles			
Vegetation			
Mold/Mildew			
Cockroaches			
Power Plant	isMentionedIn	Air Markets Program Data (AMPD)	http://catalog.data.gov/dataset/air-markets-program-data-ampd
Infrastructure	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Infrastructure	isMentionedIn	USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	https://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass
Air Ventilation			
Power Outage	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Air Infiltration			
Human Vulnerability	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Human Vulnerability	isMentionedIn	CDC WONDER: Cancer Statistics 	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	"https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths"
Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Human Vulnerability	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
Human Vulnerability	isMentionedIn	HCUPnet	http://catalog.data.gov/dataset/hcupnet
Human Vulnerability	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Human Vulnerability	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
Human Vulnerability	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Health Risks	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Health Risks	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Health Risks	isMentionedIn	FluView National Flu Activity Map	https://catalog.data.gov/dataset/fluview-national-flu-activity-map
Health Risks	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Lung Cancer	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Hives			
Mortality	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Mortality	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Mortality	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Mortality	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Mortality	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Mortality	isMentionedIn	National Death Index	http://catalog.data.gov/dataset/national-death-index
Mortality	isMentionedIn	VitalStats	http://catalog.data.gov/dataset/vitalstats
Eczema	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Eczema	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Eczema	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Eczema	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Eczema	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
COPD	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
COPD	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
COPD	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
COPD	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
COPD	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Hay Fever	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Hay Fever	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Hay Fever	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Hay Fever	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Hay Fever	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Anaphylaxis			
Existing Medical Conditions	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
Existing Medical Conditions	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Asthma	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Asthma	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Asthma	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Asthma	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Asthma	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Asthma	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Asthma	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Cardiovascular Disease	isMentionedIn	Global Annual Average PM2.5 Grids from MODIS and MISR Aerosol Optical Depth (AOD)	https://catalog.data.gov/dataset/global-annual-average-pm2-5-grids-from-modis-and-misr-aerosol-optical-depth-aod
Cardiovascular Disease	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Cardiovascular Disease	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Cardiovascular Disease	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Cardiovascular Disease	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Cardiovascular Disease	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Cardiovascular Disease	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Cardiovascular Disease	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Acute Respiratory Symptoms	isMentionedIn	Global Annual Average PM2.5 Grids from MODIS and MISR Aerosol Optical Depth (AOD)	https://catalog.data.gov/dataset/global-annual-average-pm2-5-grids-from-modis-and-misr-aerosol-optical-depth-aod
Acute Respiratory Symptoms	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Acute Respiratory Symptoms	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Acute Respiratory Symptoms	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Acute Respiratory Symptoms	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Acute Respiratory Symptoms	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Acute Respiratory Symptoms	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Populations at Risk	isMentionedIn	CDC WONDER: Cancer Statistics 	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Populations at Risk	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Populations at Risk	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	"https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths"
Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates
Populations at Risk	isMentionedIn	Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas
Populations at Risk	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Populations at Risk	isMentionedIn	National Death Index	http://catalog.data.gov/dataset/national-death-index
Populations at Risk	isMentionedIn	National Flood Hazard Layer (NFHL)	http://catalog.data.gov/dataset/national-flood-hazard-layer-nfhl
Populations at Risk	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
Populations at Risk	isMentionedIn	Supplemental Nutrition Assistance Program (SNAP) Data System	http://catalog.data.gov/dataset/supplemental-nutrition-assistance-program-snap-data-system-a2b49
Elderly	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Elderly	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Elderly	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Elderly	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Elderly	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Elderly	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Young	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Young	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	"https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths"
Young	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Young	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Young	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Young	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Young	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Minorities	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Minorities	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Minorities	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Minorities	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Minorities	isMentionedIn	CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates
Minorities	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Minorities	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Response			
Pathogen Distribution			
Exposure Threats	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Climate Projections	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	http://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Climate Projections	isMentionedIn	LandCarbon Conterminous United States Burned Area and Severity Mosaics 2001-2050 Metadata	https://catalog.data.gov/dataset/landcarbon-conterminous-united-states-burned-area-and-severity-mosaics-2001-2050-metadata
Climate Projections	isMentionedIn	Methane Flux	https://catalog.data.gov/dataset/methane-flux
Human Response	isMentionedIn	NOAA Emergency Response Imagery	https://catalog.data.gov/dataset/noaa-emergency-response-imagery
