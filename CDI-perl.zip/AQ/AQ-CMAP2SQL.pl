#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\AQ\\AQ-load-cmap.sql";
$F2 = "C:\\db\\gsfc\\AQ\\AQ-load-rship.sql";
$Relationship = "Throw this away";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
open (OUT2,">",$F2) || die "choke on open out $F2: $!\n";
print OUT2 "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
	($Subject,$Predicate,$Relationship,$Object) = split(/\t/);
	$Subject = trim($Subject);		# trim trailing/leading spaces
	$Predicate = trim($Predicate);
	$Object= trim($Object);
	$Preds{$Predicate}++; #Count Predicates
print OUT<<EOM;
INSERT INTO term_relationship (term_subject, relationship_identifier, term_object) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = '$Subject' and s.lexicon_identifier = 'cdi'), '$Predicate', (SELECT o.identifier FROM term AS o WHERE o.term = '$Object' and o.lexicon_identifier = 'cdi' ));
EOM
}
foreach $key (sort keys(%Preds)){  # generate relationship statements
	$Count = $Preds{$key};
	$Tot1 += $Count;
	print OUT2 "INSERT INTO relationship (relationship) VALUES ('$key');\n";
    }
#print OUT2 " -- [$Tot1]\n";
close OUT;
close OUT2;
system "$ENV{'ED'} $F2 $F1"
#Subject	Predicate	Relationship	Object
__DATA__
Health	skos:narrower	is broader than	Air Quality
Air Quality	isInfluencedBy	isInfluencedBy	Climate Indicators
Climate Indicators	skos:narrower	include	Length of growing season
Climate Indicators	skos:narrower	include	Vertical mixing
Climate Indicators	skos:narrower	include	Temperature
Climate Indicators	skos:narrower	include	Wind
Climate Indicators	skos:narrower	include	Cloud Cover
Climate Indicators	skos:narrower	include	Latitudinal Effects
Climate Indicators	skos:narrower	include	Precipitation
Climate Indicators	skos:narrower	include	Humidity
Air Quality	isInfluencedBy	isInfluencedBy	Extreme Weather
Extreme Weather	skos:narrower	include	Wildfires
Air Quality	isInfluencedBy	isInfluencedBy	Exposure
Exposure	isDeterminedBy	isDeterminedBy	Contaminants
Contaminants	skos:narrower	can be	Gases and Particulates
Gases and Particulates	skos:narrower	include	Pollen
Gases and Particulates	skos:narrower	include	Sulfur Dioxide
Gases and Particulates	skos:narrower	include	Sulfates
Gases and Particulates	skos:narrower	include	Ammonium
Gases and Particulates	skos:narrower	include	Sea Salt
Gases and Particulates	skos:narrower	include	Nitrates
Gases and Particulates	skos:narrower	include	Nitrogen Oxides
Gases and Particulates	skos:narrower	include	Particulate Matter
Gases and Particulates	skos:narrower	include	Ozone
Gases and Particulates	skos:narrower	include	Allergic Proteins
Gases and Particulates	skos:narrower	include	Dust Mites
Gases and Particulates	skos:narrower	include	Dust
Gases and Particulates	skos:narrower	include	Mold Spores
Gases and Particulates	skos:narrower	include	Animal Dander
Gases and Particulates	skos:narrower	include	Aeroallergens
Gases and Particulates	skos:narrower	include	Carbon
Gases and Particulates	skos:narrower	include	Volatile Organic Compounds
Exposure	isDeterminedBy	isDeterminedBy	Location
Location	skos:narrower	canOccur	Outdoor
Location	skos:narrower	canOccur	Indoor
Location	skos:narrower	canOccur	Urban Areas
Exposure	isDeterminedBy	isDeterminedBy	Sources
Sources	skos:narrower	include	Pets
Sources	skos:narrower	include	Motor Vehicles
Sources	skos:narrower	include	Vegetation
Sources	skos:narrower	include	Mold/Mildew
Sources	skos:narrower	include	Cockroaches
Sources	skos:narrower	include	Power Plant
Air Quality	isInfluencedBy	isInfluencedBy	Infrastructure
Infrastructure	skos:narrower	include	Air Ventilation
Infrastructure	skos:narrower	include	Power Outage
Infrastructure	skos:narrower	include	Air Infiltration
Air Quality	isInfluencedBy	isInfluencedBy	Human Vulnerability
Human Vulnerability	isDeterminedBy	isDeterminedBy	Health Risks
Health Risks	skos:narrower	ConsistOf	Resulting Medical Conditions
Resulting Medical Conditions	isResultOf	include	Lung Cancer
Resulting Medical Conditions	isResultOf	include	Hives
Resulting Medical Conditions	isResultOf	include	Mortality
Resulting Medical Conditions	isResultOf	include	Eczema
Resulting Medical Conditions	isResultOf	include	COPD
Resulting Medical Conditions	isResultOf	include	Hay Fever
Resulting Medical Conditions	isResultOf	include	Anaphylaxis
Health Risks	skos:narrower	ConsistOf	Existing Medical Conditions
Existing Medical Conditions	isResultOf	include	Asthma
Existing Medical Conditions	isResultOf	include	Cardiovascular Disease
Existing Medical Conditions	isResultOf	include	Acute Respiratory Symptoms
Human Vulnerability	isDeterminedBy	isDeterminedBy	Populations at Risk
Populations at Risk	isResultOf	include	Elderly
Populations at Risk	isResultOf	include	Young
Populations at Risk	isResultOf	include	Minorities
Air Quality	isInfluencedBy	isInfluencedBy	Response
Response	skos:narrower	include	Pathogen Distribution
Response	skos:narrower	include	Exposure Threats
Response	skos:narrower	include	Climate Projections
Response	skos:narrower	include	Human Response
