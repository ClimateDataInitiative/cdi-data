#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\AQ-load-term-map-gcis.sql";
$SqlStatement="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
	#Term	Relationship	Datasets	extURI
	($Term,$Relationship,$Dataset,$URI) = split(/\t/);
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term eq "") {
		$ThisTerm = $OldTerm
	} else {
		$ThisTerm = $OldTerm = $Term;
	}
	$Relationship = trim($Relationship);
	if ($Relationship eq "") {
		$Relationship= "N/A";
	}
	$Dataset = trim($Dataset);
	if ($Dataset eq "") {
		$Dataset= "N/A";
	}
	$Dataset =~ s/'/''/g;		#Escape single quotes
	$Dataset =~ s/\x92/''/g;  #Fix UTF8 quote
	$Dataset =~ s/\x97/\-/g;  #Fix UTF8 dash
	$Dataset =~ s/\x96/\-/g;  #Fix UTF8 hyphen

	$URI= trim($URI);
	if ($URI eq "") {
		$URI= "N/A";
	}
	$SqlStatement =<<EOM;
INSERT INTO term_map (term_id, relationship, gcid, description) VALUES ((SELECT s.id FROM term AS s WHERE s.term = '$ThisTerm' and s.lexicon_identifier='cdi'), '$Relationship', '$URI', '$Dataset');
EOM
	print OUT "$SqlStatement";
}
close OUT;
system "$ENV{'ED'} $F1"

#Term	Relationship	Datasets	extURI
__DATA__
Term	Relationship	Datasets	extURI
Health	isMentionedIn	The Impacts of Climate Change on Human Health in the United States: A Scientific Assessment	report/usgcrp-climate-human-health-assessment-2016
Air Quality	isMentionedIn	Chapter 3 : Air Quality Impacts	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts
Climate Indicators	isMentionedIn	How emissions, climate, and land use change will impact mid-century air quality over the United States: A focus on effects at National Parks (a92b6912)	article/10.5194/acp-15-2805-2015
Climate Indicators	isMentionedIn	chapter nca3 chapter 20 : Southwest (99baa64e)	report/nca3/chapter/southwest
Climate Indicators	isMentionedIn	Continued warming could transform Greater Yellowstone fire regimes by mid-21st century (b95e9226)	article/10.1073/pnas.1110199108
Climate Indicators	isMentionedIn	Climate Change 2013: The Physical Science Basis (f03117be)	report/ipcc-ar5-wg1
Climate Indicators	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Climate Indicators	isMentionedIn	Effect of climate change on air quality (afbd60ab)	article/10.1016/j.atmosenv.2008.09.051
Climate Indicators	isMentionedIn	Air quality and climate connections (b4038a28)	article/10.1080/10962247.2015.1040526
Climate Indicators	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Climate Indicators	isMentionedIn	Climate change and allergic disease	reference/c60ed28e-5ec3-4b9b-8b41-c6c29e4fda70
Climate Indicators	isMentionedIn	Impacts of climate change on aeroallergens: Past and future	reference/14835bc7-3df6-4fac-9e9a-2863c09e800a
Climate Indicators	isMentionedIn	Is the global rise of asthma an early impact of anthropogenic climate change?	reference/fa0649b9-2a09-43a3-a2ce-b57dbe0080a7
Climate Indicators	isMentionedIn	Climate change, air pollution and extreme events leading to increasing prevalence of allergic respiratory diseases	reference/aac0f087-3ed8-49a3-b1c9-07ce3fdf7f24
Climate Indicators	isMentionedIn	Projected carbon dioxide to increase grass pollen and allergen exposure despite higher ozone levels	reference/7dff169a-bb19-4f80-bdc9-9aae8d13a86f
Length of growing season	isMentionedIn	Climate change and allergic disease (c60ed28e)	article/10.1007/s11882-012-0314-z
Length of growing season	isMentionedIn	Impacts of climate change on aeroallergens: Past and future (14835bc7)	article/10.1111/j.1365-2222.2004.02061.x
Length of growing season	isMentionedIn	Is the global rise of asthma an early impact of anthropogenic climate change? (fa0649b9)	article/10.1289/ehp.7724
Length of growing season	isMentionedIn	Climate change, air pollution and extreme events leading to increasing prevalence of allergic respiratory diseases (aac0f087)	article/10.1186/2049-6958-8-12
Length of growing season	isMentionedIn	Projected carbon dioxide to increase grass pollen and allergen exposure despite higher ozone levels (7dff169a)	article/10.1371/journal.pone.0111712
Length of growing season	isMentionedIn	Recent warming by latitude associated with increased length of ragweed pollen season in central North America	reference/2d1ffd71-6c31-4d2e-9867-bdf330be45c1
Length of growing season	isMentionedIn	Ragweed Pollen Season Lengthens	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/ragweed-pollen-season-lengthens
Length of growing season	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Vertical mixing	isMentionedIn	Observed relationships of ozone air pollution with temperature and emissions	reference/552e0a6a-98c6-4d6c-b7ff-fdcc572fa914
Vertical mixing	isMentionedIn	Understanding the meteorological drivers of U.S. particulate matter concentrations in a changing climate	reference/2bd16a59-d347-4fb4-9ff7-701e0c32ab60
Vertical mixing	isMentionedIn	The effects of meteorology on ozone in urban areas and their use in assessing ozone trends	reference/1994b6dc-9753-44a1-a1b2-1d1566c39287
Vertical mixing	isMentionedIn	A comparison of CMAQ-based and observation-based statistical models relating ozone to meteorological parameters	reference/4ed6a6c7-6ce4-4cde-9624-44a165202b77
Temperature	isMentionedIn	chapter nca3 chapter 2 : Our Changing Climate (a6a312ba)	report/nca3/chapter/our-changing-climate
Temperature	isMentionedIn	Understanding the meteorological drivers of U.S. particulate matter concentrations in a changing climate	reference/2bd16a59-d347-4fb4-9ff7-701e0c32ab60
Temperature	isMentionedIn	The effects of meteorology on ozone in urban areas and their use in assessing ozone trends	reference/1994b6dc-9753-44a1-a1b2-1d1566c39287
Temperature	isMentionedIn	A comparison of CMAQ-based and observation-based statistical models relating ozone to meteorological parameters	reference/4ed6a6c7-6ce4-4cde-9624-44a165202b77
Temperature	isMentionedIn	Interaction of the onset of spring and elevated atmospheric CO2 on ragweed (Ambrosia artemisiifolia L.) pollen production	reference/1bc9d76c-14c8-4245-9ccb-1355cdc48d0b
Temperature	isMentionedIn	Increasing Amb a 1 content in common ragweed (Ambrosia artemisiifolia) pollen as a function of rising atmospheric CO2 concentration	reference/be4c7d95-2b71-45fb-b901-b68f5c1ad057
Temperature	isMentionedIn	Effects of urbanization on plant flowering phenology: A review	reference/37813511-d7af-4aa1-b926-70c152557fe5
Temperature	isMentionedIn	Elevated atmospheric CO2 concentration and temperature across an urban�rural transect	reference/8578fb8b-5c2e-420b-9479-5db418cbcc25
Temperature	isMentionedIn	Phenology in central Europe: Differences and trends of spring phenophases in urban and rural areas	reference/5486a67f-3f12-4126-86b6-cc202cc72472
Temperature	isMentionedIn	Effects of climate change on environmental factors in respiratory allergic diseases	reference/b1d1a01e-78e1-4b26-a8b4-513c43a7240c
Temperature	isMentionedIn	Climate change, migration, and allergic respiratory diseases: An update for the allergist	reference/12159d43-9762-4788-9a10-8e0ad5ab4d9a
Temperature	isMentionedIn	Ecology of hantavirus in a changing world	reference/428eb42d-1733-4ba4-a904-84fbb32be7fc
Temperature	isMentionedIn	Climate change and allergic disease	reference/036ba27d-8341-4f6d-ad66-1288e53dee65
Temperature	isMentionedIn	How emissions, climate, and land use change will impact mid-century air quality over the United States: A focus on effects at National Parks (a92b6912)	article/10.5194/acp-15-2805-2015
Temperature	isMentionedIn	chapter nca3 chapter 20 : Southwest (99baa64e)	report/nca3/chapter/southwest
Temperature	isMentionedIn	Continued warming could transform Greater Yellowstone fire regimes by mid-21st century (b95e9226)	article/10.1073/pnas.1110199108
Temperature	isMentionedIn	Climate Change 2013: The Physical Science Basis (f03117be)	report/ipcc-ar5-wg1
Temperature	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Temperature	isMentionedIn	Observed relationships of ozone air pollution with temperature and emissions (552e0a6a)	article/10.1029/2009gl037308
Temperature	isMentionedIn	The effects of meteorology on ozone in urban areas and their use in assessing ozone trends (1994b6dc)	article/10.1016/j.atmosenv.2007.04.061
Temperature	isMentionedIn	Climate change and allergic disease (c60ed28e)	article/10.1007/s11882-012-0314-z
Temperature	isMentionedIn	Impacts of climate change on aeroallergens: Past and future (14835bc7)	article/10.1111/j.1365-2222.2004.02061.x
Temperature	isMentionedIn	Is the global rise of asthma an early impact of anthropogenic climate change? (fa0649b9)	article/10.1289/ehp.7724
Temperature	isMentionedIn	Climate change, air pollution and extreme events leading to increasing prevalence of allergic respiratory diseases (aac0f087)	article/10.1186/2049-6958-8-12
Temperature	isMentionedIn	Projected carbon dioxide to increase grass pollen and allergen exposure despite higher ozone levels (7dff169a)	article/10.1371/journal.pone.0111712
Temperature	isMentionedIn	chapter nca3 chapter 2 : Our Changing Climate (a6a312ba)	report/nca3/chapter/our-changing-climate
Temperature	isMentionedIn	Effect of climate change on air quality (afbd60ab)	article/10.1016/j.atmosenv.2008.09.051
Temperature	isMentionedIn	Air quality and climate connections (b4038a28)	article/10.1080/10962247.2015.1040526
Temperature	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Temperature	isMentionedIn	The representative concentration pathways: an overview (44124472)	article/10.1007/s10584-011-0148-z
Temperature	isMentionedIn	Projected Change in Temperature, Ozone, and Ozone-Related Premature Deaths in 2030	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/projected-change-in-temperature-ozone-and-ozone-related-premature-deaths-in-2030
Wind	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Wind	isMentionedIn	Observed relationships of ozone air pollution with temperature and emissions	reference/552e0a6a-98c6-4d6c-b7ff-fdcc572fa914
Wind	isMentionedIn	Understanding the meteorological drivers of U.S. particulate matter concentrations in a changing climate	reference/2bd16a59-d347-4fb4-9ff7-701e0c32ab60
Wind	isMentionedIn	The effects of meteorology on ozone in urban areas and their use in assessing ozone trends	reference/1994b6dc-9753-44a1-a1b2-1d1566c39287
Wind	isMentionedIn	A comparison of CMAQ-based and observation-based statistical models relating ozone to meteorological parameters	reference/4ed6a6c7-6ce4-4cde-9624-44a165202b77
Wind	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment	reference/dd5b893d-4462-4bb3-9205-67b532919566
Wind	isMentionedIn	Impact of the 2002 Canadian forest fires on particulate matter air quality in Baltimore City	reference/3bfcb39e-f3ee-4d20-8f53-77c8487599b4
Wind	isMentionedIn	Climate Change 2013: The Physical Science Basis. Contribution of Working Group I to the Fifth Assessment Report of the Intergovernmental Panel on Climate Change	reference/f03117be-ccfe-4f88-b70a-ffd4351b8190
Cloud Cover	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Cloud Cover	isMentionedIn	Observed relationships of ozone air pollution with temperature and emissions	reference/552e0a6a-98c6-4d6c-b7ff-fdcc572fa914
Cloud Cover	isMentionedIn	Understanding the meteorological drivers of U.S. particulate matter concentrations in a changing climate	reference/2bd16a59-d347-4fb4-9ff7-701e0c32ab60
Cloud Cover	isMentionedIn	The effects of meteorology on ozone in urban areas and their use in assessing ozone trends	reference/1994b6dc-9753-44a1-a1b2-1d1566c39287
Cloud Cover	isMentionedIn	A comparison of CMAQ-based and observation-based statistical models relating ozone to meteorological parameters	reference/4ed6a6c7-6ce4-4cde-9624-44a165202b77
Latitudinal Effects	isMentionedIn	Recent warming by latitude associated with increased length of ragweed pollen season in central North America	reference/2d1ffd71-6c31-4d2e-9867-bdf330be45c1
Precipitation	isMentionedIn	Climate change and allergic disease (c60ed28e)	article/10.1007/s11882-012-0314-z
Precipitation	isMentionedIn	Impacts of climate change on aeroallergens: Past and future (14835bc7)	article/10.1111/j.1365-2222.2004.02061.x
Precipitation	isMentionedIn	Is the global rise of asthma an early impact of anthropogenic climate change? (fa0649b9)	article/10.1289/ehp.7724
Precipitation	isMentionedIn	Climate change, air pollution and extreme events leading to increasing prevalence of allergic respiratory diseases (aac0f087)	article/10.1186/2049-6958-8-12
Precipitation	isMentionedIn	Projected carbon dioxide to increase grass pollen and allergen exposure despite higher ozone levels (7dff169a)	article/10.1371/journal.pone.0111712
Precipitation	isMentionedIn	Projections of the effects of climate change on allergic asthma: The contribution of aerobiology (025515fc)	article/10.1111/j.1398-9995.2010.02423.x
Precipitation	isMentionedIn	Air quality and climate connections	reference/b4038a28-b14b-4ae8-b783-0de19e3cffdd
Precipitation	isMentionedIn	Impacts of climate change on regional and urban air quality in the eastern United States: Role of meteorology	reference/18111e41-6df6-45d5-9ff0-8f6814de8bb4
Precipitation	isMentionedIn	Global air quality and climate	reference/914c7cdc-87d8-4b27-a7f0-dd1a2df15bb0
Precipitation	isMentionedIn	Thunderstorm-asthma and pollen allergy (713cd919)	article/10.1111/j.1398-9995.2006.01271.x
Precipitation	isMentionedIn	chapter nca3 chapter 2 : Our Changing Climate (a6a312ba)	report/nca3/chapter/our-changing-climate
Precipitation	isMentionedIn	How emissions, climate, and land use change will impact mid-century air quality over the United States: A focus on effects at National Parks (a92b6912)	article/10.5194/acp-15-2805-2015
Precipitation	isMentionedIn	chapter nca3 chapter 20 : Southwest (99baa64e)	report/nca3/chapter/southwest
Precipitation	isMentionedIn	Continued warming could transform Greater Yellowstone fire regimes by mid-21st century (b95e9226)	article/10.1073/pnas.1110199108
Precipitation	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Precipitation	isMentionedIn	Climate Change 2013: The Physical Science Basis. Contribution of Working Group I to the Fifth Assessment Report of the Intergovernmental Panel on Climate Change	reference/f03117be-ccfe-4f88-b70a-ffd4351b8190
Precipitation	isMentionedIn	Observed relationships of ozone air pollution with temperature and emissions	reference/552e0a6a-98c6-4d6c-b7ff-fdcc572fa914
Precipitation	isMentionedIn	Understanding the meteorological drivers of U.S. particulate matter concentrations in a changing climate	reference/2bd16a59-d347-4fb4-9ff7-701e0c32ab60
Precipitation	isMentionedIn	The effects of meteorology on ozone in urban areas and their use in assessing ozone trends	reference/1994b6dc-9753-44a1-a1b2-1d1566c39287
Precipitation	isMentionedIn	A comparison of CMAQ-based and observation-based statistical models relating ozone to meteorological parameters	reference/4ed6a6c7-6ce4-4cde-9624-44a165202b77
Humidity	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Humidity	isMentionedIn	Climate Change 2013: The Physical Science Basis. Contribution of Working Group I to the Fifth Assessment Report of the Intergovernmental Panel on Climate Change	reference/f03117be-ccfe-4f88-b70a-ffd4351b8190
Humidity	isMentionedIn	Observed relationships of ozone air pollution with temperature and emissions	reference/552e0a6a-98c6-4d6c-b7ff-fdcc572fa914
Humidity	isMentionedIn	Understanding the meteorological drivers of U.S. particulate matter concentrations in a changing climate	reference/2bd16a59-d347-4fb4-9ff7-701e0c32ab60
Humidity	isMentionedIn	The effects of meteorology on ozone in urban areas and their use in assessing ozone trends	reference/1994b6dc-9753-44a1-a1b2-1d1566c39287
Humidity	isMentionedIn	A comparison of CMAQ-based and observation-based statistical models relating ozone to meteorological parameters	reference/4ed6a6c7-6ce4-4cde-9624-44a165202b77
Humidity	isMentionedIn	Air quality and climate connections	reference/b4038a28-b14b-4ae8-b783-0de19e3cffdd
Humidity	isMentionedIn	Impacts of climate change on regional and urban air quality in the eastern United States: Role of meteorology	reference/18111e41-6df6-45d5-9ff0-8f6814de8bb4
Humidity	isMentionedIn	Global air quality and climate	reference/914c7cdc-87d8-4b27-a7f0-dd1a2df15bb0
Humidity	isMentionedIn	Unplanned airflows & moisture problems	reference/e846ef84-3a45-4a54-93c1-07b42fa3a9a2
Extreme Weather	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Extreme Weather	isMentionedIn	Climate changes, environment and infection: Facts, scenarios and growing awareness from the public health community within Europe	reference/9141fd5f-b949-4652-86b0-b31ba25d31c2
Wildfires	isMentionedIn	Three Measures of Forest Fire Smoke Exposure and Their Associations with Respiratory and Cardiovascular Health Outcomes in a Population-Based Cohort (250b4ec3)	article/10.1289/ehp.1002288
Wildfires	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment	reference/dd5b893d-4462-4bb3-9205-67b532919566
Wildfires	isMentionedIn	Impact of the 2002 Canadian forest fires on particulate matter air quality in Baltimore City	reference/3bfcb39e-f3ee-4d20-8f53-77c8487599b4
Wildfires	isMentionedIn	The climate-wildfire-air quality system: Interactions and feedbacks across spatial and temporal scales	reference/8160274b-cfe7-4d23-b068-a34da55a8052
Wildfires	isMentionedIn	The relationship of respiratory and cardiovascular hospital admissions to the southern California wildfires of 2003	reference/1a72beb2-f4a0-4db9-bac8-eac55cbf676d
Wildfires	isMentionedIn	Health effects of the 2003 southern California wildfires on children	reference/5d3a9428-c81f-4c38-bda4-0b475b07d947
Wildfires	isMentionedIn	Sources of carbonaceous aerosols over the United States and implications for natural visibility	reference/a1a1caa5-a3b6-4dd1-aef3-396aebc8cfed
Wildfires	isMentionedIn	A systematic review of the physical health impacts from non-occupational exposure to wildfire smoke	reference/0e12319b-ddc2-4ead-bb54-3a00e5d8c776
Wildfires	isMentionedIn	Warming and earlier spring increase western U.S. forest wildfire activity	reference/12261a2b-98d5-4a12-ae26-241d04356b5b
Wildfires	isMentionedIn	Fire in the air: Biomass burning impacts in a changing climate	reference/f4daa36c-4b3f-449a-8d03-94cdd39fe1eb
Wildfires	isMentionedIn	Impacts of climate change from 2000 to 2050 on wildfire activity and carbonaceous aerosol concentrations in the western United States	reference/940ef8f4-6b52-40f8-a289-02bb7f07e350
Wildfires	isMentionedIn	Cardio-respiratory outcomes associated with exposure to wildfire smoke are modified by measures of community health (21efa9a6)	article/10.1186/1476-069X-11-71
Wildfires	isMentionedIn	How emissions, climate, and land use change will impact mid-century air quality over the United States: A focus on effects at National Parks (a92b6912)	article/10.5194/acp-15-2805-2015
Wildfires	isMentionedIn	chapter nca3 chapter 20 : Southwest (99baa64e)	report/nca3/chapter/southwest
Wildfires	isMentionedIn	Continued warming could transform Greater Yellowstone fire regimes by mid-21st century (b95e9226)	article/10.1073/pnas.1110199108
Exposures	isMentionedIn	Aeroallergens, Allergic Disease, and Climate Change: Impacts and Adaptation (b9370347)	article/10.1007/s10393-009-0261-x
Exposures	isMentionedIn	Effect modification of ozone-related mortality risks by temperature in 97 US cities	reference/2665e2d1-a6e6-48ea-93ec-d8f0b1c33e40
Exposures	isMentionedIn	Effect modification by community characteristics on the short-term effects of ozone exposure and mortality in 98 US communities	reference/495289be-0bc8-4c43-8e6d-f2fc7d26e361
Exposures	isMentionedIn	Particulate matter�induced health effects: Who is susceptible?	reference/fd90ea4e-e20c-488c-9e6d-6d16933940c5
Exposures	isMentionedIn	Review of some effects of climate change on indoor environmental quality and health and associated no-regrets mitigation measures	reference/cc7159e1-bdd7-450e-b4c6-a943fc153351
Exposures	isMentionedIn	Ozone's impact on public health: Contributions from indoor exposures to ozone and products of ozone-initiated chemistry	reference/5dbd8d4e-540b-4551-83e7-202589965032
Exposures	isMentionedIn	Who is more affected by ozone pollution? A systematic review and meta-analysis	reference/67a241cc-98d9-4478-a11e-f94d1dc3144b
Exposures	isMentionedIn	Chronic exposure to ambient ozone and asthma hospital admissions among children	reference/1dd1dce1-0102-4440-9451-e630b6d49128
Exposures	isMentionedIn	Epidemiology and ecology of opportunistic premise plumbing pathogens: Legionella pneumophila, Mycobacterium avium, and Pseudomonas aeruginosa	reference/40677a7f-197f-4473-a351-ea62a7249dfb
Exposures	isMentionedIn	Epidemiology of Hantavirus infections in humans: A comprehensive, global overview	reference/f895c7bb-2487-4b77-96e9-0fa249f36002
Exposures	isMentionedIn	Emergence and persistence of hantaviruses	reference/d774237d-5d86-4dde-91ca-8b51dabf6106
Exposures	isMentionedIn	Factors driving hantavirus emergence in Europe	reference/c0076f84-2a19-435c-a326-efb6f0aa09c6
Exposures	isMentionedIn	Moving environmental justice indoors: Understanding structural influences on residential exposure patterns in low-income communities	reference/1f6857ab-f1ab-4902-962b-253333e82750
Exposures	isMentionedIn	Socioeconomic predictors of high allergen levels in homes in the greater Boston area	reference/fc1d9b82-45a5-4da7-ba95-e855d793b178
Exposures	isMentionedIn	Pediatric asthma: A different disease	reference/f10993f6-3898-4269-b1e4-803d1f9340af
Exposures	isMentionedIn	Effects of ambient pollen concentrations on frequency and severity of asthma symptoms among asthmatic children	reference/727c62e3-9a02-41cb-8c91-31ec4e1f1085
Exposures	isMentionedIn	Climate change and children	reference/9b2bb133-071f-479a-a32d-71e9f40f5a5b
Exposures	isMentionedIn	The impact of climate change and aeroallergens on children's health	reference/0b3b0345-837c-4be4-9e68-6dd8d6ea5e51
Exposures	isMentionedIn	Climate change and allergic disease (c60ed28e)	article/10.1007/s11882-012-0314-z
Exposures	isMentionedIn	Anthropogenic climate change and allergic diseases (f89543d6)	article/10.3390/atmos3010200
Exposures	isMentionedIn	Relationship between climate, pollen concentrations of Ambrosia and medical consultations for allergic rhinitis in Montreal, 1994�2002 (7eaad122)	article/10.1016/j.scitotenv.2006.05.022
Exposures	isMentionedIn	webpage Allergy Statistics (49a88ae9)	webpage/3bd35c21-e4de-426d-9542-5e56f95de321
Exposures	isMentionedIn	Air pollution and allergens (d9f760b1)	article/air-pollution-allergens
Exposures	isMentionedIn	Projections of the effects of climate change on allergic asthma: The contribution of aerobiology (025515fc)	article/10.1111/j.1398-9995.2010.02423.x
Exposures	isMentionedIn	Climate change and allergic disease (036ba27d)	article/10.1016/j.jaci.2008.06.032
Exposures	isMentionedIn	The role of outdoor air pollution and climatic changes on the rising trends in respiratory allergy (a5b5448f)	article/10.1053/rmed.2001.1112
Exposures	isMentionedIn	Environmental urban factors (air pollution and allergens) and the rising trends in allergic respiratory diseases (6d18401d)	article/10.1034/j.1398-9995.57.s72.5.x
Exposures	isMentionedIn	Environmental risk factors and allergic bronchial asthma (a52668d8)	article/10.1111/j.1365-2222.2005.02328.x
Exposures	isMentionedIn	Role of outdoor aeroallergens in asthma exacerbations: Epidemiological evidence (203adb04)	article/10.1136/thx.2003.019133
Exposures	isMentionedIn	Analysis of short-term influences of ambient aeroallergens on pediatric asthma hospital visits (98a7b7be)	article/10.1016/j.scitotenv.2006.06.019
Exposures	isMentionedIn	Induction of asthma and the environment: What we know and need to know (9d0046a1)	article/10.1289/ehp.8376
Exposures	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Contaminants	isMentionedIn	Projections of the effects of climate change on allergic asthma: The contribution of aerobiology (025515fc)	article/10.1111/j.1398-9995.2010.02423.x
Contaminants	isMentionedIn	Review of some effects of climate change on indoor environmental quality and health and associated no-regrets mitigation measures	reference/cc7159e1-bdd7-450e-b4c6-a943fc153351
Contaminants	isMentionedIn	Healthier tribal housing: Combining the best of old and new	reference/fe12c254-1db1-4c46-8268-e966fc185ac4
Contaminants	isMentionedIn	Anthropogenic climate change and allergic diseases (f89543d6)	article/10.3390/atmos3010200
Contaminants	isMentionedIn	Air pollution and allergens (d9f760b1)	article/air-pollution-allergens
Contaminants	isMentionedIn	Climate change and allergic disease (036ba27d)	article/10.1016/j.jaci.2008.06.032
Contaminants	isMentionedIn	The role of outdoor air pollution and climatic changes on the rising trends in respiratory allergy (a5b5448f)	article/10.1053/rmed.2001.1112
Contaminants	isMentionedIn	Environmental urban factors (air pollution and allergens) and the rising trends in allergic respiratory diseases (6d18401d)	article/10.1034/j.1398-9995.57.s72.5.x
Contaminants	isMentionedIn	Environmental risk factors and allergic bronchial asthma (a52668d8)	article/10.1111/j.1365-2222.2005.02328.x
Contaminants	isMentionedIn	Role of outdoor aeroallergens in asthma exacerbations: Epidemiological evidence (203adb04)	article/10.1136/thx.2003.019133
Contaminants	isMentionedIn	Analysis of short-term influences of ambient aeroallergens on pediatric asthma hospital visits (98a7b7be)	article/10.1016/j.scitotenv.2006.06.019
Gases and Particulates	isMentionedIn	Climate Change 2013: The Physical Science Basis (f03117be)	report/ipcc-ar5-wg1
Gases and Particulates	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Pollen	isMentionedIn	Climate change and allergic disease (c60ed28e)	article/10.1007/s11882-012-0314-z
Pollen	isMentionedIn	Climate change, air quality, and human health	reference/2d58d3bb-62b3-45f2-b4c9-10d22b556f9c
Pollen	isMentionedIn	Effects of urbanization on plant flowering phenology: A review	reference/37813511-d7af-4aa1-b926-70c152557fe5
Pollen	isMentionedIn	Elevated atmospheric CO2 concentration and temperature across an urban�rural transect	reference/8578fb8b-5c2e-420b-9479-5db418cbcc25
Pollen	isMentionedIn	Phenology in central Europe: Differences and trends of spring phenophases in urban and rural areas	reference/5486a67f-3f12-4126-86b6-cc202cc72472
Pollen	isMentionedIn	Elevated CO2 and tree fecundity: The role of tree size, interannual variability, and population heterogeneity	reference/69154c62-5fa7-48ca-9a7c-7a8bf2f0d7e4
Pollen	isMentionedIn	Development of a regional-scale pollen emission and transport modeling framework for investigating the impact of climate change on allergic airway disease	reference/6144a649-5c20-4070-ac57-0c87261572da
Pollen	isMentionedIn	Impacts of climate change on aeroallergens: Past and future (14835bc7)	article/10.1111/j.1365-2222.2004.02061.x
Pollen	isMentionedIn	Is the global rise of asthma an early impact of anthropogenic climate change? (fa0649b9)	article/10.1289/ehp.7724
Pollen	isMentionedIn	Climate change, air pollution and extreme events leading to increasing prevalence of allergic respiratory diseases (aac0f087)	article/10.1186/2049-6958-8-12
Pollen	isMentionedIn	Projected carbon dioxide to increase grass pollen and allergen exposure despite higher ozone levels (7dff169a)	article/10.1371/journal.pone.0111712
Pollen	isMentionedIn	Interaction of the onset of spring and elevated atmospheric CO2 on ragweed (Ambrosia artemisiifolia L.) pollen production	reference/1bc9d76c-14c8-4245-9ccb-1355cdc48d0b
Pollen	isMentionedIn	Increasing Amb a 1 content in common ragweed (Ambrosia artemisiifolia) pollen as a function of rising atmospheric CO2 concentration	reference/be4c7d95-2b71-45fb-b901-b68f5c1ad057
Pollen	isMentionedIn	Effects of climate change on environmental factors in respiratory allergic diseases (b1d1a01e)	article/10.1111/j.1365-2222.2008.03033.x
Pollen	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Pollen	isMentionedIn	Ragweed Pollen Season Lengthens	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/ragweed-pollen-season-lengthens
Pollen	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Sulfates	isMentionedIn	Global air quality and climate	reference/914c7cdc-87d8-4b27-a7f0-dd1a2df15bb0
Sulfur Dioxide	isMentionedIn	Technical Support Document (TSD): Preparation of Emissions Inventories for the Version 6.2, 2011 Emissions Modeling Platform	reference/5958ffb9-83be-45ec-8515-0949949ceceb
Sulfur Dioxide	isMentionedIn	Cross-State Air Pollution Rule (CSAPR)	reference/311fddd1-8068-4f09-a74e-66d3b72bd304
Sulfur Dioxide	isMentionedIn	Tier 2 Vehicle and Gasoline Sulfur Program	reference/7392ba34-1f61-448b-9451-11ab04a0523b
Sulfur Dioxide	isMentionedIn	Regulatory Impact Analysis - Control of Air Pollution from New Motor Vehicles: Tier 2 Motor Vehicle Emissions Standards and Gasoline Sulfur Control Requirements	reference/8e1110ca-e1dd-42c6-b686-1aa1f964a659
Sulfur Dioxide	isMentionedIn	Air pollution and allergens	reference/d9f760b1-0caa-450c-a807-e65c2097c0fb
Sulfur Dioxide	isMentionedIn	The role of outdoor air pollution and climatic changes on the rising trends in respiratory allergy	reference/a5b5448f-6f88-4e74-a3a9-2f34aab42ecb
Sulfur Dioxide	isMentionedIn	Climate change and allergic disease	reference/036ba27d-8341-4f6d-ad66-1288e53dee65
Sulfur Dioxide	isMentionedIn	Projections of the effects of climate change on allergic asthma: The contribution of aerobiology	reference/025515fc-f83a-47ff-b547-92ade9513c15
Sulfur Dioxide	isMentionedIn	Environmental urban factors (air pollution and allergens) and the rising trends in allergic respiratory diseases	reference/6d18401d-b332-4805-8b3b-07e4f6e01d13
Sulfur Dioxide	isMentionedIn	Environmental risk factors and allergic bronchial asthma	reference/a52668d8-0468-4b90-9b62-c32a86cae478
Sulfur Dioxide	isMentionedIn	Role of outdoor aeroallergens in asthma exacerbations: Epidemiological evidence	reference/203adb04-2d0d-4b2e-ac47-bbaeb3befedd
Sulfur Dioxide	isMentionedIn	Analysis of short-term influences of ambient aeroallergens on pediatric asthma hospital visits	reference/98a7b7be-a84e-4adf-bbe0-72f34256c87f
Sulfur Dioxide	isMentionedIn	Anthropogenic climate change and allergic diseases	reference/f89543d6-09bf-436c-8f7e-c0f908473457
Ammonium	isMentionedIn	Integrated Science Assessment for Particulate Matter	reference/f7ffc8dd-70ec-4779-817a-b2985c0779e7
Sea Salt	isMentionedIn	Integrated Science Assessment for Particulate Matter	reference/f7ffc8dd-70ec-4779-817a-b2985c0779e7
Nitrates	isMentionedIn	Integrated Science Assessment for Particulate Matter	reference/f7ffc8dd-70ec-4779-817a-b2985c0779e7
Nitrogen Oxides	isMentionedIn	Near-term climate change: Projections and predictability	reference/2f638e6d-6ba0-4426-a196-fbc3ef435d40
Nitrogen Oxides	isMentionedIn	Technical Support Document (TSD): Preparation of Emissions Inventories for the Version 6.2, 2011 Emissions Modeling Platform	reference/5958ffb9-83be-45ec-8515-0949949ceceb
Particulate Matter	isMentionedIn	Three Measures of Forest Fire Smoke Exposure and Their Associations with Respiratory and Cardiovascular Health Outcomes in a Population-Based Cohort (250b4ec3)	article/10.1289/ehp.1002288
Particulate Matter	isMentionedIn	Understanding the meteorological drivers of U.S. particulate matter concentrations in a changing climate	reference/2bd16a59-d347-4fb4-9ff7-701e0c32ab60
Particulate Matter	isMentionedIn	Global air quality and climate	reference/914c7cdc-87d8-4b27-a7f0-dd1a2df15bb0
Particulate Matter	isMentionedIn	Integrated Science Assessment for Particulate Matter	reference/f7ffc8dd-70ec-4779-817a-b2985c0779e7
Particulate Matter	isMentionedIn	The relationship of respiratory and cardiovascular hospital admissions to the southern California wildfires of 2003	reference/1a72beb2-f4a0-4db9-bac8-eac55cbf676d
Particulate Matter	isMentionedIn	Health effects of the 2003 southern California wildfires on children	reference/5d3a9428-c81f-4c38-bda4-0b475b07d947
Particulate Matter	isMentionedIn	Sources of carbonaceous aerosols over the United States and implications for natural visibility	reference/a1a1caa5-a3b6-4dd1-aef3-396aebc8cfed
Particulate Matter	isMentionedIn	Cardio-respiratory outcomes associated with exposure to wildfire smoke are modified by measures of community health (21efa9a6)	article/10.1186/1476-069X-11-71
Particulate Matter	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Particulate Matter	isMentionedIn	Air pollution and allergens	reference/d9f760b1-0caa-450c-a807-e65c2097c0fb
Particulate Matter	isMentionedIn	The role of outdoor air pollution and climatic changes on the rising trends in respiratory allergy	reference/a5b5448f-6f88-4e74-a3a9-2f34aab42ecb
Particulate Matter	isMentionedIn	Climate change and allergic disease	reference/036ba27d-8341-4f6d-ad66-1288e53dee65
Particulate Matter	isMentionedIn	Projections of the effects of climate change on allergic asthma: The contribution of aerobiology	reference/025515fc-f83a-47ff-b547-92ade9513c15
Particulate Matter	isMentionedIn	Environmental urban factors (air pollution and allergens) and the rising trends in allergic respiratory diseases	reference/6d18401d-b332-4805-8b3b-07e4f6e01d13
Particulate Matter	isMentionedIn	Environmental risk factors and allergic bronchial asthma	reference/a52668d8-0468-4b90-9b62-c32a86cae478
Particulate Matter	isMentionedIn	Role of outdoor aeroallergens in asthma exacerbations: Epidemiological evidence	reference/203adb04-2d0d-4b2e-ac47-bbaeb3befedd
Particulate Matter	isMentionedIn	Analysis of short-term influences of ambient aeroallergens on pediatric asthma hospital visits	reference/98a7b7be-a84e-4adf-bbe0-72f34256c87f
Particulate Matter	isMentionedIn	Anthropogenic climate change and allergic diseases	reference/f89543d6-09bf-436c-8f7e-c0f908473457
Ozone	isMentionedIn	Integrated Science Assessment for Ozone and Related Photochemical Oxidants (e00fb4e2)	report/epa-600-r-10-076f
Ozone	isMentionedIn	Understanding the meteorological drivers of U.S. particulate matter concentrations in a changing climate	reference/2bd16a59-d347-4fb4-9ff7-701e0c32ab60
Ozone	isMentionedIn	Sensitivity of US air quality to mid-latitude cyclone frequency and implications of 1980�2006 climate change	reference/d85008eb-70ba-4b95-bdd1-0ec927248351
Ozone	isMentionedIn	A preliminary synthesis of modeled climate change impacts on U.S. regional ozone concentrations	reference/a19a16db-8155-45a3-83f0-357064ec254a
Ozone	isMentionedIn	Global air quality and climate	reference/914c7cdc-87d8-4b27-a7f0-dd1a2df15bb0
Ozone	isMentionedIn	Intercontinental impacts of ozone pollution on human mortality	reference/159d09fd-a7de-470d-9e15-375718243164
Ozone	isMentionedIn	Estimating the national public health burden associated with exposure to ambient PM2.5 and ozone	reference/be14c1d4-c494-4844-b147-951f1c44a497
Ozone	isMentionedIn	Projections of mid-century summer air-quality for North America: Effects of changes in climate and precursor emissions	reference/f719785d-3c26-46cc-bf3a-defb6e208c10
Ozone	isMentionedIn	Impacts of future climate and emission changes on U.S. air quality	reference/52e393f5-5b43-494d-bf74-90e51182239a
Ozone	isMentionedIn	Regulatory Impact Analysis of the Proposed Revisions to the National Ambient Air Quality Standards for Ground-Level Ozone	reference/489c7b61-d874-4378-8952-180bb3c990d5
Ozone	isMentionedIn	Effects of 2000�2050 global change on ozone air quality in the United States	reference/89c49b97-dc6e-489c-bd95-a5a0a4bb0ee7
Ozone	isMentionedIn	A comparison of CMAQ-based and observation-based statistical models relating ozone to meteorological parameters	reference/4ed6a6c7-6ce4-4cde-9624-44a165202b77
Ozone	isMentionedIn	Relationship between boundary layer heights and growth rates with ground-level ozone in Houston, Texas	reference/713831bd-1a07-4549-a4cb-1560df48103c
Ozone	isMentionedIn	Sources contributing to background surface ozone in the US Intermountain West	reference/93f0e8b4-f053-47da-b714-e879e640fb6f
Ozone	isMentionedIn	Near-term climate change: Projections and predictability	reference/2f638e6d-6ba0-4426-a196-fbc3ef435d40
Ozone	isMentionedIn	The climate-wildfire-air quality system: Interactions and feedbacks across spatial and temporal scales	reference/8160274b-cfe7-4d23-b068-a34da55a8052
Ozone	isMentionedIn	Projecting policy-relevant metrics for high summertime ozone pollution events over the eastern United States due to climate and emission changes during the 21st century	reference/3830ef15-7b28-466d-8159-8b0b9d7de522
Ozone	isMentionedIn	Integrated Science Assessment for Ozone and Related Photochemical Oxidants	reference/e00fb4e2-6406-40be-90f8-071dfc43cca3
Ozone	isMentionedIn	Long-term ozone exposure and mortality	reference/18a03092-28de-406e-b060-8f5b44614a9e
Ozone	isMentionedIn	Global health and economic impacts of future ozone pollution	reference/8e802a4f-d4f1-4f72-a0ae-aefbbece477e
Ozone	isMentionedIn	Potential impact of climate change on air pollution-related human health effects	reference/c275ae44-75e4-4974-81ea-fe7119474ffb
Ozone	isMentionedIn	U.S. air quality and health benefits from avoided climate change under greenhouse gas mitigation	reference/81f96860-7931-48b6-9d57-32682728636f
Ozone	isMentionedIn	Climate change, ambient ozone, and health in 50 US cities	reference/d6e399c7-1efe-4f91-927e-f957965e3aaa
Ozone	isMentionedIn	On the causal link between carbon dioxide and air pollution mortality	reference/d3df6d52-0441-47cc-a939-6d09f57ea48d
Ozone	isMentionedIn	Effect modification of ozone-related mortality risks by temperature in 97 US cities	reference/2665e2d1-a6e6-48ea-93ec-d8f0b1c33e40
Ozone	isMentionedIn	Observed relationships of ozone air pollution with temperature and emissions (552e0a6a)	article/10.1029/2009gl037308
Ozone	isMentionedIn	The effects of meteorology on ozone in urban areas and their use in assessing ozone trends (1994b6dc)	article/10.1016/j.atmosenv.2007.04.061
Ozone	isMentionedIn	Effect of climate change on air quality (afbd60ab)	article/10.1016/j.atmosenv.2008.09.051
Ozone	isMentionedIn	Air quality and climate connections (b4038a28)	article/10.1080/10962247.2015.1040526
Ozone	isMentionedIn	The Geographic Distribution and Economic Value of Climate Change-Related Ozone Health Impacts in the United States in 2030 (54a66159)	article/10.1080/10962247.2014.996270
Ozone	isMentionedIn	Variation in Estimated Ozone-Related Health Impacts of Climate Change due to Modeling Choices and Assumptions (fe6d1c69)	article/10.1289/ehp.1104271
Ozone	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Ozone	isMentionedIn	The representative concentration pathways: an overview (44124472)	article/10.1007/s10584-011-0148-z
Ozone	isMentionedIn	Ozone and short-term mortality in 95 US urban communities, 1987-2000 (a02f25a1)	article/10.1001/jama.292.19.2372
Ozone	isMentionedIn	Projected Change in Temperature, Ozone, and Ozone-Related Premature Deaths in 2030	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/projected-change-in-temperature-ozone-and-ozone-related-premature-deaths-in-2030
Ozone	isMentionedIn	Projected Change in Ozone-related Premature Deaths	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/projected-change-in-ozone-related-premature-deaths
Ozone	isMentionedIn	Air pollution and allergens	reference/d9f760b1-0caa-450c-a807-e65c2097c0fb
Ozone	isMentionedIn	The role of outdoor air pollution and climatic changes on the rising trends in respiratory allergy	reference/a5b5448f-6f88-4e74-a3a9-2f34aab42ecb
Ozone	isMentionedIn	Climate change and allergic disease	reference/036ba27d-8341-4f6d-ad66-1288e53dee65
Ozone	isMentionedIn	Projections of the effects of climate change on allergic asthma: The contribution of aerobiology	reference/025515fc-f83a-47ff-b547-92ade9513c15
Ozone	isMentionedIn	Environmental urban factors (air pollution and allergens) and the rising trends in allergic respiratory diseases	reference/6d18401d-b332-4805-8b3b-07e4f6e01d13
Ozone	isMentionedIn	Environmental risk factors and allergic bronchial asthma	reference/a52668d8-0468-4b90-9b62-c32a86cae478
Ozone	isMentionedIn	Role of outdoor aeroallergens in asthma exacerbations: Epidemiological evidence	reference/203adb04-2d0d-4b2e-ac47-bbaeb3befedd
Ozone	isMentionedIn	Analysis of short-term influences of ambient aeroallergens on pediatric asthma hospital visits	reference/98a7b7be-a84e-4adf-bbe0-72f34256c87f
Ozone	isMentionedIn	Anthropogenic climate change and allergic diseases	reference/f89543d6-09bf-436c-8f7e-c0f908473457
Allergic Proteins	isMentionedIn	Climate change, air quality, and human health	reference/2d58d3bb-62b3-45f2-b4c9-10d22b556f9c
Dust Mites	isMentionedIn	Climate change, air quality, and human health	reference/2d58d3bb-62b3-45f2-b4c9-10d22b556f9c
Dust Mites	isMentionedIn	Climate Change, the Indoor Environment, and Health	reference/c2e46e42-7cb9-4bb0-91df-c676943cd62a
Dust Mites	isMentionedIn	Damp Indoor Spaces and Health	reference/3ffeefed-eb88-4fb5-8fce-a463134fb5ba
Dust Mites	isMentionedIn	Review of health hazards and prevention measures for response and recovery workers and volunteers after natural disasters, flooding, and water damage: Mold and dampness	reference/a23ae616-9cef-4381-b8e7-1148eb73501b
Dust Mites	isMentionedIn	Moving environmental justice indoors: Understanding structural influences on residential exposure patterns in low-income communities	reference/1f6857ab-f1ab-4902-962b-253333e82750
Dust Mites	isMentionedIn	Socioeconomic predictors of high allergen levels in homes in the greater Boston area	reference/fc1d9b82-45a5-4da7-ba95-e855d793b178
Dust	isMentionedIn	Integrated Science Assessment for Particulate Matter	reference/f7ffc8dd-70ec-4779-817a-b2985c0779e7
Dust	isMentionedIn	Global air quality and climate	reference/914c7cdc-87d8-4b27-a7f0-dd1a2df15bb0
Dust	isMentionedIn	Understanding the meteorological drivers of U.S. particulate matter concentrations in a changing climate	reference/2bd16a59-d347-4fb4-9ff7-701e0c32ab60
Mold Spores			
Animal Dander	isMentionedIn	Climate change, air quality, and human health	reference/2d58d3bb-62b3-45f2-b4c9-10d22b556f9c
Aeroallergens	isMentionedIn	Integrated Science Assessment for Ozone and Related Photochemical Oxidants (e00fb4e2)	report/epa-600-r-10-076f
Aeroallergens	isMentionedIn	Projections of the effects of climate change on allergic asthma: The contribution of aerobiology (025515fc)	article/10.1111/j.1398-9995.2010.02423.x
Aeroallergens	isMentionedIn	Thunderstorm-asthma and pollen allergy (713cd919)	article/10.1111/j.1398-9995.2006.01271.x
Aeroallergens	isMentionedIn	Aeroallergens, Allergic Disease, and Climate Change: Impacts and Adaptation (b9370347)	article/10.1007/s10393-009-0261-x
Aeroallergens	isMentionedIn	Climate change and allergic disease (c60ed28e)	article/10.1007/s11882-012-0314-z
Aeroallergens	isMentionedIn	Anthropogenic climate change and allergic diseases (f89543d6)	article/10.3390/atmos3010200
Aeroallergens	isMentionedIn	Air pollution and allergens (d9f760b1)	article/air-pollution-allergens
Aeroallergens	isMentionedIn	Climate change and allergic disease (036ba27d)	article/10.1016/j.jaci.2008.06.032
Aeroallergens	isMentionedIn	The role of outdoor air pollution and climatic changes on the rising trends in respiratory allergy (a5b5448f)	article/10.1053/rmed.2001.1112
Aeroallergens	isMentionedIn	Environmental urban factors (air pollution and allergens) and the rising trends in allergic respiratory diseases (6d18401d)	article/10.1034/j.1398-9995.57.s72.5.x
Aeroallergens	isMentionedIn	Environmental risk factors and allergic bronchial asthma (a52668d8)	article/10.1111/j.1365-2222.2005.02328.x
Aeroallergens	isMentionedIn	Role of outdoor aeroallergens in asthma exacerbations: Epidemiological evidence (203adb04)	article/10.1136/thx.2003.019133
Aeroallergens	isMentionedIn	Analysis of short-term influences of ambient aeroallergens on pediatric asthma hospital visits (98a7b7be)	article/10.1016/j.scitotenv.2006.06.019
Aeroallergens	isMentionedIn	Effects of climate change on environmental factors in respiratory allergic diseases (b1d1a01e)	article/10.1111/j.1365-2222.2008.03033.x
Aeroallergens	isMentionedIn	Impacts of climate change on aeroallergens: Past and future (14835bc7)	article/10.1111/j.1365-2222.2004.02061.x
Aeroallergens	isMentionedIn	Does air pollution increase the effect of aeroallergens on hospitalization for asthma?	reference/4beaa115-1cbe-404e-a62d-4a943c946820
Aeroallergens	isMentionedIn	Aeroallergens, allergic disease, and climate change: Impacts and adaptation	reference/b9370347-fe7c-4b6f-9d49-af723ed931a4
Aeroallergens	isMentionedIn	Climate change, air quality, and human health	reference/2d58d3bb-62b3-45f2-b4c9-10d22b556f9c
Aeroallergens	isMentionedIn	Air pollution and allergens	reference/d9f760b1-0caa-450c-a807-e65c2097c0fb
Aeroallergens	isMentionedIn	The role of outdoor air pollution and climatic changes on the rising trends in respiratory allergy	reference/a5b5448f-6f88-4e74-a3a9-2f34aab42ecb
Aeroallergens	isMentionedIn	Climate change and allergic disease	reference/036ba27d-8341-4f6d-ad66-1288e53dee65
Aeroallergens	isMentionedIn	Projections of the effects of climate change on allergic asthma: The contribution of aerobiology	reference/025515fc-f83a-47ff-b547-92ade9513c15
Aeroallergens	isMentionedIn	Environmental urban factors (air pollution and allergens) and the rising trends in allergic respiratory diseases	reference/6d18401d-b332-4805-8b3b-07e4f6e01d13
Aeroallergens	isMentionedIn	Environmental risk factors and allergic bronchial asthma	reference/a52668d8-0468-4b90-9b62-c32a86cae478
Aeroallergens	isMentionedIn	Role of outdoor aeroallergens in asthma exacerbations: Epidemiological evidence	reference/203adb04-2d0d-4b2e-ac47-bbaeb3befedd
Aeroallergens	isMentionedIn	Analysis of short-term influences of ambient aeroallergens on pediatric asthma hospital visits	reference/98a7b7be-a84e-4adf-bbe0-72f34256c87f
Aeroallergens	isMentionedIn	Anthropogenic climate change and allergic diseases	reference/f89543d6-09bf-436c-8f7e-c0f908473457
Carbon	isMentionedIn	Technical Support Document (TSD): Preparation of Emissions Inventories for the Version 6.2, 2011 Emissions Modeling Platform	reference/5958ffb9-83be-45ec-8515-0949949ceceb
Carbon	isMentionedIn	Cross-State Air Pollution Rule (CSAPR)	reference/311fddd1-8068-4f09-a74e-66d3b72bd304
Carbon	isMentionedIn	Tier 2 Vehicle and Gasoline Sulfur Program	reference/7392ba34-1f61-448b-9451-11ab04a0523b
Carbon	isMentionedIn	Regulatory Impact Analysis - Control of Air Pollution from New Motor Vehicles: Tier 2 Motor Vehicle Emissions Standards and Gasoline Sulfur Control Requirements	reference/8e1110ca-e1dd-42c6-b686-1aa1f964a659
Carbon	isMentionedIn	Global air quality and climate	reference/914c7cdc-87d8-4b27-a7f0-dd1a2df15bb0
Carbon	isMentionedIn	Impacts of climate change from 2000 to 2050 on wildfire activity and carbonaceous aerosol concentrations in the western United States	reference/940ef8f4-6b52-40f8-a289-02bb7f07e350
Volatile Organic Compounds	isMentionedIn	Climate Change, the Indoor Environment, and Health	reference/c2e46e42-7cb9-4bb0-91df-c676943cd62a
Volatile Organic Compounds	isMentionedIn	Damp Indoor Spaces and Health	reference/3ffeefed-eb88-4fb5-8fce-a463134fb5ba
Volatile Organic Compounds	isMentionedIn	Review of health hazards and prevention measures for response and recovery workers and volunteers after natural disasters, flooding, and water damage: Mold and dampness	reference/a23ae616-9cef-4381-b8e7-1148eb73501b
Volatile Organic Compounds	isMentionedIn	Effect of temperature and humidity on formaldehyde emissions in temporary housing units	reference/94552ce3-9bd9-492d-8f3a-629bee94e836
Volatile Organic Compounds	isMentionedIn	Asthma symptoms in relation to measured building dampness in upper concrete floor construction, and 2-ethyl-1-hexanol in indoor air	reference/af729802-608b-4d90-a848-0796d625f332
Volatile Organic Compounds	isMentionedIn	Influence of relative humidity on VOC concentrations in indoor air	reference/568d2838-1167-4041-bf9d-d83a16b9dd0a
Volatile Organic Compounds	isMentionedIn	Technical Support Document (TSD): Preparation of Emissions Inventories for the Version 6.2, 2011 Emissions Modeling Platform	reference/5958ffb9-83be-45ec-8515-0949949ceceb
Location	isMentionedIn	Effects of climate change on environmental factors in respiratory allergic diseases (b1d1a01e)	article/10.1111/j.1365-2222.2008.03033.x
Location	isMentionedIn	Induction of asthma and the environment: What we know and need to know (9d0046a1)	article/10.1289/ehp.8376
Location	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Location	isMentionedIn	Projected Change in Ozone-related Premature Deaths	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/projected-change-in-ozone-related-premature-deaths
Location	isMentionedIn	Ozone and short-term mortality in 95 US urban communities, 1987-2000 (a02f25a1)	article/10.1001/jama.292.19.2372
Location	isMentionedIn	The Geographic Distribution and Economic Value of Climate Change-Related Ozone Health Impacts in the United States in 2030 (54a66159)	article/10.1080/10962247.2014.996270
Location	isMentionedIn	Ragweed Pollen Season Lengthens	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/ragweed-pollen-season-lengthens
Location	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Location	isMentionedIn	Projected Change in Temperature, Ozone, and Ozone-Related Premature Deaths in 2030	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/projected-change-in-temperature-ozone-and-ozone-related-premature-deaths-in-2030
Location	isMentionedIn	The representative concentration pathways: an overview (44124472)	article/10.1007/s10584-011-0148-z
Location	isMentionedIn	The Geographic Distribution and Economic Value of Climate Change-Related Ozone Health Impacts in the United States in 2030 (54a66159)	article/10.1080/10962247.2014.996270
Location	isMentionedIn	Ozone and short-term mortality in 95 US urban communities, 1987-2000 (a02f25a1)	article/10.1001/jama.292.19.2372
Outdoor	isMentionedIn	Integrated Science Assessment for Ozone and Related Photochemical Oxidants (e00fb4e2)	report/epa-600-r-10-076f
Outdoor	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Indoor	isMentionedIn	Human activity patterns: A review of the literature for estimating time spent indoors, outdoors, and in transit	reference/ada33d6a-7403-4a59-9b6d-f2777dd75f38
Indoor	isMentionedIn	The National Human Activity Pattern Survey (NHAPS): A resource for assessing exposure to environmental pollutants	reference/558272eb-342a-4b51-adc6-485a70a24b54
Indoor	isMentionedIn	Indoor particulate matter of outdoor origin: Importance of size-dependent removal mechanisms	reference/4385426c-155d-4006-90c0-9d1ec59b5247
Indoor	isMentionedIn	Determining the infiltration of outdoor particles in the indoor environment using a dynamic model	reference/84b6855c-3151-4929-8265-2de1c72079e9
Indoor	isMentionedIn	Indoor particles: A review	reference/808c0a4d-e4aa-43a8-a717-c522ea76eedc
Indoor	isMentionedIn	Who is more affected by ozone pollution? A systematic review and meta-analysis	reference/67a241cc-98d9-4478-a11e-f94d1dc3144b
Indoor	isMentionedIn	Chronic exposure to ambient ozone and asthma hospital admissions among children	reference/1dd1dce1-0102-4440-9451-e630b6d49128
Indoor	isMentionedIn	Review of some effects of climate change on indoor environmental quality and health and associated no-regrets mitigation measures	reference/cc7159e1-bdd7-450e-b4c6-a943fc153351
Indoor	isMentionedIn	Ozone's impact on public health: Contributions from indoor exposures to ozone and products of ozone-initiated chemistry	reference/5dbd8d4e-540b-4551-83e7-202589965032
Indoor	isMentionedIn	Epidemiology and ecology of opportunistic premise plumbing pathogens: Legionella pneumophila, Mycobacterium avium, and Pseudomonas aeruginosa	reference/40677a7f-197f-4473-a351-ea62a7249dfb
Urban Areas	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Sources	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Sources	isMentionedIn	Global air quality and climate	reference/914c7cdc-87d8-4b27-a7f0-dd1a2df15bb0
Sources	isMentionedIn	Regulatory Impact Analysis of the Proposed Revisions to the National Ambient Air Quality Standards for Ground-Level Ozone	reference/489c7b61-d874-4378-8952-180bb3c990d5
Pets			
Motor Vehicles	isMentionedIn	Regulatory Impact Analysis of the Proposed Revisions to the National Ambient Air Quality Standards for Ground-Level Ozone	reference/489c7b61-d874-4378-8952-180bb3c990d5
Vegetation	isMentionedIn	Global air quality and climate	reference/914c7cdc-87d8-4b27-a7f0-dd1a2df15bb0
Mold/Mildew	isMentionedIn	Climate change, air quality, and human health	reference/2d58d3bb-62b3-45f2-b4c9-10d22b556f9c
Mold/Mildew	isMentionedIn	Climate Change, the Indoor Environment, and Health	reference/c2e46e42-7cb9-4bb0-91df-c676943cd62a
Mold/Mildew	isMentionedIn	Damp Indoor Spaces and Health	reference/3ffeefed-eb88-4fb5-8fce-a463134fb5ba
Mold/Mildew	isMentionedIn	Review of health hazards and prevention measures for response and recovery workers and volunteers after natural disasters, flooding, and water damage: Mold and dampness	reference/a23ae616-9cef-4381-b8e7-1148eb73501b
Mold/Mildew	isMentionedIn	Review of some effects of climate change on indoor environmental quality and health and associated no-regrets mitigation measures	reference/cc7159e1-bdd7-450e-b4c6-a943fc153351
Mold/Mildew	isMentionedIn	Public health and economic impact of dampness and mold	reference/9787187e-18a1-4e16-a244-f96aec28fbff
Mold/Mildew	isMentionedIn	Association of residential dampness and mold with respiratory tract infections and bronchitis: A meta-analysis	reference/44c90dc1-a7a1-4ec8-8db4-1bb5b9fa89d6
Mold/Mildew	isMentionedIn	Healthier tribal housing: Combining the best of old and new	reference/fe12c254-1db1-4c46-8268-e966fc185ac4
Cockroaches	isMentionedIn	Climate change, air quality, and human health	reference/2d58d3bb-62b3-45f2-b4c9-10d22b556f9c
Power Plant	isMentionedIn	Regulatory Impact Analysis of the Proposed Revisions to the National Ambient Air Quality Standards for Ground-Level Ozone	reference/489c7b61-d874-4378-8952-180bb3c990d5
Infrastructure	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Air Ventilation	isMentionedIn	Healthier tribal housing: Combining the best of old and new	reference/fe12c254-1db1-4c46-8268-e966fc185ac4
Power Outage	isMentionedIn	Exploring the consequences of climate change for indoor air quality	reference/6178ad09-3e96-43ec-9775-2f772b162a29
Power Outage	isMentionedIn	Carbon monoxide exposures--United States, 2000-2009	reference/0dfe6b30-d94d-4d5b-8fec-0da6aa229d3e
Air Infiltration	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Air Infiltration	isMentionedIn	Effects of climate change on residential infiltration and air pollution exposure	reference/0b6877aa-f858-4910-8c80-3fe41e7b1855
Human Vulnerability	isMentionedIn	Induction of asthma and the environment: What we know and need to know (9d0046a1)	article/10.1289/ehp.8376
Human Vulnerability	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Human Vulnerability	isMentionedIn	Relationship between climate, pollen concentrations of Ambrosia and medical consultations for allergic rhinitis in Montreal, 1994�2002 (7eaad122)	article/10.1016/j.scitotenv.2006.05.022
Human Vulnerability	isMentionedIn	webpage Allergy Statistics (49a88ae9)	webpage/3bd35c21-e4de-426d-9542-5e56f95de321
Human Vulnerability	isMentionedIn	Air pollution and allergens (d9f760b1)	article/air-pollution-allergens
Human Vulnerability	isMentionedIn	Trends in Asthma Prevalence, Health Care Use, and Mortality in the United States, 2001�2010. NCHS Data Brief. No. 94, May 2012	reference/5a3ba94b-e83c-4f01-8156-d4b018006d0c
Health Risks	isMentionedIn	The Geographic Distribution and Economic Value of Climate Change-Related Ozone Health Impacts in the United States in 2030 (54a66159)	article/10.1080/10962247.2014.996270
Health Risks	isMentionedIn	Projections of the effects of climate change on allergic asthma: The contribution of aerobiology	reference/025515fc-f83a-47ff-b547-92ade9513c15
Health Risks	isMentionedIn	Variation in Estimated Ozone-Related Health Impacts of Climate Change due to Modeling Choices and Assumptions (fe6d1c69)	article/10.1289/ehp.1104271
Health Risks	isMentionedIn	Global health and economic impacts of future ozone pollution (8e802a4f)	article/10.1088/1748-9326/4/4/044014
Health Risks	isMentionedIn	Potential Impact of Climate Change on Air Pollution-Related Human Health Effects (c275ae44)	article/10.1021/es803650w
Health Risks	isMentionedIn	Climate change, ambient ozone, and health in 50 US cities (d6e399c7)	article/10.1007/s10584-006-9166-7
Health Risks	isMentionedIn	On the causal link between carbon dioxide and air pollution mortality (d3df6d52)	article/10.1029/2007GL031101
Health Risks	isMentionedIn	Projections of the effects of climate change on allergic asthma: The contribution of aerobiology (025515fc)	article/10.1111/j.1398-9995.2010.02423.x
Health Risks	isMentionedIn	Anthropogenic climate change and allergic diseases (f89543d6)	article/10.3390/atmos3010200
Health Risks	isMentionedIn	Air pollution and allergens (d9f760b1)	article/air-pollution-allergens
Health Risks	isMentionedIn	Climate change and allergic disease (036ba27d)	article/10.1016/j.jaci.2008.06.032
Health Risks	isMentionedIn	The role of outdoor air pollution and climatic changes on the rising trends in respiratory allergy (a5b5448f)	article/10.1053/rmed.2001.1112
Health Risks	isMentionedIn	Environmental urban factors (air pollution and allergens) and the rising trends in allergic respiratory diseases (6d18401d)	article/10.1034/j.1398-9995.57.s72.5.x
Health Risks	isMentionedIn	Environmental risk factors and allergic bronchial asthma (a52668d8)	article/10.1111/j.1365-2222.2005.02328.x
Health Risks	isMentionedIn	Role of outdoor aeroallergens in asthma exacerbations: Epidemiological evidence (203adb04)	article/10.1136/thx.2003.019133
Health Risks	isMentionedIn	Analysis of short-term influences of ambient aeroallergens on pediatric asthma hospital visits (98a7b7be)	article/10.1016/j.scitotenv.2006.06.019
Health Risks	isMentionedIn	Three Measures of Forest Fire Smoke Exposure and Their Associations with Respiratory and Cardiovascular Health Outcomes in a Population-Based Cohort (250b4ec3)	article/10.1289/ehp.1002288
Health Risks	isMentionedIn	Cardio-respiratory outcomes associated with exposure to wildfire smoke are modified by measures of community health (21efa9a6)	article/10.1186/1476-069X-11-71
Health Risks	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Resulting Medical Conditions	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Lung Cancer	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Lung Cancer	isMentionedIn	Integrated Science Assessment for Particulate Matter	reference/f7ffc8dd-70ec-4779-817a-b2985c0779e7
Hives	isMentionedIn	Climate change and allergic disease (c60ed28e)	article/10.1007/s11882-012-0314-z
Hives	isMentionedIn	Anthropogenic climate change and allergic diseases (f89543d6)	article/10.3390/atmos3010200
Mortality	isMentionedIn	The Geographic Distribution and Economic Value of Climate Change-Related Ozone Health Impacts in the United States in 2030 (54a66159)	article/10.1080/10962247.2014.996270
Mortality	isMentionedIn	Variation in Estimated Ozone-Related Health Impacts of Climate Change due to Modeling Choices and Assumptions (fe6d1c69)	article/10.1289/ehp.1104271
Mortality	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Mortality	isMentionedIn	The representative concentration pathways: an overview (44124472)	article/10.1007/s10584-011-0148-z
Mortality	isMentionedIn	Projected Change in Temperature, Ozone, and Ozone-Related Premature Deaths in 2030	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/projected-change-in-temperature-ozone-and-ozone-related-premature-deaths-in-2030
Mortality	isMentionedIn	Projected Change in Ozone-related Premature Deaths	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/projected-change-in-ozone-related-premature-deaths
Mortality	isMentionedIn	Ozone and short-term mortality in 95 US urban communities, 1987-2000 (a02f25a1)	article/10.1001/jama.292.19.2372
Eczema	isMentionedIn	Climate change and allergic disease	reference/c60ed28e-5ec3-4b9b-8b41-c6c29e4fda70
Eczema	isMentionedIn	Anthropogenic climate change and allergic diseases	reference/f89543d6-09bf-436c-8f7e-c0f908473457
COPD	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
COPD	isMentionedIn	Integrated Science Assessment for Particulate Matter	reference/f7ffc8dd-70ec-4779-817a-b2985c0779e7
Hay Fever	isMentionedIn	Climate change and allergic disease (c60ed28e)	article/10.1007/s11882-012-0314-z
Hay Fever	isMentionedIn	Anthropogenic climate change and allergic diseases (f89543d6)	article/10.3390/atmos3010200
Hay Fever	isMentionedIn	Aeroallergens, allergic disease, and climate change: Impacts and adaptation	reference/b9370347-fe7c-4b6f-9d49-af723ed931a4
Anaphylaxis	isMentionedIn	Climate change and allergic disease (c60ed28e)	article/10.1007/s11882-012-0314-z
Anaphylaxis	isMentionedIn	Anthropogenic climate change and allergic diseases (f89543d6)	article/10.3390/atmos3010200
Existing Medical Conditions	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Existing Medical Conditions	isMentionedIn	Ambient air pollution and cardiovascular emergency department visits in potentially sensitive groups	reference/92de7665-a4ff-4644-84bf-a82e9de7de35
Asthma	isMentionedIn	Percentage of population with active asthma, by year and selected characteristics: United States, 2001 and 2010	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/table/percent-population-active-asthma-characteristics
Asthma	isMentionedIn	National Surveillance of Asthma: United States, 2001-2010 (6c82bf48)	report/cdc-phs-2013-1419
Asthma	isMentionedIn	Climate change and allergic disease (c60ed28e)	article/10.1007/s11882-012-0314-z
Asthma	isMentionedIn	Anthropogenic climate change and allergic diseases (f89543d6)	article/10.3390/atmos3010200
Asthma	isMentionedIn	Integrated Science Assessment for Particulate Matter	reference/f7ffc8dd-70ec-4779-817a-b2985c0779e7
Asthma	isMentionedIn	Ozone and short-term mortality in 95 US urban communities, 1987-2000	reference/a02f25a1-29c1-4564-9b41-7d974e8ce6b5
Asthma	isMentionedIn	Integrated Science Assessment for Ozone and Related Photochemical Oxidants	reference/e00fb4e2-6406-40be-90f8-071dfc43cca3
Asthma	isMentionedIn	Long-term ozone exposure and mortality	reference/18a03092-28de-406e-b060-8f5b44614a9e
Asthma	isMentionedIn	Aeroallergens, allergic disease, and climate change: Impacts and adaptation	reference/b9370347-fe7c-4b6f-9d49-af723ed931a4
Asthma	isMentionedIn	Induction of asthma and the environment: What we know and need to know	reference/9d0046a1-8cd1-4a6d-a8c1-ab853fd1fb2a
Asthma	isMentionedIn	Review of the Impact of Climate Variability and Change on Aeroallergens and Their Associated Effects. EPA/600/R-06/164F	reference/ee565231-aabb-4636-a5c3-1c2431928538
Asthma	isMentionedIn	Asthma epidemiology: Has the crisis passed?	reference/5a49b492-093f-41bb-951c-01e1ffbeac38
Asthma	isMentionedIn	Impacts of climate change on aeroallergens: Past and future	reference/14835bc7-3df6-4fac-9e9a-2863c09e800a
Asthma	isMentionedIn	Public health and economic impact of dampness and mold	reference/9787187e-18a1-4e16-a244-f96aec28fbff
Asthma	isMentionedIn	Association of residential dampness and mold with respiratory tract infections and bronchitis: A meta-analysis	reference/44c90dc1-a7a1-4ec8-8db4-1bb5b9fa89d6
Asthma	isMentionedIn	Summary Health Statistics for U.S. Children: National Health Interview Survey, 2012	reference/dd3cf393-3d86-40ca-b13c-175b6b47941a
Asthma	isMentionedIn	Pediatric asthma: A different disease	reference/f10993f6-3898-4269-b1e4-803d1f9340af
Asthma	isMentionedIn	California's racial and ethnic minorities more adversely affected by asthma	reference/13b47140-756d-41f3-b054-e5bfbe390b69
Asthma	isMentionedIn	Asthma prevalence among US children in underrepresented minority populations: American Indian/Alaska Native, Chinese, Filipino, and Asian Indian	reference/04b0164f-5506-40f7-a6bf-698dba41196b
Asthma	isMentionedIn	Impacts of climate change on aeroallergens: Past and future (14835bc7)	article/10.1111/j.1365-2222.2004.02061.x
Cardiovascular Disease	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Cardiovascular Disease	isMentionedIn	Integrated Science Assessment for Particulate Matter	reference/f7ffc8dd-70ec-4779-817a-b2985c0779e7
Acute Respiratory Symptoms	isMentionedIn	The Geographic Distribution and Economic Value of Climate Change-Related Ozone Health Impacts in the United States in 2030 (54a66159)	article/10.1080/10962247.2014.996270
Acute Respiratory Symptoms	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Acute Respiratory Symptoms	isMentionedIn	Intercontinental impacts of ozone pollution on human mortality	reference/159d09fd-a7de-470d-9e15-375718243164
Acute Respiratory Symptoms	isMentionedIn	Estimating the national public health burden associated with exposure to ambient PM2.5 and ozone	reference/be14c1d4-c494-4844-b147-951f1c44a497
Population at Risk	isMentionedIn	Climate Change and Health--Outdoor Air Quality	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/figure/climate-change-and-health-outdoor-air-quality
Population at Risk	isMentionedIn	Relationship between climate, pollen concentrations of Ambrosia and medical consultations for allergic rhinitis in Montreal, 1994�2002 (7eaad122)	article/10.1016/j.scitotenv.2006.05.022
Population at Risk	isMentionedIn	Trends in Asthma Prevalence, Health Care Use, and Mortality in the United States, 2001�2010. NCHS Data Brief. No. 94, May 2012	reference/5a3ba94b-e83c-4f01-8156-d4b018006d0c
Population at Risk	isMentionedIn	California's racial and ethnic minorities more adversely affected by asthma	reference/13b47140-756d-41f3-b054-e5bfbe390b69
Population at Risk	isMentionedIn	Asthma prevalence among US children in underrepresented minority populations: American Indian/Alaska Native, Chinese, Filipino, and Asian Indian	reference/04b0164f-5506-40f7-a6bf-698dba41196b
Population at Risk	isMentionedIn	Racial and ethnic disparities in asthma medication usage and health-care utilization: Data from the National Asthma Survey	reference/c3bb3479-982f-4a2c-89e4-5278fa52490e
Population at Risk	isMentionedIn	webpage Allergy Statistics (49a88ae9)	webpage/3bd35c21-e4de-426d-9542-5e56f95de321
Population at Risk	isMentionedIn	Air pollution and allergens (d9f760b1)	article/air-pollution-allergens
Population at Risk	isMentionedIn	National Surveillance of Asthma: United States, 2001-2010 (6c82bf48)	report/cdc-phs-2013-1419
Population at Risk	isMentionedIn	Percentage of population with active asthma, by year and selected characteristics: United States, 2001 and 2010	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/table/percent-population-active-asthma-characteristics
Population at Risk	isMentionedIn	Pediatric asthma: A different disease	reference/f10993f6-3898-4269-b1e4-803d1f9340af
Population at Risk	isMentionedIn	Effects of ambient pollen concentrations on frequency and severity of asthma symptoms among asthmatic children	reference/727c62e3-9a02-41cb-8c91-31ec4e1f1085
Population at Risk	isMentionedIn	Climate change and children	reference/9b2bb133-071f-479a-a32d-71e9f40f5a5b
Population at Risk	isMentionedIn	The impact of climate change and aeroallergens on children's health	reference/0b3b0345-837c-4be4-9e68-6dd8d6ea5e51
Population at Risk	isMentionedIn	Effect modification by community characteristics on the short-term effects of ozone exposure and mortality in 98 US communities	reference/495289be-0bc8-4c43-8e6d-f2fc7d26e361
Population at Risk	isMentionedIn	Particulate matter�induced health effects: Who is susceptible?	reference/fd90ea4e-e20c-488c-9e6d-6d16933940c5
Population at Risk	isMentionedIn	Temperature, temperature extremes, and mortality: A study of acclimatisation and effect modification in 50 US cities	reference/bdea0759-701d-4183-9966-cee3ce977e08
Population at Risk	isMentionedIn	Ambient air pollution and cardiovascular emergency department visits in potentially sensitive groups	reference/92de7665-a4ff-4644-84bf-a82e9de7de35
Elderly	isMentionedIn	National Surveillance of Asthma: United States, 2001-2010 (6c82bf48)	report/cdc-phs-2013-1419
Elderly	isMentionedIn	Percentage of population with active asthma, by year and selected characteristics: United States, 2001 and 2010	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/table/percent-population-active-asthma-characteristics
Elderly	isMentionedIn	Effect modification by community characteristics on the short-term effects of ozone exposure and mortality in 98 US communities	reference/495289be-0bc8-4c43-8e6d-f2fc7d26e361
Elderly	isMentionedIn	Particulate matter�induced health effects: Who is susceptible?	reference/fd90ea4e-e20c-488c-9e6d-6d16933940c5
Elderly	isMentionedIn	Temperature, temperature extremes, and mortality: A study of acclimatisation and effect modification in 50 US cities	reference/bdea0759-701d-4183-9966-cee3ce977e08
Elderly	isMentionedIn	Who is more affected by ozone pollution? A systematic review and meta-analysis	reference/67a241cc-98d9-4478-a11e-f94d1dc3144b
Elderly	isMentionedIn	Chronic exposure to ambient ozone and asthma hospital admissions among children	reference/1dd1dce1-0102-4440-9451-e630b6d49128
Young	isMentionedIn	National Surveillance of Asthma: United States, 2001-2010 (6c82bf48)	report/cdc-phs-2013-1419
Young	isMentionedIn	Percentage of population with active asthma, by year and selected characteristics: United States, 2001 and 2010	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/table/percent-population-active-asthma-characteristics
Young	isMentionedIn	Trends in Asthma Prevalence, Health Care Use, and Mortality in the United States, 2001�2010. NCHS Data Brief. No. 94, May 2012	reference/5a3ba94b-e83c-4f01-8156-d4b018006d0c
Minorities	isMentionedIn	National Surveillance of Asthma: United States, 2001-2010 (6c82bf48)	report/cdc-phs-2013-1419
Minorities	isMentionedIn	Percentage of population with active asthma, by year and selected characteristics: United States, 2001 and 2010	report/usgcrp-climate-human-health-assessment-2016/chapter/air-quality-impacts/table/percent-population-active-asthma-characteristics
Minorities	isMentionedIn	California's racial and ethnic minorities more adversely affected by asthma	reference/13b47140-756d-41f3-b054-e5bfbe390b69
Minorities	isMentionedIn	Asthma prevalence among US children in underrepresented minority populations: American Indian/Alaska Native, Chinese, Filipino, and Asian Indian	reference/04b0164f-5506-40f7-a6bf-698dba41196b
Responses	isMentionedIn	The Geographic Distribution and Economic Value of Climate Change-Related Ozone Health Impacts in the United States in 2030 (54a66159)	article/10.1080/10962247.2014.996270
Responses	isMentionedIn	Variation in Estimated Ozone-Related Health Impacts of Climate Change due to Modeling Choices and Assumptions (fe6d1c69)	article/10.1289/ehp.1104271
Responses	isMentionedIn	Global health and economic impacts of future ozone pollution (8e802a4f)	article/10.1088/1748-9326/4/4/044014
Responses	isMentionedIn	Potential Impact of Climate Change on Air Pollution-Related Human Health Effects (c275ae44)	article/10.1021/es803650w
Responses	isMentionedIn	Climate change, ambient ozone, and health in 50 US cities (d6e399c7)	article/10.1007/s10584-006-9166-7
Responses	isMentionedIn	On the causal link between carbon dioxide and air pollution mortality (d3df6d52)	article/10.1029/2007GL031101
Responses	isMentionedIn	How emissions, climate, and land use change will impact mid-century air quality over the United States: A focus on effects at National Parks	reference/a92b6912-a92c-482b-a8e7-f43d324947e3
Responses	isMentionedIn	The impact of emission and climate change on ozone in the United States under representative concentration pathways (RCPs)	reference/c32eafb4-b6c1-4580-99a6-55740cea74c0
Pathogen Distribution			
Exposure Threats			
Climate Projections	isMentionedIn	chapter nca3 chapter 2 : Our Changing Climate (a6a312ba)	report/nca3/chapter/our-changing-climate
Climate Projections	isMentionedIn	How emissions, climate, and land use change will impact mid-century air quality over the United States: A focus on effects at National Parks (a92b6912)	article/10.5194/acp-15-2805-2015
Climate Projections	isMentionedIn	chapter nca3 chapter 20 : Southwest (99baa64e)	report/nca3/chapter/southwest
Climate Projections	isMentionedIn	Continued warming could transform Greater Yellowstone fire regimes by mid-21st century (b95e9226)	article/10.1073/pnas.1110199108
Human Response	isMentionedIn	The potential impacts of climate variability and change on air pollution-related health effects in the United States	reference/87031b30-75fa-495d-8a99-0df6c5eb4ced
Human Response	isMentionedIn	Effect of climate change on air quality	reference/afbd60ab-ba9f-4547-88e3-968bc3a4b949
Human Response	isMentionedIn	Integrated Science Assessment for Ozone and Related Photochemical Oxidants	reference/e00fb4e2-6406-40be-90f8-071dfc43cca3
Human Response	isMentionedIn	Variation in estimated ozone-related health impacts of climate change due to modeling choices and assumptions	reference/fe6d1c69-790d-46cc-89c4-26dc24585dcf
Human Response	isMentionedIn	On the causal link between carbon dioxide and air pollution mortality	reference/d3df6d52-0441-47cc-a939-6d09f57ea48d
Human Response	isMentionedIn	Effect modification of ozone-related mortality risks by temperature in 97 US cities	reference/2665e2d1-a6e6-48ea-93ec-d8f0b1c33e40
Human Response	isMentionedIn	Does temperature modify short-term effects of ozone on total mortality in 60 large eastern US communities? An assessment using the NMMAPS data	reference/df571440-b3df-4e18-b6d3-d990c0863a34
Human Response	isMentionedIn	Ozone modifies associations between temperature and cardiovascular mortality: Analysis of the NMMAPS data	reference/39711d30-ff47-4e0a-a2e9-9bf2b3b8c632
Human Response	isMentionedIn	Temperature enhanced effects of ozone on cardiovascular mortality in 95 large US communities, 1987-2000: Assessment using the NMMAPS data	reference/1101f4a6-b814-4d39-9a56-d07567d182d3
Human Response	isMentionedIn	Modifiers of short-term effects of ozone on mortality in eastern Massachusetts - A case-crossover analysis at individual level	reference/ac45c05a-dd19-4d79-a262-ee941af799ef
