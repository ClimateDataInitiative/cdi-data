#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
use Text::Unidecode;;
$F1 = "C:\\db\\gsfc\\crtfix\\2430_AQ-load-term-map-crt.sql";
$SqlStatement="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
#Term	Relationship	Datasets	extURI
     ($Term,$Relationship,$Datasets,$extURI) = split(/\t/);
	$DoWrite = 1;
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term eq "") {
		$ThisTerm = $OldTerm
	} else {
		$ThisTerm = $OldTerm = $Term;
	}
	$Datasets = trim($Datasets);
	$Datasets = unidecode($Datasets);
	$Datasets =~ s/'/''/g;		#Escape single quotes
	if ($Datasets eq "") {
		$DoWrite=0;
	}

	$extURI= trim($extURI);
	if ($extURI eq "") {
		$DoWrite=0;
	}


	if ($DoWrite) {
		$SqlStatement =<<EOM;
INSERT INTO term_map (term_identifier, relationship_identifier, description, gcid) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = '$ThisTerm' and s.lexicon_identifier = 'cdi'), '$Relationship', '$Datasets', '$extURI');
EOM
		print OUT "$SqlStatement";
	}
}
close OUT;
system "$ENV{'ED'} $F1"
#Term	Relationship	Datasets	extURI
__DATA__
Health	hasCaseStudy		http://toolkit.climate.gov/taking-action
Health	hasAnalysisTool		http://toolkit.climate.gov/tools?f[0]=field_parent_topic%3A116
Air Quality	hasCaseStudy	Health Care Facilities Maintain Indoor Air Quality Through Smoke and Wildfires	http://toolkit.climate.gov/taking-action/healthcare-facilities-maintain-indoor-air-quality-through-smoke-and-wildfires
Air Quality	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Air Quality	hasAnalysisTool	Benefits Mapping and Analysis Program�Community Edition (BenMAP-CE)	http://toolkit.climate.gov/tool/benefits-mapping-and-analysis-program%E2%80%94community-edition-benmap-ce
Air Quality	hasAnalysisTool	Urban Tree Canopy Assessment	http://toolkit.climate.gov/tool/urban-tree-canopy-assessment
Air Quality	hasAnalysisTool	Energy Savings Plus Health: Indoor Air Quality Guidelines for School Building Upgrades	http://toolkit.climate.gov/tool/energy-savings-plus-health-indoor-air-quality-guidelines-school-building-upgrades
Air Quality	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit
Air Quality	hasAnalysisTool	Assessing Health Vulnerability to Climate Change: A Guide for Health Departments	http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments
Climate Indicators	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Climate Indicators	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Climate Indicators	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Climate Indicators	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
Climate Indicators	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Climate Indicators	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Climate Indicators	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Climate Indicators	hasAnalysisTool	U.S. Drought Portal	http://toolkit.climate.gov/tool/us-drought-portal
Length of growing season			
Vertical mixing			
Temperature	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Temperature	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Temperature	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Temperature	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Temperature	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
Temperature	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Temperature	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Temperature	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Wind	hasCaseStudy	Wind-Resistant Construction Key to Rebuilding for Resilience	http://toolkit.climate.gov/taking-action/wind-resistant-construction-key-rebuilding-resilience
Cloud Cover			
Latitudinal Effects			
Precipitation	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Precipitation	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Precipitation	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Precipitation	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
Precipitation	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Precipitation	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Precipitation	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Humidity			
Extreme Weather	hasCaseStudy	Wind-Resistant Construction Key to Rebuilding for Resilience	http://toolkit.climate.gov/taking-action/wind-resistant-construction-key-rebuilding-resilience
Extreme Weather	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Extreme Weather	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Extreme Weather	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign
Extreme Weather	hasAnalysisTool	Substantial Damage Estimator	http://toolkit.climate.gov/tool/substantial-damage-estimator
Wildfires	hasCaseStudy	Health Care Facilities Maintain Indoor Air Quality Through Smoke and Wildfires	http://toolkit.climate.gov/taking-action/healthcare-facilities-maintain-indoor-air-quality-through-smoke-and-wildfires
Wildfires	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Wildfires	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Wildfires	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Wildfires	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign
Wildfires	hasAnalysisTool	Substantial Damage Estimator	http://toolkit.climate.gov/tool/substantial-damage-estimator
Exposure	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Exposure	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Exposure	hasAnalysisTool	Tribal-Focused Environmental Risk and Sustainability Tool (Tribal-FERST)	http://toolkit.climate.gov/tool/tribal-focused-environmental-risk-and-sustainability-tool-tribal-ferst
Exposure			
Contaminants			
Contaminants	hasAnalysisTool	Benefits Mapping and Analysis Program�Community Edition (BenMAP-CE)	http://toolkit.climate.gov/tool/benefits-mapping-and-analysis-program%E2%80%94community-edition-benmap-ce
Contaminants	hasAnalysisTool	Tribal-Focused Environmental Risk and Sustainability Tool (Tribal-FERST)	http://toolkit.climate.gov/tool/tribal-focused-environmental-risk-and-sustainability-tool-tribal-ferst
Contaminants			
Gases and Particulates	hasAnalysisTool	Benefits Mapping and Analysis Program�Community Edition (BenMAP-CE)	http://toolkit.climate.gov/tool/benefits-mapping-and-analysis-program%E2%80%94community-edition-benmap-ce
Gases and Particulates			
Pollen	hasAnalysisTool	Benefits Mapping and Analysis Program�Community Edition (BenMAP-CE)	http://toolkit.climate.gov/tool/benefits-mapping-and-analysis-program%E2%80%94community-edition-benmap-ce
Sulfates			
Sulfur Dioxide			
Ammonium			
Sea Salt			
Nitrates			
Nitrogen Oxides			
Particulate Matter	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Particulate Matter	hasAnalysisTool	Benefits Mapping and Analysis Program�Community Edition (BenMAP-CE)	http://toolkit.climate.gov/tool/benefits-mapping-and-analysis-program%E2%80%94community-edition-benmap-ce
Particulate Matter	hasAnalysisTool	EJSCREEN: Environmental Justice Screening and Mapping Tool	http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool
Ozone	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Ozone	hasAnalysisTool	Benefits Mapping and Analysis Program�Community Edition (BenMAP-CE)	http://toolkit.climate.gov/tool/benefits-mapping-and-analysis-program%E2%80%94community-edition-benmap-ce
Ozone	hasAnalysisTool	EJSCREEN: Environmental Justice Screening and Mapping Tool	http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool
Allergic Proteins			
Dust Mites			
Dust	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Mold Spores			
Animal Dander			
Aeroallergens			
Carbon			
Volatile Organic Compounds			
Location	hasCaseStudy	Health Care Facilities Maintain Indoor Air Quality Through Smoke and Wildfires	http://toolkit.climate.gov/taking-action/healthcare-facilities-maintain-indoor-air-quality-through-smoke-and-wildfires
Location	hasAnalysisTool	Assessing Health Vulnerability to Climate Change: A Guide for Health Departments	http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments
Location	hasAnalysisTool	EJSCREEN: Environmental Justice Screening and Mapping Tool	http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool
Location	hasAnalysisTool	Energy Savings Plus Health: Indoor Air Quality Guidelines for School Building Upgrades	http://toolkit.climate.gov/tool/energy-savings-plus-health-indoor-air-quality-guidelines-school-building-upgrades
Location	hasAnalysisTool	Urban Tree Canopy Assessment	http://toolkit.climate.gov/tool/urban-tree-canopy-assessment
Outdoor			
Indoor	hasCaseStudy	Health Care Facilities Maintain Indoor Air Quality Through Smoke and Wildfires	http://toolkit.climate.gov/taking-action/healthcare-facilities-maintain-indoor-air-quality-through-smoke-and-wildfires
Indoor	hasAnalysisTool	Energy Savings Plus Health: Indoor Air Quality Guidelines for School Building Upgrades	http://toolkit.climate.gov/tool/energy-savings-plus-health-indoor-air-quality-guidelines-school-building-upgrades
Urban Areas			
Sources	hasAnalysisTool	Tribal-Focused Environmental Risk and Sustainability Tool (Tribal-FERST)	http://toolkit.climate.gov/tool/tribal-focused-environmental-risk-and-sustainability-tool-tribal-ferst
Pets			
Motor Vehicles			
Vegetation			
Mold/Mildew	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Cockroaches			
Power Plant			
Infrastructure	hasCaseStudy	Health Care Facilities Maintain Indoor Air Quality Through Smoke and Wildfires	http://toolkit.climate.gov/taking-action/healthcare-facilities-maintain-indoor-air-quality-through-smoke-and-wildfires
Infrastructure	hasCaseStudy	Wind-Resistant Construction Key to Rebuilding for Resilience	http://toolkit.climate.gov/taking-action/wind-resistant-construction-key-rebuilding-resilience
Air Ventilation	hasCaseStudy	Health Care Facilities Maintain Indoor Air Quality Through Smoke and Wildfires	http://toolkit.climate.gov/taking-action/healthcare-facilities-maintain-indoor-air-quality-through-smoke-and-wildfires
Power Outage			
Air Infiltration	hasCaseStudy	Health Care Facilities Maintain Indoor Air Quality Through Smoke and Wildfires	http://toolkit.climate.gov/taking-action/healthcare-facilities-maintain-indoor-air-quality-through-smoke-and-wildfires
Human Vulnerability	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Human Vulnerability	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages
Human Vulnerability	hasAnalysisTool	Assessing Health Vulnerability to Climate Change: A Guide for Health Departments	http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments
Human Vulnerability	hasAnalysisTool	Energy Savings Plus Health: Indoor Air Quality Guidelines for School Building Upgrades	http://toolkit.climate.gov/tool/energy-savings-plus-health-indoor-air-quality-guidelines-school-building-upgrades
Human Vulnerability	hasAnalysisTool	Urban Tree Canopy Assessment	http://toolkit.climate.gov/tool/urban-tree-canopy-assessment
Human Vulnerability	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Human Vulnerability	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Human Vulnerability	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit
Health Risks	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Health Risks	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages
Health Risks	hasAnalysisTool	Assessing Health Vulnerability to Climate Change: A Guide for Health Departments	http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments
Health Risks	hasAnalysisTool	Benefits Mapping and Analysis Program�Community Edition (BenMAP-CE)	http://toolkit.climate.gov/tool/benefits-mapping-and-analysis-program%E2%80%94community-edition-benmap-ce
Health Risks	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Health Risks	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Health Risks	hasAnalysisTool	Tribal-Focused Environmental Risk and Sustainability Tool (Tribal-FERST)	http://toolkit.climate.gov/tool/tribal-focused-environmental-risk-and-sustainability-tool-tribal-ferst
Resulting Medical Conditions	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Resulting Medical Conditions			
Lung Cancer			
Hives			
Mortality			
Eczema			
COPD	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Hay Fever			
Anaphylaxis			
Existing Medical Conditions	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Existing Medical Conditions	hasAnalysisTool	Urban Tree Canopy Assessment	http://toolkit.climate.gov/tool/urban-tree-canopy-assessment
Asthma	hasAnalysisTool	Benefits Mapping and Analysis Program�Community Edition (BenMAP-CE)	http://toolkit.climate.gov/tool/benefits-mapping-and-analysis-program%E2%80%94community-edition-benmap-ce
Asthma	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Asthma	hasAnalysisTool	Urban Tree Canopy Assessment	http://toolkit.climate.gov/tool/urban-tree-canopy-assessment
Cardiovascular Disease	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Cardiovascular Disease	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Acute Respiratory Symptoms			
Populations at Risk	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Populations at Risk	hasAnalysisTool	Assessing Health Vulnerability to Climate Change: A Guide for Health Departments	http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments
Populations at Risk	hasAnalysisTool	Benefits Mapping and Analysis Program�Community Edition (BenMAP-CE)	http://toolkit.climate.gov/tool/benefits-mapping-and-analysis-program%E2%80%94community-edition-benmap-ce
Populations at Risk	hasAnalysisTool	EJSCREEN: Environmental Justice Screening and Mapping Tool	http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool
Populations at Risk	hasAnalysisTool	Energy Savings Plus Health: Indoor Air Quality Guidelines for School Building Upgrades	http://toolkit.climate.gov/tool/energy-savings-plus-health-indoor-air-quality-guidelines-school-building-upgrades
Populations at Risk	hasAnalysisTool	Urban Tree Canopy Assessment	http://toolkit.climate.gov/tool/urban-tree-canopy-assessment
Populations at Risk	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Populations at Risk			
Elderly	hasAnalysisTool	EJSCREEN: Environmental Justice Screening and Mapping Tool	http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool
Young	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Young	hasAnalysisTool	EJSCREEN: Environmental Justice Screening and Mapping Tool	http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool
Young	hasAnalysisTool	Energy Savings Plus Health: Indoor Air Quality Guidelines for School Building Upgrades	http://toolkit.climate.gov/tool/energy-savings-plus-health-indoor-air-quality-guidelines-school-building-upgrades
Minorities	hasAnalysisTool	EJSCREEN: Environmental Justice Screening and Mapping Tool	http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool
Response	hasCaseStudy	Health Care Facilities Maintain Indoor Air Quality Through Smoke and Wildfires	http://toolkit.climate.gov/taking-action/healthcare-facilities-maintain-indoor-air-quality-through-smoke-and-wildfires
Response	hasCaseStudy	Wind-Resistant Construction Key to Rebuilding for Resilience	http://toolkit.climate.gov/taking-action/wind-resistant-construction-key-rebuilding-resilience
Response	hasAnalysisTool	Energy Savings Plus Health: Indoor Air Quality Guidelines for School Building Upgrades	http://toolkit.climate.gov/tool/energy-savings-plus-health-indoor-air-quality-guidelines-school-building-upgrades
Response	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit
Pathogen Distribution			
Exposure Threats			
Climate Projections	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Climate Projections	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Human Response			
