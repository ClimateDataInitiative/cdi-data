use LWP::UserAgent;
use vcfw;
GenDTG();

$url = $ARGV[0];    #File to Snarf
#$url = "https://catalog.data.gov/dataset/agricultural-baseline-database";
$f1  = "c:\\temp\\snarf_$DTG2.1";    #Where to Stash it
$f2  = "c:\\temp\\snarf_$DTG2.json";    #Where to Stash the JSON 

if ($url eq "") {
   die "\nFormat:\n\ngetmeta [http://file.to.snarf]\n\n";
}

if ($f1 eq "") {
   $l = rindex($url,"/");   #use same file name to save to
   $f1 = substr($url,$l+1);
   $f1 = "index.html" if $f1 eq "";
}

print "Snarfing :$url\nto       :$f1\n";


  $ua = new LWP::UserAgent;
  $ua->agent("$0/0.1 " . $ua->agent);
  $ua->agent("Vince Wilding's Snarfilator (VCFW)");
# $ua->referer("http://joe.sent.me/");

  $req = new HTTP::Request 'GET' => "$url";
  $req->header('Accept' => 'text/html');

  # send request
  $res = $ua->request($req);

  # check the outcome
  if ($res->is_success) {
    open (FILE,">$f1") || die "Couldn't open $f1: $!\n";
    print FILE $res->content;;
    close (FILE);
  } else {
    $X = $res->status_line;
    print "\n\aError: \"$X\"\n???";
    $X = (<STDIN>);
  }

$Cmd1 = "C:\\cygwin\\bin\\grep \"Download Metadata\" $f1";
print "Executing [$Cmd1]\n";
$json1 = `$Cmd1`;
if ($json1 eq "") {
	die "Bad File Format at $url\n";
}
$json1 = trim($json1);
$json1 =~ s/<a href=\"//;
$json1 =~ s/\">Download Metadata<\/a>//;
$json1 = "https://catalog.data.gov" . $json1;
print $json1;
  $req = new HTTP::Request 'GET' => "$json1";
  $req->header('Accept' => 'text/html');

  # send request
  $res = $ua->request($req);

  # check the outcome
  if ($res->is_success) {
    open (FILE,">$f2") || die "Couldn't open $f1: $!\n";
    print FILE $res->content;;
    close (FILE);
  } else {
    $X = $res->status_line;
    print "\n\aError: \"$X\"\n???";
    $X = (<STDIN>);
  }
print "\nDownloaded $json1 to $f2";
#system "C:\\Progra~2\\EditPl~1\\editplus.exe $f2"
system "c:\\perl\\bin\\perl c:\\db\\gsfc\\readjson2.pl $f2";
