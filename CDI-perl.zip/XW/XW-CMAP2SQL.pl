#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
$F1 = "C:\\db\\gsfc\\XW\\XW-load-cmap.sql";
$F2 = "C:\\db\\gsfc\\XW\\XW-load-rship.sql";
$Relationship = "Throw this away";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
open (OUT2,">",$F2) || die "choke on open out $F2: $!\n";
print OUT2 "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
	($Subject,$Predicate,$Relationship,$Object) = split(/\t/);
	$Subject = trim($Subject);		# trim trailing/leading spaces
	$Predicate = trim($Predicate);
	$Object= trim($Object);
	$Preds{$Predicate}++; #Count Predicates
print OUT<<EOM;
INSERT INTO term_relationship (term_subject, relationship_identifier, term_object) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = '$Subject' and s.lexicon_identifier = 'cdi'), '$Predicate', (SELECT o.identifier FROM term AS o WHERE o.term = '$Object' and o.lexicon_identifier = 'cdi' ));
EOM
}
foreach $key (sort keys(%Preds)){  # generate relationship statements
	$Count = $Preds{$key};
	$Tot1 += $Count;
	print OUT2 "INSERT INTO relationship (relationship) VALUES ('$key');\n";
    }
#print OUT2 " -- [$Tot1]\n";
close OUT;
close OUT2;
system "$ENV{'ED'} $F2 $F1"
#Subject	Predicate	Relationship	Object
__DATA__
Health	skos:narrower	is broader than	Extreme Weather
Extreme Weather	isInfluencedBy	isInfluencedBy	Human Vulnerability
Human Vulnerability	isDeterminedBy	isDeterminedBy	Socioeconomic Risks
Socioeconomic Risks	isResultOf	Include	Poverty
Human Vulnerability	isDeterminedBy	isDeterminedBy	Health Risks
Health Risks	skos:narrower	consistOf	Resulting Medical Conditions
Resulting Medical Conditions	isResultOf	Include	Traumatic Injury
Resulting Medical Conditions	isResultOf	Include	Frost Bite
Resulting Medical Conditions	isResultOf	Include	Hypothermia
Resulting Medical Conditions	isResultOf	Include	Asphyxiation
Resulting Medical Conditions	isResultOf	Include	Carbon Monoxide Poisoning
Resulting Medical Conditions	isResultOf	Include	Respiratory Impacts
Resulting Medical Conditions	isResultOf	Include	Disease Spread
Resulting Medical Conditions	isResultOf	Include	Burns
Resulting Medical Conditions	isResultOf	Include	Drowning
Resulting Medical Conditions	isResultOf	Include	Wound Infection
Health Risks	skos:narrower	consistOf	Existing Medical Conditions
Existing Medical Conditions	isResultOf	Include	Mental Illness
Existing Medical Conditions	isResultOf	Include	Stress Disorders
Existing Medical Conditions	isResultOf	Include	Chronic Disease
Existing Medical Conditions	isResultOf	Include	Asthma
Human Vulnerability	isDeterminedBy	isDeterminedBy	Populations at Risk
Populations at Risk	isResultOf	Include	Medication Dependent
Populations at Risk	isResultOf	Include	Age
Populations at Risk	isResultOf	Include	Chronic Medical Conditions
Populations at Risk	isResultOf	Include	Assistance Needed
Human Vulnerability	isDeterminedBy	isDeterminedBy	Adaptive Capacity
Adaptive Capacity	skos:narrower	Involves	Resilience
Adaptive Capacity	skos:narrower	Involves	Cognitive Impairments
Adaptive Capacity	skos:narrower	Involves	Mobility Impairments
Adaptive Capacity	skos:narrower	Involves	Chemical Dependence
Adaptive Capacity	skos:narrower	Involves	Medical Dependence
Extreme Weather	isInfluencedBy	isInfluencedBy	Exposure
Exposure	isDeterminedBy	isDeterminedBy	Contaminants
Contaminants	skos:narrower	canBe	Illness
Illness	isResultOf	Include	Disease Exposure
Contaminants	skos:narrower	canBe	Gases and Particulates
Gases and Particulates	skos:narrower	Include	Carbon Monoxide
Gases and Particulates	skos:narrower	Include	Toxic Smoke
Exposure	isDeterminedBy	isDeterminedBy	Location
Location	skos:narrower	canOccur	Rural Communities
Location	skos:narrower	canOccur	Urban Areas
Location	skos:narrower	canOccur	Building Locations
Extreme Weather	isInfluencedBy	isInfluencedBy	Infrastructure
Infrastructure	skos:narrower	Include	Water Treatment
Infrastructure	skos:narrower	Include	Water Quality/ Water Quantity
Infrastructure	skos:narrower	Include	Electrical Grids
Infrastructure	skos:narrower	Include	Public Health Systems
Infrastructure	skos:narrower	Include	Cascading Failure
Extreme Weather	isInfluencedBy	isInfluencedBy	Climate Indicators
Climate Indicators	skos:narrower	Include	Intensity
Climate Indicators	skos:narrower	Include	Frequency
Climate Indicators	skos:narrower	Include	High Tide
Climate Indicators	skos:narrower	Include	Rising Temperature
Climate Indicators	skos:narrower	Include	Duration
Climate Indicators	skos:narrower	Include	Drier Summers
Climate Indicators	skos:narrower	Include	Sea Level Rise
Climate Indicators	skos:narrower	Include	Trends
Climate Indicators	skos:narrower	Include	Warning
Extreme Weather	isInfluencedBy	isInfluencedBy	Extreme Weather
Extreme Weather	skos:narrower	Include	Flooding
Extreme Weather	skos:narrower	Include	Storm Surge
Extreme Weather	skos:narrower	include	Extreme Precipitation
Extreme Weather	skos:narrower	include	Coastal Storms
Extreme Weather	skos:narrower	include	Hurricanes
Extreme Weather	skos:narrower	include	Drought
Extreme Weather	skos:narrower	include	Severe Thunderstorms
Extreme Weather	skos:narrower	include	Hail 
Extreme Weather	skos:narrower	include	Tornadoes
Extreme Weather	skos:narrower	include	Winter Storms
Extreme Weather	skos:narrower	include	Wind
Extreme Weather	skos:narrower	include	Derecho
Extreme Weather	skos:narrower	include	Storms
Extreme Weather	skos:narrower	include	Wildfires
