#!perl -w
#Input from __DATA__ below, tab seperated subject,predicate,(old relationship, ignored), object
use vcfw;
use Text::Unidecode;
$F1 = "C:\\db\\gsfc\\XW\\XW-load-term-map.sql";
$Sql1="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
	($Term,$Relationship,$Dataset,$URI) = split(/\t/);
	if ($Term ne "") {
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Dataset eq "") {
		$Dataset= "N/A";
	}
	$Dataset = trim($Dataset);
	$Dataset =~ s/'/''/g;		#Escape single quotes
	$Dataset =~ s/"/''/g;		#Escape double quotes
	$Dataset =~ s/\x0a//g;  # 
	$Dataset =~ s/\x0d//g;  # 
	if ($URI eq "") {
		$URI= "N/A";
	}
	$URI= trim($URI);
	$Dataset =~ s/'/''/g;		#Escape single quotes
	$Dataset =~ s/"/''/g;		#Escape double quotes
	$URI =~ s/\x0a//g;  # 
	$URI =~ s/\x0d//g;  # 

	$Relationship = trim($Relationship);

$Sql1 = "INSERT INTO term_map (term_identifier, relationship_identifier, gcid, description) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = ";
	$OutLine=<<EOM;
$Sql1'$Term' and s.lexicon_identifier = 'cdi'), '$Relationship', '$URI', '$Dataset');
EOM
	if ($Dataset ne "N/A") {print OUT "$OutLine";}
	}
}
close OUT;
system "$ENV{'ED'} $F1"
#Subject	Predicate	Relationship	Object
#Term	Relationship	Datasets	extURI		
#xtermid	contextid	Term	Relationship	Datasets	extURI








__DATA__
Health	isMentionedIn		https://catalog.data.gov/dataset?vocab_category_all=Human+Health&groups=climate5434#topic=humanhealth_navigation
			
Extreme Weather	isMentionedIn	U.S. Annual Climatological Summaries	http://catalog.data.gov/dataset/annual-climatological-summaries
Extreme Weather	isMentionedIn	Climate Data Online (CDO)	http://catalog.data.gov/dataset/climate-data-online-cdo
Extreme Weather	isMentionedIn	Climate Reconstructions	http://catalog.data.gov/dataset/climate-reconstructions
Extreme Weather	isMentionedIn	Geographical Information System Graphical Database of Tornados 1950-2006	http://catalog.data.gov/dataset/geographical-information-system-graphical-database-of-tornados-1950-2006
Extreme Weather	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Extreme Weather	isMentionedIn	NOAA Emergency Response Imagery	http://catalog.data.gov/dataset/noaa-emergency-response-imagery
Extreme Weather	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Extreme Weather	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Extreme Weather	isMentionedIn	Severe Weather Data Inventory	http://catalog.data.gov/dataset/severe-weather-data-inventory
Extreme Weather	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Extreme Weather	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Extreme Weather	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Extreme Weather	isMentionedIn	National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system
Extreme Weather	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Extreme Weather	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries	https://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
Extreme Weather	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
			
Human Vulnerability	isMentionedIn	Food Environment Atlas	http://catalog.data.gov/dataset/food-environment-atlas-f4a22
Human Vulnerability	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Human Vulnerability	isMentionedIn	CDC WONDER: Cancer Statistics	http://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	"https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths"
Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Human Vulnerability	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Human Vulnerability	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
Human Vulnerability	isMentionedIn	Designated Health Professional Shortage Areas	http://catalog.data.gov/dataset/designated-health-professional-shortage-areas
Human Vulnerability	isMentionedIn	Food Security in the United States	http://catalog.data.gov/dataset/food-security-in-the-united-states
Human Vulnerability	isMentionedIn	HCUPnet	http://catalog.data.gov/dataset/hcupnet
Human Vulnerability	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Human Vulnerability	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
Human Vulnerability	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
Human Vulnerability	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Human Vulnerability	isMentionedIn	Global Annual Average PM2.5 Grids from MODIS and MISR Aerosol Optical Depth (AOD)	http://catalog.data.gov/dataset/global-annual-average-pm2-5-grids-from-modis-and-misr-aerosol-optical-depth-aod
			
Socioeconomic Risks	isMentionedIn	Food Access Research Atlas	http://catalog.data.gov/dataset/food-access-research-atlas
Socioeconomic Risks	isMentionedIn	Food Environment Atlas	https://catalog.data.gov/dataset/food-environment-atlas-f4a22
Socioeconomic Risks	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Socioeconomic Risks	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
Socioeconomic Risks	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Socioeconomic Risks	isMentionedIn	NOAA Digital Coast Sea Level Rise and Coastal Flooding Impacts Viewer	https://catalog.data.gov/dataset/noaa-digital-coast-sea-level-rise-and-coastal-flooding-impacts-viewer
Socioeconomic Risks	isMentionedIn	Supplemental Nutrition Assistance Program (SNAP) Data System	https://catalog.data.gov/dataset/supplemental-nutrition-assistance-program-snap-data-system-a2b49
			
Poverty	isMentionedIn	Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas
Poverty	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Poverty	isMentionedIn	Designated Health Professional Shortage Areas	http://catalog.data.gov/dataset/designated-health-professional-shortage-areas
Poverty	isMentionedIn	Food Environment Atlas	https://catalog.data.gov/dataset/food-environment-atlas-f4a22
			
Health Risks	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Health Risks	isMentionedIn	Drinking Water Treatability Database (TDB)	https://catalog.data.gov/dataset/drinking-water-treatability-database-tdb
Health Risks	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Health Risks	isMentionedIn	FluView National Flu Activity Map	https://catalog.data.gov/dataset/fluview-national-flu-activity-map
Health Risks	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
			
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Cancer Statistics	http://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Resulting Medical Conditions	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
			
Traumatic Injury			
Frost Bite			
Hypothermia	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Hypothermia	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Hypothermia	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Hypothermia	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Hypothermia	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
			
Asphyxiation	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Asphyxiation	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Asphyxiation	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Asphyxiation	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Asphyxiation	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
			
Carbon Monoxide Poisoning	isMentionedIn	ISLSCP II EDGAR 3 Gridded Greenhouse and Ozone Precursor Gas Emissions	http://catalog.data.gov/dataset/islscp-ii-edgar-3-gridded-greenhouse-and-ozone-precursor-gas-emissions
Carbon Monoxide Poisoning	isMentionedIn	Tropospheric Emission Spectrometer (TES) Data	http://catalog.data.gov/dataset/tropospheric-emission-spectrometer-tes-data
			
Respiratory Impacts	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Respiratory Impacts	isMentionedIn	Global Annual Average PM2.5 Grids from MODIS and MISR Aerosol Optical Depth (AOD)	https://catalog.data.gov/dataset/global-annual-average-pm2-5-grids-from-modis-and-misr-aerosol-optical-depth-aod
			
Disease Spread			
Burns			
Drowning	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Drowning	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Drowning	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Drowning	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Drowning	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
			
Wound Infection			
Existing Medical Conditions	isMentionedIn	Health Data Interactive (HDI)	https://catalog.data.gov/dataset/health-data-interactive-hdi
Existing Medical Conditions	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
			
Mental Illness	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Mental Illness	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Mental Illness	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Mental Illness	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Mental Illness	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Mental Illness	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Mental Illness	isMentionedIn	Mental Health Treatement Facilities Locator	https://catalog.data.gov/dataset/mental-health-treatement-facilities-locator
Mental Illness	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
			
Stress Disorders	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Stress Disorders	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Stress Disorders	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Stress Disorders	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Stress Disorders	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
			
Chronic Disease	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Chronic Disease	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Chronic Disease	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Chronic Disease	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Chronic Disease	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
			
Asthma	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Asthma	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
Asthma	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Asthma	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Asthma	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	http://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths
Asthma	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Asthma	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
			
Populations at Risk	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Populations at Risk	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	http://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Populations at Risk	isMentionedIn	CDC WONDER: Cancer Statistics 	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Populations at Risk	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Infant Deaths	"https://catalog.data.gov/dataset/cdc-wonder-mortality-infant-deaths"
Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Populations at Risk	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Populations at Risk	isMentionedIn	CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates
Populations at Risk	isMentionedIn	Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas
Populations at Risk	isMentionedIn	Food Environment Atlas	http://catalog.data.gov/dataset/food-environment-atlas-f4a22
Populations at Risk	isMentionedIn	Pesticide Data Program 2008	http://catalog.data.gov/dataset/pesticide-data-program-2008
Populations at Risk	isMentionedIn	Social Vulnerability Index (SoVI) for the U.S. Coastal States based on the 2010 Census Tracts	http://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-the-u-s-coastal-states-based-on-the-2010-census-tracts
Populations at Risk	isMentionedIn	Supplemental Nutrition Assistance Program (SNAP) Data System	http://catalog.data.gov/dataset/supplemental-nutrition-assistance-program-snap-data-system-a2b49
Populations at Risk	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	http://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
			
Medication Dependent			
Age	isMentionedIn	CDC WONDER: Cancer Statistics	https://catalog.data.gov/dataset/cdc-wonder-cancer-statistics
Age	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Age	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	"https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death"
Age	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Age	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Age	isMentionedIn	Health Data Interactive (HDI)	http://catalog.data.gov/dataset/health-data-interactive-hdi
Age	isMentionedIn	State Snapshots	http://catalog.data.gov/dataset/state-snapshots
Age	isMentionedIn	Statistical Abstract of the United States	http://catalog.data.gov/dataset/statistical-abstract-of-the-united-states
Age	isMentionedIn	Demographic Trends (1970-2010) for Coastal Geographies	https://catalog.data.gov/dataset/demographic-trends-1970-2010-for-coastal-geographies
Age	isMentionedIn	CDC WONDER: Population - Bridged-Race July 1st Estimates	https://catalog.data.gov/dataset/cdc-wonder-population-bridged-race-july-1st-estimates
Age	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Age	isMentionedIn	VitalStats	https://catalog.data.gov/dataset/vitalstats
Age	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
			
Chronic Medical Conditions	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
			
Assistance Needed			
Adaptive Capacity			
Resilience	isMentionedIn	Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper
Resilience	isMentionedIn	Social Vulnerability Index (SoVI) for Coastal States based on 2000 Census Block Groups	https://catalog.data.gov/dataset/social-vulnerability-index-sovi-for-coastal-states-based-on-2000-census-block-groups
			
Cognitive Impairments			
Mobility Impairments			
Chemical Dependence			
Medical Dependence			
Exposure	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Exposure	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Exposure	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Exposure	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
			
			
Contaminants	isMentionedIn	Air Markets Program Data (AMPD)	https://catalog.data.gov/dataset/air-markets-program-data-ampd
Contaminants	isMentionedIn	Clean Air Markets - Where You Live (National and State Maps)	https://catalog.data.gov/dataset/clean-air-markets-where-you-live-national-and-state-maps
Contaminants	isMentionedIn	Clean Air Status and Trends Network (CASTNET)	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet
Contaminants	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Contaminants	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Contaminants	isMentionedIn	Safe Drinking Water Information System (SDWIS)	https://catalog.data.gov/dataset/safe-drinking-water-information-system-sdwis
			
Illness			
Disease Exposure	isMentionedIn	FluView National Flu Activity Map	https://catalog.data.gov/dataset/fluview-national-flu-activity-map
			
Gases and Particulates	isMentionedIn	MODIS/Terra+Aqua NRT value-added Aerosol Optical Depth Produc V051 NRT	http://catalog.data.gov/dataset/modis-terraaqua-nrt-value-added-aerosol-optical-depth-produc-v051-nrt
Gases and Particulates	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Gases and Particulates	isMentionedIn	Report on U.S. Methane Emissions 1990-2020: Inventories, Projections, and Opportunities for Reductions: 2001 Updated emission and cost estimates	https://catalog.data.gov/dataset/report-on-u-s-methane-emissions-1990-2020-inventories-projections-and-opportunities-for-reducti
Gases and Particulates	isMentionedIn	Tropospheric Emission Spectrometer (TES) Data	http://catalog.data.gov/dataset/tropospheric-emission-spectrometer-tes-data
Gases and Particulates	isMentionedIn	Air Markets Program Data (AMPD)	http://catalog.data.gov/dataset/air-markets-program-data-ampd
			
Carbon Monoxide	isMentionedIn	ISLSCP II EDGAR 3 Gridded Greenhouse and Ozone Precursor Gas Emissions	http://catalog.data.gov/dataset/islscp-ii-edgar-3-gridded-greenhouse-and-ozone-precursor-gas-emissions
Carbon Monoxide	isMentionedIn	Tropospheric Emission Spectrometer (TES) Data	http://catalog.data.gov/dataset/tropospheric-emission-spectrometer-tes-data
			
Toxic Smoke			
Location	isMentionedIn	National Air Toxic Assessments (NATA) Results	http://catalog.data.gov/dataset/national-air-toxic-assessments-nata-results
Location	isMentionedIn	CDC WONDER: Daily Fine Particulate Matter	http://catalog.data.gov/dataset/cdc-wonder-daily-fine-particulate-matter
Location	isMentionedIn	Clean Air Markets - Where You Live (National and State Maps)	http://catalog.data.gov/dataset/clean-air-markets-where-you-live-national-and-state-maps
Location	isMentionedIn	Clean Air Status and Trends Network (CASTNET)	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet
Location	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Location	isMentionedIn	EnviroAtlas - Clean Air Metrics for Conterminous United States	https://catalog.data.gov/dataset/enviroatlas-clean-air-metrics-for-conterminous-united-states
Location	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Location	isMentionedIn	Fire Weather Outlooks 	http://catalog.data.gov/dataset/fire-weather-outlooks
Location	isMentionedIn	FluView National Flu Activity Map	http://catalog.data.gov/dataset/fluview-national-flu-activity-map
Location	isMentionedIn	National Flood Hazard Layer (NFHL)	http://catalog.data.gov/dataset/national-flood-hazard-layer-nfhl
Location	isMentionedIn	National Integrated Drought Information System	http://catalog.data.gov/dataset/national-integrated-drought-information-system
Location	isMentionedIn	National Weather Service County Warning Area Boundaries	http://catalog.data.gov/dataset/national-weather-service-county-warning-area-boundaries
Location	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Location	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries 	http://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
Location	isMentionedIn	USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	http://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass
			
Rural Communities	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Rural Communities	isMentionedIn	State Snapshots	https://catalog.data.gov/dataset/state-snapshots
			
Urban Areas	isMentionedIn	CDC WONDER: Mortality - Underlying Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-underlying-cause-of-death
Urban Areas	isMentionedIn	CDC WONDER: Mortality - Multiple Cause of Death	https://catalog.data.gov/dataset/cdc-wonder-mortality-multiple-cause-of-death
Urban Areas	isMentionedIn	CDC WONDER: Compressed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-compressed-mortality-underlying-cause-of-death
Urban Areas	isMentionedIn	CDC WONDER: Detailed Mortality - Underlying Cause of Death	http://catalog.data.gov/dataset/cdc-wonder-detailed-mortality-underlying-cause-of-death
Urban Areas	isMentionedIn	Emergency Shelter Grantee (ESG) Areas	https://catalog.data.gov/dataset/esg-grantee-areas
			
Building Locations			
			
Infrastructure	isMentionedIn	USGS National Structures Dataset (NSD) Downloadable Data Collection - National Geospatial Data Asset (NGDA) USGS National Structures Dataset	https://catalog.data.gov/dataset/usgs-national-structures-dataset-nsd-downloadable-data-collection-national-geospatial-data-ass
Infrastructure	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
			
Water Treatment			
Water Quality/ Water Quantity			
Electrical Grids			
Public Health Systems			
Cascading Failure			
			
Climate Indicators	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	https://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Climate Indicators	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Climate Indicators	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Climate Indicators	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
Climate Indicators	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Climate Indicators	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Climate Indicators	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Climate Indicators	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Climate Indicators	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Climate Indicators	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Climate Indicators	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
Climate Indicators	isMentionedIn	Climate Prediction Center (CPC) Global Land Surface Air Temperature Analysis	https://catalog.data.gov/dataset/climate-prediction-center-cpc-global-land-surface-air-temperature-analysis
Climate Indicators	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Climate Indicators	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
Climate Indicators	isMentionedIn	Global Climate Station Summaries	https://catalog.data.gov/dataset/global-climate-station-summaries
Climate Indicators	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Climate Indicators	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M), Version 3	https://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
Climate Indicators	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Climate Indicators	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
Climate Indicators	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
			
Intensity			
Frequency	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Frequency	isMentionedIn	PRISM	http://catalog.data.gov/dataset/prism-585c8
Frequency	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	https://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Frequency	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Frequency	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Frequency	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
			
High Tide	isMentionedIn	USGS Map service: Coastal Vulnerability to Sea-Level Rise	https://catalog.data.gov/dataset/usgs-map-service-coastal-vulnerability-to-sea-level-rise
High Tide	isMentionedIn	Integrated Surface Global Hourly Data	https://catalog.data.gov/dataset/integrated-surface-global-hourly-data
High Tide	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	https://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
			
Rising Temperature			
Duration			
Drier Summers			
Sea Level Rise	isMentionedIn	USGS Map service: Coastal Vulnerability to Sea-Level Rise	https://catalog.data.gov/dataset/usgs-map-service-coastal-vulnerability-to-sea-level-rise
Sea Level Rise	isMentionedIn	NOAA Digital Coast Sea Level Rise and Coastal Flooding Impacts Viewer	https://catalog.data.gov/dataset/noaa-digital-coast-sea-level-rise-and-coastal-flooding-impacts-viewer
Sea Level Rise	isMentionedIn	Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper
			
Trends	isMentionedIn	Climate Reconstructions	http://catalog.data.gov/dataset/climate-reconstructions
Trends	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Trends	isMentionedIn	Global Historical Climatology Network - Daily (GHCN-Daily)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-daily-ghcn-daily-version-3
Trends	isMentionedIn	Global Historical Climatology Network - Monthly (GHCN-M)- Version 3	http://catalog.data.gov/dataset/global-historical-climatology-network-monthly-ghcn-m-version-3
Trends	isMentionedIn	Global Surface Summary of the Day - GSOD	http://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Trends	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	http://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Trends	isMentionedIn	U.S. Annual/Seasonal Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-annual-seasonal-climate-normals-1981-2010
Trends	isMentionedIn	U.S. Daily Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-daily-climate-normals-1981-2010
Trends	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Trends	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	http://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Trends	isMentionedIn	Half degree-Alaska Daily Downscaled Climate Projections by Katharine Hayhoe	http://catalog.data.gov/dataset/half-degree-alaska-daily-downscaled-climate-projections-by-katharine-hayhoe
Trends	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Trends	isMentionedIn	U.S. Climate Reference Network (USCRN) Daily Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-daily-products
Trends	isMentionedIn	U.S. Climate Reference Network (USCRN) Hourly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-hourly-products
Trends	isMentionedIn	U.S. Climate Reference Network (USCRN) Monthly Products	http://catalog.data.gov/dataset/u-s-climate-reference-network-uscrn-monthly-products
Trends	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
			
Warning	isMentionedIn	Severe Weather Data Inventory	https://catalog.data.gov/dataset/severe-weather-data-inventory
Warning	isMentionedIn	National Weather Service County Warning Area Boundaries	https://catalog.data.gov/dataset/national-weather-service-county-warning-area-boundaries
Warning	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	https://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Warning	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries	https://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
			
			
Extreme Weather	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Extreme Weather	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Extreme Weather	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
Extreme Weather	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
Extreme Weather	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Extreme Weather	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Extreme Weather	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	https://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Extreme Weather	isMentionedIn	Severe Weather Data Inventory	https://catalog.data.gov/dataset/severe-weather-data-inventory
Extreme Weather	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries	https://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
Extreme Weather	isMentionedIn	U.S. Monthly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-monthly-climate-normals-1981-2010
Extreme Weather	isMentionedIn	Geographical Information System Graphical Database of Tornados 1950-2006	http://catalog.data.gov/dataset/geographical-information-system-graphical-database-of-tornados-1950-2006
Extreme Weather	isMentionedIn	NOAA Emergency Response Imagery	http://catalog.data.gov/dataset/noaa-emergency-response-imagery
Extreme Weather	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Extreme Weather	isMentionedIn	National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system
Extreme Weather	isMentionedIn	CDC National Environmental Public Health Tracking Network (Tracking Network)	https://catalog.data.gov/dataset/cdc-national-environmental-public-health-tracking-network-tracking-network
Extreme Weather	isMentionedIn	Fire Weather Outlooks 	http://catalog.data.gov/dataset/fire-weather-outlooks
			
Flooding	isMentionedIn	Coastal Flood Hazard Composite Layer for the Coastal Flood Exposure Mapper	https://catalog.data.gov/dataset/coastal-flood-hazard-composite-layer-for-the-coastal-flood-exposure-mapper
Flooding	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Flooding	isMentionedIn	National Flood Hazard Layer (NFHL)	http://catalog.data.gov/dataset/national-flood-hazard-layer-nfhl
Flooding	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Flooding	isMentionedIn	NOAA Digital Coast Sea Level Rise and Coastal Flooding Impacts Viewer	http://catalog.data.gov/dataset/noaa-digital-coast-sea-level-rise-and-coastal-flooding-impacts-viewer
Flooding	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries 	http://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
Flooding	isMentionedIn	WaterWatch -- Current Water Resources Conditions	http://catalog.data.gov/dataset/waterwatch-current-water-resources-conditions
Flooding	isMentionedIn	Integrated Surface Global Hourly Data	https://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Storm Surge	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Extreme Precipitation	isMentionedIn	Eighth degree-CONUS Statistical Asynchronous Regional Regression Daily Downscaled Climate Projections	https://catalog.data.gov/dataset/eighth-degree-conus-daily-downscaled-climate-projections-by-katharine-hayhoe
			
Coastal Storms			
			
Drought	isMentionedIn	National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system
Drought	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Drought	isMentionedIn	WaterWatch -- Current Water Resources Conditions	http://catalog.data.gov/dataset/waterwatch-current-water-resources-conditions
Drought	isMentionedIn	Climate Prediction Center (CPC) Palmer Drought and Crop Moisture Indices	http://catalog.data.gov/dataset/climate-prediction-center-cpc-palmer-drought-and-crop-moisture-indices
Drought	isMentionedIn	Integrated Surface Global Hourly Data	https://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Drought	isMentionedIn	NOAA's Climate Divisional Database (nCLIMDIV)	https://catalog.data.gov/dataset/noaas-climate-divisional-database-nclimdiv
Drought	isMentionedIn	Climate Reconstructions	https://catalog.data.gov/dataset/climate-reconstructions
			
Severe Thunderstorms	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Severe Thunderstorms	isMentionedIn	Geographical Information System Graphical Database of Tornados 1950-2006	https://catalog.data.gov/dataset/geographical-information-system-graphical-database-of-tornados-1950-2006
Severe Thunderstorms	isMentionedIn	Fire Weather Outlooks	https://catalog.data.gov/dataset/fire-weather-outlooks
Severe Thunderstorms	isMentionedIn	NOAA National Weather Service- Flood Inundation Map Libraries 	http://catalog.data.gov/dataset/noaa-national-weather-service-flood-inundation-map-libraries
Hail 	isMentionedIn	Global Surface Summary of the Day - GSOD	http://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Hail 	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Hail 	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Hail 	isMentionedIn	Fire Weather Outlooks	https://catalog.data.gov/dataset/fire-weather-outlooks
			
Tornadoes	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Tornadoes	isMentionedIn	Geographical Information System Graphical Database of Tornados 1950-2006	https://catalog.data.gov/dataset/geographical-information-system-graphical-database-of-tornados-1950-2006
Tornadoes	isMentionedIn	Severe Weather Data Inventory	https://catalog.data.gov/dataset/severe-weather-data-inventory
Tornadoes	isMentionedIn	NOAA Emergency Response Imagery	https://catalog.data.gov/dataset/noaa-emergency-response-imagery
Tornadoes	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Tornadoes	isMentionedIn	Integrated Surface Global Hourly Data	https://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Tornadoes	isMentionedIn	Fire Weather Outlooks	https://catalog.data.gov/dataset/fire-weather-outlooks
			
Winter Storms	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Winter Storms	isMentionedIn	Fire Weather Outlooks	https://catalog.data.gov/dataset/fire-weather-outlooks
			
Wind	isMentionedIn	Climate Data Online (CDO)	http://catalog.data.gov/dataset/climate-data-online-cdo
Wind	isMentionedIn	Geographical Information System Graphical Database of Tornados 1950-2006	http://catalog.data.gov/dataset/geographical-information-system-graphical-database-of-tornados-1950-2006
Wind	isMentionedIn	Global Climate Station Summaries	http://catalog.data.gov/dataset/global-climate-station-summaries
Wind	isMentionedIn	Global Surface Summary of the Day - GSOD	http://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Wind	isMentionedIn	Integrated Surface Global Hourly Data	http://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Wind	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Wind	isMentionedIn	NOAA Climate Data Record (CDR) of Ocean Near Surface Atmospheric Properties	https://catalog.data.gov/dataset/noaa-climate-data-record-cdr-of-ocean-near-surface-atmospheric-properties
Wind	isMentionedIn	NOAA's nowCOAST Web Mapping Portal to Near-Real-Time Coastal Information	http://catalog.data.gov/dataset/noaas-nowcoast-web-mapping-portal-to-near-real-time-coastal-information
Wind	isMentionedIn	PRISM	https://catalog.data.gov/dataset/prism-585c8
Wind	isMentionedIn	Quality Controlled Local Climatological Data (QCLCD) Publication	https://catalog.data.gov/dataset/quality-controlled-local-climatological-data-qclcd-publication
Wind	isMentionedIn	U.S. Hourly Climate Normals (1981-2010)	https://catalog.data.gov/dataset/u-s-hourly-climate-normals-1981-2010
Wind	isMentionedIn	Clean Air Status and Trends Network (CASTNET) Download Data Module	https://catalog.data.gov/dataset/clean-air-status-and-trends-network-castnet-download-data-module
Wind	isMentionedIn	Fire Weather Outlooks	https://catalog.data.gov/dataset/fire-weather-outlooks
Derecho			
Storms	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Storms	isMentionedIn	Severe Weather Data Inventory	https://catalog.data.gov/dataset/severe-weather-data-inventory
Storms	isMentionedIn	NOAA Emergency Response Imagery	https://catalog.data.gov/dataset/noaa-emergency-response-imagery
Storms	isMentionedIn	Global Surface Summary of the Day - GSOD	https://catalog.data.gov/dataset/global-surface-summary-of-the-day-gsod
Storms	isMentionedIn	Integrated Surface Global Hourly Data	https://catalog.data.gov/dataset/integrated-surface-global-hourly-data
Storms	isMentionedIn	Geographical Information System Graphical Database of Tornados 1950-2006	https://catalog.data.gov/dataset/geographical-information-system-graphical-database-of-tornados-1950-2006
Storms	isMentionedIn	Climate Data Online (CDO)	https://catalog.data.gov/dataset/climate-data-online-cdo
			
Hurricanes	isMentionedIn	FEMA HAZUS Critical Facilities for Coastal Geographies	http://catalog.data.gov/dataset/fema-hazus-critical-facilities-for-coastal-geographies
Hurricanes	isMentionedIn	NCDC Storm Events Database	http://catalog.data.gov/dataset/ncdc-storm-events-database
Hurricanes	isMentionedIn	NOAA Emergency Response Imagery	http://catalog.data.gov/dataset/noaa-emergency-response-imagery
			
Wildfires	isMentionedIn	LandCarbon Conterminous United States Burned Area and Severity Mosaics 2001-2050 Metadata	https://catalog.data.gov/dataset/landcarbon-conterminous-united-states-burned-area-and-severity-mosaics-2001-2050-metadata
Wildfires	isMentionedIn	NCDC Storm Events Database	https://catalog.data.gov/dataset/ncdc-storm-events-database
Wildfires	isMentionedIn	National Integrated Drought Information System	https://catalog.data.gov/dataset/national-integrated-drought-information-system
Wildfires	isMentionedIn	Fire Weather Outlooks	https://catalog.data.gov/dataset/fire-weather-outlooks
