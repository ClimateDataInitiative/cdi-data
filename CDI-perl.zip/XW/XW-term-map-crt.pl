#!perl -w
##Input from __DATA__ below, GCIS tab of spreadsheet, tab seperated Term	Relationship	Datasets	extURI
use vcfw;
use Text::Unidecode;
$F1 = "C:\\db\\gsfc\\crtfix\\2480_XW-load-term-map-crt.sql"; #2480_XW-load-term-map-crt.sql
$SqlStatement="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
#Term	Relationship	Datasets	extURI
	($Term,$Relationship,$Datasets,$extURI) = split(/\t/);
	$DoWrite = 1;
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term eq "") {
		$ThisTerm = $OldTerm
	} else {
		$ThisTerm = $OldTerm = $Term;
	}
	$Datasets = trim($Datasets);
	$Datasets = unidecode($Datasets);
	$Datasets =~ s/'/''/g;		#Escape single quotes
	if ($Datasets eq "") {
		$DoWrite=0;
	}

	$extURI= trim($extURI);
	if ($extURI eq "") {
		$DoWrite=0;
	}
	$Relationship = trim($Relationship);
		if ($Relationship eq "") {
		$DoWrite=0;
	}

	if ($DoWrite) {
		$SqlStatement =<<EOM;
INSERT INTO term_map (term_identifier, relationship_identifier, description, gcid) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = '$ThisTerm' and s.lexicon_identifier = 'cdi'), '$Relationship', '$Datasets', '$extURI');
EOM
		print OUT "$SqlStatement";
	}
}
close OUT;
system "$ENV{'ED'} $F1"
#Subject	Predicate	Relationship	Object
#Term	Relationship	Datasets	extURI

#Extreme Weather
#hasCaseStudy	
#Following a Devastating Tornado, Town and Hospital Rebuild to Harness Wind Energy	
#http://toolkit.climate.gov/taking-action/following-devastating-tornado-town-and-hospital-rebuild-harness-wind-energy


#Term	Relationship	Datasets	extURI

__DATA__
Extreme Weather	hasCaseStudy	Following a Devastating Tornado, Town and Hospital Rebuild to Harness Wind Energy	http://toolkit.climate.gov/taking-action/following-devastating-tornado-town-and-hospital-rebuild-harness-wind-energy
Extreme Weather	hasAnalysisTool	Disaster Behavioral Health Information Series	http://toolkit.climate.gov/tool/disaster-behavioral-health-information-series
Extreme Weather	hasAnalysisTool	EJSCREEN: Environmental Justice Screening and Mapping Tool	http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool
Extreme Weather	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Extreme Weather	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Extreme Weather	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit
Human Vulnerability	hasCaseStudy	After Record-Breaking Rains, a Major Medical Center's Hazard Mitigation Plan Improves Resilience	http://toolkit.climate.gov/taking-action/after-record-breaking-rains-major-medical-centers-hazard-mitigation-plan-improves
Human Vulnerability	hasAnalysisTool	Great Lakes Climate Atlas	http://toolkit.climate.gov/tool/great-lakes-climate-atlas
Human Vulnerability	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Human Vulnerability	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Human Vulnerability	hasAnalysisTool	Assessing Health Vulnerability to Climate Change: A Guide for Health Departments	http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments
Socioeconomic Risks	hasCaseStudy	Following a Devastating Tornado, Town and Hospital Rebuild to Harness Wind Energy	http://toolkit.climate.gov/taking-action/following-devastating-tornado-town-and-hospital-rebuild-harness-wind-energy
Socioeconomic Risks	hasCaseStudy	Extreme Rainfall Analyses Can Point to Right Size for Culverts	http://toolkit.climate.gov/taking-action/extreme-rainfall-analyses-can-point-right-size-culverts
Socioeconomic Risks	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Socioeconomic Risks	hasAnalysisTool	Great Lakes Climate Atlas	http://toolkit.climate.gov/tool/great-lakes-climate-atlas
Socioeconomic Risks	hasAnalysisTool	Hazus-MH	http://toolkit.climate.gov/tool/hazus
Poverty	hasAnalysisTool	Social Vulnerability Index	http://toolkit.climate.gov/tool/social-vulnerability-index
Health Risks	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages
Health Risks	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Resulting Medical Conditions			
Traumatic Injury			
Frost Bite			
Hypothermia			
Asphyxiation			
Carbon Monoxide Poisoning			
Respiratory Impacts			
Disease Spread			
Burns			
Drowning			
Wound Infection			
Existing Medical Conditions			
Mental Illness	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages
Mental Illness	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Stress Disorders	hasAnalysisTool	SAMHSA Disaster App	http://toolkit.climate.gov/tool/samhsa-disaster-app
Chronic Disease			
Asthma			
Populations at Risk	hasCaseStudy	Retrofitting a Children's Hospital with a Hurricane-Resistant Shell	http://toolkit.climate.gov/taking-action/retrofitting-childrens-hospital-hurricane-resistant-shell
Populations at Risk	hasAnalysisTool	EJSCREEN: Environmental Justice Screening and Mapping Tool	http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool
Medication Dependent			
Age	hasAnalysisTool	EJSCREEN: Environmental Justice Screening and Mapping Tool	http://toolkit.climate.gov/tool/ejscreen-environmental-justice-screening-and-mapping-tool
Chronic Medical Conditions			
Assistance Needed	hasCaseStudy	Retrofitting a Children's Hospital with a Hurricane-Resistant Shell	http://toolkit.climate.gov/taking-action/retrofitting-childrens-hospital-hurricane-resistant-shell
Adaptive Capacity	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages
Adaptive Capacity	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall
Adaptive Capacity	hasAnalysisTool	Arctic Adaptation Exchange	http://toolkit.climate.gov/tool/arctic-adaptation-exchange
Adaptive Capacity	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Adaptive Capacity	hasAnalysisTool	Climate Adaptation Knowledge Exchange (CAKE)	http://toolkit.climate.gov/tool/climate-adaptation-knowledge-exchange-cake
Resilience	hasCaseStudy	After Record-Breaking Rains, a Major Medical Center's Hazard Mitigation Plan Improves Resilience	http://toolkit.climate.gov/taking-action/after-record-breaking-rains-major-medical-centers-hazard-mitigation-plan-improves
Resilience	hasCaseStudy	Hospital Plans Ahead for Power, Serves the Community Through Hurricane Sandy	http://toolkit.climate.gov/taking-action/hospital-plans-ahead-power-serves-community-through-hurricane-sandy
Resilience	hasCaseStudy	Planning for the Future in a Floodplain	http://toolkit.climate.gov/taking-action/planning-future-floodplain
Resilience	hasCaseStudy	Building Smart in the Floodplain	http://toolkit.climate.gov/taking-action/building-smart-floodplain
Resilience	hasCaseStudy	After Katrina, Health Care Facility's Infrastructure Planned to Withstand Future Flooding	http://toolkit.climate.gov/taking-action/after-katrina-health-care-facilitys-infrastructure-planned-withstand-future-flooding
Resilience	hasCaseStudy	Retrofitting a Children's Hospital with a Hurricane-Resistant Shell	http://toolkit.climate.gov/taking-action/retrofitting-childrens-hospital-hurricane-resistant-shell
Resilience	hasCaseStudy	Island Medical Campus Recovers, Rebuilds to Face Future Storms	http://toolkit.climate.gov/taking-action/island-medical-campus-recovers-rebuilds-face-future-storms
Resilience	hasCaseStudy	Wind-Resistant Construction Key to Rebuilding for Resilience	http://toolkit.climate.gov/taking-action/wind-resistant-construction-key-rebuilding-resilience
Resilience	hasCaseStudy	Investment in Infrastructure at Sea-Level Hospital Will Pay Off by Reducing Risk	http://toolkit.climate.gov/taking-action/investment-infrastructure-sea-level-hospital-will-pay-reducing-risk
Resilience	hasAnalysisTool	Community Health Resilience Guide and Toolset	http://toolkit.climate.gov/tool/community-health-resilience-guide-and-toolset
Resilience	hasAnalysisTool	Flood Resilience: A Basic Guide for Water and Wastewater Utilities	http://toolkit.climate.gov/tool/flood-resilience-basic-guide-water-and-wastewater-utilities
Resilience	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit
Resilience	hasAnalysisTool	Assessing Health Vulnerability to Climate Change: A Guide for Health Departments	http://toolkit.climate.gov/tool/assessing-health-vulnerability-climate-change-guide-health-departments
Cognitive Impairments			
Mobility Impairments			
Chemical Dependence			
Medical Dependence	hasAnalysisTool	Dialysis Facility Comparison	http://toolkit.climate.gov/tool/dialysis-facility-comparison
Exposure			
Contaminants			
Illness			
Disease Exposure			
Gases and Particulates			
Carbon Monoxide			
Toxic Smoke			
Location			
Rural Communities			
Urban Areas			
Building Locations			
Infrastructure	hasCaseStudy	After Record-Breaking Rains, a Major Medical Center's Hazard Mitigation Plan Improves Resilience	http://toolkit.climate.gov/taking-action/after-record-breaking-rains-major-medical-centers-hazard-mitigation-plan-improves
Infrastructure	hasCaseStudy	Planning for the Future in a Floodplain	http://toolkit.climate.gov/taking-action/planning-future-floodplain
Infrastructure	hasCaseStudy	After Katrina, Health Care Facility's Infrastructure Planned to Withstand Future Flooding	http://toolkit.climate.gov/taking-action/after-katrina-health-care-facilitys-infrastructure-planned-withstand-future-flooding
Infrastructure	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages
Infrastructure	hasCaseStudy	Island Medical Campus Recovers, Rebuilds to Face Future Storms	http://toolkit.climate.gov/taking-action/island-medical-campus-recovers-rebuilds-face-future-storms
Infrastructure	hasAnalysisTool	Substantial Damage Estimator	http://toolkit.climate.gov/tool/substantial-damage-estimator
Infrastructure	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit
Water Treatment	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall
Water Quality/ Water Quantity			
Electrical Grids			
Public Health Systems	hasCaseStudy	After Record-Breaking Rains, a Major Medical Center's Hazard Mitigation Plan Improves Resilience	http://toolkit.climate.gov/taking-action/after-record-breaking-rains-major-medical-centers-hazard-mitigation-plan-improves
Public Health Systems	hasCaseStudy	Hospital Plans Ahead for Power, Serves the Community Through Hurricane Sandy	http://toolkit.climate.gov/taking-action/hospital-plans-ahead-power-serves-community-through-hurricane-sandy
Public Health Systems	hasCaseStudy	After Katrina, Health Care Facility's Infrastructure Planned to Withstand Future Flooding	http://toolkit.climate.gov/taking-action/after-katrina-health-care-facilitys-infrastructure-planned-withstand-future-flooding
Public Health Systems	hasCaseStudy	Following a Devastating Tornado, Town and Hospital Rebuild to Harness Wind Energy	http://toolkit.climate.gov/taking-action/following-devastating-tornado-town-and-hospital-rebuild-harness-wind-energy
Public Health Systems	hasCaseStudy	Retrofitting a Children's Hospital with a Hurricane-Resistant Shell	http://toolkit.climate.gov/taking-action/retrofitting-childrens-hospital-hurricane-resistant-shell
Public Health Systems	hasCaseStudy	Elevated Rehabilitation Facility Functions Flawlessly Through Hurricane Sandy	http://toolkit.climate.gov/taking-action/elevated-rehab-facility-functions-flawlessly-through-hurricane-sandy
Public Health Systems	hasCaseStudy	Island Medical Campus Recovers, Rebuilds to Face Future Storms	http://toolkit.climate.gov/taking-action/island-medical-campus-recovers-rebuilds-face-future-storms
Public Health Systems	hasCaseStudy	Wind-Resistant Construction Key to Rebuilding for Resilience	http://toolkit.climate.gov/taking-action/wind-resistant-construction-key-rebuilding-resilience
Public Health Systems	hasCaseStudy	Investment in Infrastructure at Sea-Level Hospital Will Pay Off by Reducing Risk	http://toolkit.climate.gov/taking-action/investment-infrastructure-sea-level-hospital-will-pay-reducing-risk
Public Health Systems	hasAnalysisTool	Sustainable and Climate-Resilient Health Care Facilities Toolkit	http://toolkit.climate.gov/tool/sustainable-and-climate-resilient-health-care-facilities-toolkit
Cascading Failure			
Climate Indicators	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Climate Indicators	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
Climate Indicators	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Intensity	hasCaseStudy	Retrofitting a Children's Hospital with a Hurricane-Resistant Shell	http://toolkit.climate.gov/taking-action/retrofitting-childrens-hospital-hurricane-resistant-shell
Frequency			
High Tide			
Rising Temperature	hasCaseStudy	Navajo Nation: Hotter, Drier Climate Puts Sand Dunes on the Move	http://toolkit.climate.gov/taking-action/navajo-nation-hotter-drier-climate-puts-sand-dunes-move
Rising Temperature	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Rising Temperature	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Rising Temperature	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Rising Temperature	hasAnalysisTool	Excessive Heat Events Guidebook	http://toolkit.climate.gov/tool/excessive-heat-events-guidebook
Duration			
Drier Summers			
Sea Level Rise	hasCaseStudy	After Katrina, Health Care Facility's Infrastructure Planned to Withstand Future Flooding	http://toolkit.climate.gov/taking-action/after-katrina-health-care-facilitys-infrastructure-planned-withstand-future-flooding
Sea Level Rise	hasCaseStudy	Investment in Infrastructure at Sea-Level Hospital Will Pay Off by Reducing Risk	http://toolkit.climate.gov/taking-action/investment-infrastructure-sea-level-hospital-will-pay-reducing-risk
Sea Level Rise	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Sea Level Rise	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Trends			
Warning			
Extreme Weather	hasCaseStudy	After Record-Breaking Rains, a Major Medical Center's Hazard Mitigation Plan Improves Resilience	http://toolkit.climate.gov/taking-action/after-record-breaking-rains-major-medical-centers-hazard-mitigation-plan-improves
Extreme Weather	hasCaseStudy	Elevated Rehabilitation Facility Functions Flawlessly Through Hurricane Sandy	http://toolkit.climate.gov/taking-action/elevated-rehab-facility-functions-flawlessly-through-hurricane-sandy
Extreme Weather	hasCaseStudy	Island Medical Campus Recovers, Rebuilds to Face Future Storms	http://toolkit.climate.gov/taking-action/island-medical-campus-recovers-rebuilds-face-future-storms
Extreme Weather	hasCaseStudy	Hospital Plans Ahead for Power, Serves the Community Through Hurricane Sandy	http://toolkit.climate.gov/taking-action/hospital-plans-ahead-power-serves-community-through-hurricane-sandy
Extreme Weather	hasCaseStudy	Wind-Resistant Construction Key to Rebuilding for Resilience	http://toolkit.climate.gov/taking-action/wind-resistant-construction-key-rebuilding-resilience
Extreme Weather	hasAnalysisTool	Advanced Hydrologic Prediction Service	http://toolkit.climate.gov/tool/advanced-hydrologic-prediction-service
Extreme Weather	hasAnalysisTool	Community Health Resilience Guide and Toolset	http://toolkit.climate.gov/tool/community-health-resilience-guide-and-toolset
Extreme Weather	hasAnalysisTool	Dialysis Facility Comparison	http://toolkit.climate.gov/tool/dialysis-facility-comparison
Extreme Weather	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Extreme Weather	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Extreme Weather	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Extreme Weather	hasAnalysisTool	Substantial Damage Estimator	http://toolkit.climate.gov/tool/substantial-damage-estimator
Extreme Weather	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign
Flooding	hasCaseStudy	After Record-Breaking Rains, a Major Medical Center's Hazard Mitigation Plan Improves Resilience	http://toolkit.climate.gov/taking-action/after-record-breaking-rains-major-medical-centers-hazard-mitigation-plan-improves
Flooding	hasCaseStudy	Planning for the Future in a Floodplain	http://toolkit.climate.gov/taking-action/planning-future-floodplain
Flooding	hasCaseStudy	Extreme Rainfall Analyses Can Point to Right Size for Culverts	http://toolkit.climate.gov/taking-action/extreme-rainfall-analyses-can-point-right-size-culverts
Flooding	hasCaseStudy	Building Smart in the Floodplain	http://toolkit.climate.gov/taking-action/building-smart-floodplain
Flooding	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall
Flooding	hasCaseStudy	Elevated Rehabilitation Facility Functions Flawlessly Through Hurricane Sandy	http://toolkit.climate.gov/taking-action/elevated-rehab-facility-functions-flawlessly-through-hurricane-sandy
Flooding	hasCaseStudy	Island Medical Campus Recovers, Rebuilds to Face Future Storms	http://toolkit.climate.gov/taking-action/island-medical-campus-recovers-rebuilds-face-future-storms
Flooding	hasCaseStudy	Extreme Rainfall Analyses Can Point to Right Size for Culverts	http://toolkit.climate.gov/taking-action/extreme-rainfall-analyses-can-point-right-size-culverts
Flooding	hasCaseStudy	Investment in Infrastructure at Sea-Level Hospital Will Pay Off by Reducing Risk	http://toolkit.climate.gov/taking-action/investment-infrastructure-sea-level-hospital-will-pay-reducing-risk
Flooding	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Flooding	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Flooding	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Flooding	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Flooding	hasAnalysisTool	Community Health Resilience Guide and Toolset	http://toolkit.climate.gov/tool/community-health-resilience-guide-and-toolset
Flooding	hasAnalysisTool	Disaster Behavioral Health Information Series	http://toolkit.climate.gov/tool/disaster-behavioral-health-information-series
Flooding	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Flooding	hasAnalysisTool	FEMA Flood Map Service Center	http://toolkit.climate.gov/tool/fema-flood-map-service-center
Flooding	hasAnalysisTool	Flood Resilience: A Basic Guide for Water and Wastewater Utilities	http://toolkit.climate.gov/tool/flood-resilience-basic-guide-water-and-wastewater-utilities
Flooding	hasAnalysisTool	Hazus-MH	http://toolkit.climate.gov/tool/hazus
Flooding	hasAnalysisTool	Metadata Access Tool for Climate and Health (MATCH)	http://toolkit.climate.gov/tool/metadata-access-tool-climate-and-health-match
Flooding	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Flooding	hasAnalysisTool	Substantial Damage Estimator	http://toolkit.climate.gov/tool/substantial-damage-estimator
Flooding	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign
Storm Surge	hasCaseStudy	Elevated Rehabilitation Facility Functions Flawlessly Through Hurricane Sandy	http://toolkit.climate.gov/taking-action/elevated-rehab-facility-functions-flawlessly-through-hurricane-sandy
Storm Surge	hasCaseStudy	Island Medical Campus Recovers, Rebuilds to Face Future Storms	http://toolkit.climate.gov/taking-action/island-medical-campus-recovers-rebuilds-face-future-storms
Storm Surge	hasCaseStudy	Investment in Infrastructure at Sea-Level Hospital Will Pay Off by Reducing Risk	http://toolkit.climate.gov/taking-action/investment-infrastructure-sea-level-hospital-will-pay-reducing-risk
Storm Surge	hasAnalysisTool	HURREVAC	http://toolkit.climate.gov/tool/hurrevac
Extreme Precipitation	hasCaseStudy	Using Demonstration Storms to Prepare for Extreme Rainfall	http://toolkit.climate.gov/taking-action/using-demonstration-storms-prepare-extreme-rainfall
Extreme Precipitation	hasCaseStudy	Elevated Rehabilitation Facility Functions Flawlessly Through Hurricane Sandy	http://toolkit.climate.gov/taking-action/elevated-rehab-facility-functions-flawlessly-through-hurricane-sandy
Extreme Precipitation	hasCaseStudy	Extreme Rainfall Analyses Can Point to Right Size for Culverts	http://toolkit.climate.gov/taking-action/extreme-rainfall-analyses-can-point-right-size-culverts
Extreme Precipitation	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Coastal Storms			
Hurricanes	hasCaseStudy	Elevated Rehabilitation Facility Functions Flawlessly Through Hurricane Sandy	http://toolkit.climate.gov/taking-action/elevated-rehab-facility-functions-flawlessly-through-hurricane-sandy
Hurricanes	hasCaseStudy	Hospital Plans Ahead for Power, Serves the Community Through Hurricane Sandy	http://toolkit.climate.gov/taking-action/hospital-plans-ahead-power-serves-community-through-hurricane-sandy
Hurricanes	hasCaseStudy	After Katrina, Health Care Facility's Infrastructure Planned to Withstand Future Flooding	http://toolkit.climate.gov/taking-action/after-katrina-health-care-facilitys-infrastructure-planned-withstand-future-flooding
Hurricanes	hasCaseStudy	Retrofitting a Children's Hospital with a Hurricane-Resistant Shell	http://toolkit.climate.gov/taking-action/retrofitting-childrens-hospital-hurricane-resistant-shell
Hurricanes	hasCaseStudy	Island Medical Campus Recovers, Rebuilds to Face Future Storms	http://toolkit.climate.gov/taking-action/island-medical-campus-recovers-rebuilds-face-future-storms
Hurricanes	hasAnalysisTool	Climate Explorer	http://toolkit.climate.gov/tool/climate-explorer
Hurricanes	hasAnalysisTool	Community Health Resilience Guide and Toolset	http://toolkit.climate.gov/tool/community-health-resilience-guide-and-toolset
Hurricanes	hasAnalysisTool	Disaster Behavioral Health Information Series	http://toolkit.climate.gov/tool/disaster-behavioral-health-information-series
Hurricanes	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Hurricanes	hasAnalysisTool	Hazus-MH	http://toolkit.climate.gov/tool/hazus
Hurricanes	hasAnalysisTool	Historical Hurricane Tracks	http://toolkit.climate.gov/tool/historical-hurricane-tracks
Hurricanes	hasAnalysisTool	HURREVAC	http://toolkit.climate.gov/tool/hurrevac
Hurricanes	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Drought	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Drought	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages
Drought	hasCaseStudy	Addressing Links Between Climate and Public Health in Alaska Native Villages	http://toolkit.climate.gov/taking-action/addressing-links-between-climate-and-public-health-alaska-native-villages
Drought	hasCaseStudy	Health Care Facilities Maintain Indoor Air Quality Through Smoke and Wildfires	http://toolkit.climate.gov/taking-action/healthcare-facilities-maintain-indoor-air-quality-through-smoke-and-wildfires
Drought	hasAnalysisTool	Advanced Hydrologic Prediction Service	http://toolkit.climate.gov/tool/advanced-hydrologic-prediction-service
Drought	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Drought	hasAnalysisTool	Climate at a Glance	http://toolkit.climate.gov/tool/climate-glance
Drought	hasAnalysisTool	Climate Outlooks	http://toolkit.climate.gov/tool/climate-outlooks
Drought	hasAnalysisTool	Disaster Behavioral Health Information Series	http://toolkit.climate.gov/tool/disaster-behavioral-health-information-series
Drought	hasAnalysisTool	U.S. Drought Portal	http://toolkit.climate.gov/tool/us-drought-portal
Drought	hasAnalysisTool	NOAA's Weather and Climate Toolkit	http://toolkit.climate.gov/tool/noaas-weather-and-climate-toolkit
Severe Thunderstorms	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign
Hail			
Tornadoes	hasCaseStudy	Following a Devastating Tornado, Town and Hospital Rebuild to Harness Wind Energy	http://toolkit.climate.gov/taking-action/following-devastating-tornado-town-and-hospital-rebuild-harness-wind-energy
Tornadoes	hasCaseStudy	Wind-Resistant Construction Key to Rebuilding for Resilience	http://toolkit.climate.gov/taking-action/wind-resistant-construction-key-rebuilding-resilience
Tornadoes	hasAnalysisTool	Community Health Resilience Guide and Toolset	http://toolkit.climate.gov/tool/community-health-resilience-guide-and-toolset
Tornadoes	hasAnalysisTool	Disaster Behavioral Health Information Series	http://toolkit.climate.gov/tool/disaster-behavioral-health-information-series
Tornadoes	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Tornadoes	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign
Winter Storms			
Wind	hasCaseStudy	Retrofitting a Children's Hospital with a Hurricane-Resistant Shell	http://toolkit.climate.gov/taking-action/retrofitting-childrens-hospital-hurricane-resistant-shell
Wind	hasCaseStudy	Wind-Resistant Construction Key to Rebuilding for Resilience	http://toolkit.climate.gov/taking-action/wind-resistant-construction-key-rebuilding-resilience
Wind	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Wind	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Wind	hasAnalysisTool	HURREVAC	http://toolkit.climate.gov/tool/hurrevac
Wind	hasAnalysisTool	Substantial Damage Estimator	http://toolkit.climate.gov/tool/substantial-damage-estimator
Derecho			
Storms	hasCaseStudy	Wind-Resistant Construction Key to Rebuilding for Resilience	http://toolkit.climate.gov/taking-action/wind-resistant-construction-key-rebuilding-resilience
Storms	hasAnalysisTool	Historical Hurricane Tracks	http://toolkit.climate.gov/tool/historical-hurricane-tracks
Wildfires	hasCaseStudy	Health Care Facilities Maintain Indoor Air Quality Through Smoke and Wildfires	http://toolkit.climate.gov/taking-action/healthcare-facilities-maintain-indoor-air-quality-through-smoke-and-wildfires
Wildfires	hasCaseStudy	Charting Colorado�s Vulnerability to Climate Change	http://toolkit.climate.gov/taking-action/charting-colorado%E2%80%99s-vulnerability-climate-change
Wildfires	hasAnalysisTool	Cal-Adapt	http://toolkit.climate.gov/tool/cal-adapt
Wildfires	hasAnalysisTool	Cities Impacts & Adaptation Tool (CIAT)	http://toolkit.climate.gov/tool/cities-impacts-adaptation-tool-ciat
Wildfires	hasAnalysisTool	Community Health Resilience Guide and Toolset	http://toolkit.climate.gov/tool/community-health-resilience-guide-and-toolset
Wildfires	hasAnalysisTool	Disaster Behavioral Health Information Series	http://toolkit.climate.gov/tool/disaster-behavioral-health-information-series
Wildfires	hasAnalysisTool	Emergency Preparedness and Response: Natural Disasters and Severe Weather	http://toolkit.climate.gov/tool/emergency-preparedness-and-response-natural-disasters-and-severe-weather
Wildfires	hasAnalysisTool	Substantial Damage Estimator	http://toolkit.climate.gov/tool/substantial-damage-estimator
Wildfires	hasAnalysisTool	Ready Campaign	http://toolkit.climate.gov/tool/ready-campaign
