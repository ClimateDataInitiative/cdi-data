#!perl -w
#Input from __DATA__ below, GCIS tab of spreadsheet, tab seperated Term	Relationship	Datasets	extURI
use vcfw;
use Text::Unidecode;
$F1 = "C:\\db\\gsfc\\XW\\XW-load-term-map-gcis.sql";
$SqlStatement="";
open (OUT,">",$F1) || die "choke on open out $F1: $!\n";
print OUT "-- O/P of $0\n";
while (<DATA>) 	{
	chomp;
	#Term	Relationship	Datasets	extURI
	($Term,$Relationship,$Dataset,$URI) = split(/\t/);
	$Term = trim($Term);		# trim trailing/leading spaces
	if ($Term ne "") {
		$Relationship = trim($Relationship);
		if ($Relationship eq "") {
			$Relationship= "N/A";
		}
		$Dataset = trim($Dataset);
		if ($Dataset eq "") {
			$Dataset= "N/A";
		}
		$Dataset = unidecode($Dataset);
		$Dataset =~ s/'/''/g;		#Escape single quotes
		$URI= trim($URI);
		if ($URI eq "") {
			$URI= "N/A";
		}
		$SqlStatement =<<EOM;
INSERT INTO term_map (term_identifier, relationship_identifier, gcid, description) VALUES ((SELECT s.identifier FROM term AS s WHERE s.term = '$Term' and s.lexicon_identifier='cdi'), '$Relationship', '$URI', '$Dataset');
EOM
		if ($Dataset ne "N/A") {print OUT "$SqlStatement";}
	}
}
close OUT;
system "$ENV{'ED'} $F1"

#Term	Relationship	Datasets	extURI
__DATA__
Term	Relationship	Datasets	extURI
Health	isMentionedIn	The Impacts of Climate Change on Human Health in the United States: A Scientific Assessment	report/usgcrp-climate-human-health-assessment-2016
Extreme Weather	isMentionedIn	Chapter 4 : Impacts of Extreme Events on Human Health	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events
Extreme Weather	isMentionedIn	Tropical cyclone hazards in the USA (91c3ced0)	article/10.1111/j.1749-8198.2011.00439.x
Extreme Weather	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season (c43fa066)	article/10.1007/s00484-010-0370-9
Extreme Weather	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Extreme Weather	isMentionedIn	chapter nca3 chapter 4 : Energy Supply and Use (686dd899)	report/nca3/chapter/energy-supply-and-use
Extreme Weather	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Extreme Weather	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Extreme Weather	isMentionedIn	Interdependencies of urban climate change impacts and adaptation strategies: a case study of Metropolitan Boston USA (df8dbdfc)	article/10.1007/s10584-007-9252-5
Extreme Weather	isMentionedIn	chapter nca3 chapter 11 : Urban Systems, Infrastructure, and Vulnerability (5a79e12b)	report/nca3/chapter/urban-systems-infrastructure-vulnerability
Extreme Weather	isMentionedIn	Estimated Deaths and Billion Dollar Losses from Extreme Weather Events in the U.S. 2004-2013	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/estimated-deaths-and-billion-dollar-losses-from-extreme-weather-events-in-the-us-2004-2013
Extreme Weather	isMentionedIn	webpage Weather Fatalities (a1b08f2f)	webpage/f1a61f43-0119-4163-8c7a-36e2dc787687
Extreme Weather	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Extreme Weather	isMentionedIn	A review of the potential impacts of climate change on surface water quality (f60a6281)	article/10.1623/hysj.54.1.101
Human Vulnerability	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Human Vulnerability	isMentionedIn	Reducing hazard vulnerability: Towards a common approach between disaster risk reduction and climate adaptation	reference/10bcb504-9827-448d-affd-266276e268f7
Human Vulnerability	isMentionedIn	Vulnerability to flooding: Health and social dimensions	reference/874d657c-f3a1-48f8-b76a-13416e47f666
Human Vulnerability	isMentionedIn	Disaster management and populations with special needs	reference/61b95c91-09b7-4f17-b551-dce616662ae6
Human Vulnerability	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Human Vulnerability	isMentionedIn	Interdependencies of urban climate change impacts and adaptation strategies: a case study of Metropolitan Boston USA (df8dbdfc)	article/10.1007/s10584-007-9252-5
Human Vulnerability	isMentionedIn	chapter nca3 chapter 14 : Rural Communities (d57129df)	report/nca3/chapter/rural
Human Vulnerability	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Human Vulnerability	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Human Vulnerability	isMentionedIn	Disaster Management Handbook (61b95c91)	book/2b3cd768-5f2e-4ed4-b75a-df1f2675ecfe
Human Vulnerability	isMentionedIn	Heat Stress and Public Health: A Critical Review (b00a1349)	article/10.1146/annurev.publhealth.29.020907.090843
Human Vulnerability	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Human Vulnerability	isMentionedIn	Lights Out (dd072932)	article/10.1097/EDE.0b013e318245c61c
Human Vulnerability	isMentionedIn	Providing shelter to nursing home evacuees in disasters: Lessons from Hurricane Katrina (81e4da11)	article/10.2105/ajph.2006.107748
Human Vulnerability	isMentionedIn	Health of the homeless and climate change (6a74b0ff)	article/10.1007/s11524-009-9354-7
Human Vulnerability	isMentionedIn	Fuel poverty and human health: A review of recent evidence (fd7edbac)	article/10.1016/j.enpol.2010.01.037
Human Vulnerability	isMentionedIn	Heat or eat? Cold-weather shocks and nutrition in poor american families (8204e372)	article/10.2105/AJPH.93.7.1149
Human Vulnerability	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Socioeconomic Risks	isMentionedIn	Estimated Deaths and Billion Dollar Losses from Extreme Weather Events in the U.S. 2004-2013	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/estimated-deaths-and-billion-dollar-losses-from-extreme-weather-events-in-the-us-2004-2013
Socioeconomic Risks	isMentionedIn	webpage Weather Fatalities (a1b08f2f)	webpage/f1a61f43-0119-4163-8c7a-36e2dc787687
Socioeconomic Risks	isMentionedIn	US billion-dollar weather and climate disasters: Data sources, trends, accuracy and biases (4fe32146)	article/10.1007/s11069-013-0566-5
Socioeconomic Risks	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Socioeconomic Risks	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Socioeconomic Risks	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods	reference/c4dc57e5-707f-4967-ab31-2b6e2b94fde5
Socioeconomic Risks	isMentionedIn	Floods and human health: A systematic review	reference/57f88e8c-2e4f-4e00-91e8-aea256ca3128
Socioeconomic Risks	isMentionedIn	Health impacts of floods	reference/60be18ee-b5bc-4503-8f77-102561b193fb
Poverty	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change	reference/089d8050-f4c8-4d07-bc35-25bf61691be3
Poverty	isMentionedIn	Climate change: The public health response	reference/3f2402c5-22aa-4f75-861e-f6aca127cd1f
Poverty	isMentionedIn	Socioeconomic vulnerability and adaptation to environmental risk: A case study of climate change and flooding in Bangladesh	reference/3630cebb-db86-453e-90b7-4cf9c061d47e
Health Risks	isMentionedIn	A review of the potential impacts of climate change on surface water quality (f60a6281)	article/10.1623/hysj.54.1.101
Health Risks	isMentionedIn	Climate Change: The Public Health Response (3f2402c5)	article/10.2105/AJPH.2007.119362
Health Risks	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods (c4dc57e5)	article/10.3390/ijerph10127015
Health Risks	isMentionedIn	chapter nca3 chapter 9 : Human Health (61fd6e32)	report/nca3/chapter/human-health
Health Risks	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Health Risks	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Health Risks	isMentionedIn	Primary Protection: Enhancing Health Care Resilience for a Changing Climate	reference/05ee299b-0f67-41b4-98c8-7f06718799fc
Health Risks	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods	reference/c4dc57e5-707f-4967-ab31-2b6e2b94fde5
Health Risks	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season (c43fa066)	article/10.1007/s00484-010-0370-9
Health Risks	isMentionedIn	The health impacts of windstorms: A systematic literature review (aa29148e)	article/10.1016/j.puhe.2013.09.022
Health Risks	isMentionedIn	Providing continuity of care for chronic diseases in the aftermath of Katrina: From field experience to policy recommendations (858d9e98)	article/10.1097/DMP.0b013e3181b66ae4
Health Risks	isMentionedIn	Missed dialysis sessions and hospitalization in hemodialysis patients after Hurricane Katrina (692dfb63)	article/10.1038/ki.2009.5
Health Risks	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Health Risks	isMentionedIn	Health impacts of floods (60be18ee)	article/10.1017/S1049023X00008141
Health Risks	isMentionedIn	Water quality parameters of a Nebraska reservoir differ between drought and normal conditions (54b0ebb2)	article/10.1080/07438141.2011.601401
Health Risks	isMentionedIn	Impact of summer droughts on water quality of the Rhine River - a preview of climate change? (6a9eaa35)	article/10.2166/wst.2007.535
Health Risks	isMentionedIn	Impacts of climate change on surface water quality in relation to drinking water production (8c50c794)	article/10.1016/j.envint.2009.07.001
Health Risks	isMentionedIn	Impact of summer droughts on the water quality of the Meuse river (b6607393)	article/10.1016/j.jhydrol.2008.01.001
Health Risks	isMentionedIn	chapter nca3 chapter 20 : Southwest (99baa64e)	report/nca3/chapter/southwest
Health Risks	isMentionedIn	Driving blind: Weather-related vision hazards and fatal motor vehicle crashes (bc6db90e)	article/10.1175/BAMS-D-14-00026.1
Health Risks	isMentionedIn	Woodsmoke health effects: A review (35bb9e8b)	article/10.1080/08958370600985875
Health Risks	isMentionedIn	Health impacts of fire smoke inhalation (9cdc89b2)	article/10.1080/08958370801975311
Health Risks	isMentionedIn	Birth Weight following Pregnancy during the 2003 Southern California Wildfires (d2b28363)	article/10.1289/ehp.1104515
Health Risks	isMentionedIn	Extreme air pollution events from bushfires and dust storms and their association with mortality in Sydney, Australia 1994�2007 (a31388fc)	article/10.1016/j.envres.2011.05.007
Health Risks	isMentionedIn	Time series analysis of fine particulate matter and asthma reliever dispensations in populations affected by forest fires (8a6d6f43)	article/10.1186/1476-069X-12-11
Health Risks	isMentionedIn	Three Measures of Forest Fire Smoke Exposure and Their Associations with Respiratory and Cardiovascular Health Outcomes in a Population-Based Cohort (250b4ec3)	article/10.1289/ehp.1002288
Health Risks	isMentionedIn	Measures of forest fire smoke exposure and their associations with respiratory health outcomes (3f73c3f1)	article/10.1097/ACI.0b013e328353351f
Health Risks	isMentionedIn	Communicating about smoke from wildland fire: Challenges and opportunities for managers (c8a01a08)	article/10.1007/s00267-014-0312-0
Health Risks	isMentionedIn	The hidden cost of wildfires: Economic valuation of health effects of wildfire smoke exposure in Southern California (4ee18e43)	article/10.1016/j.jfe.2011.05.002
Health Risks	isMentionedIn	Smoke-impacted regional haze in California during the summer of 2002 (d0bcbc01)	article/10.1016/j.agrformet.2006.01.011
Health Risks	isMentionedIn	Non-accidental health impacts of wildfire smoke (bf639de9)	article/10.3390/ijerph111111772
Health Risks	isMentionedIn	Particle size-dependent radical generation from wildland fire smoke (107c077e)	article/10.1016/j.tox.2007.04.008
Health Risks	isMentionedIn	Medical events during the 2009 Los Angeles County Station fire: Lessons for wildfire EMS planning (064a28ed)	article/10.3109/10903127.2011.598607
Health Risks	isMentionedIn	A screening-level assessment of the health risks of chronic smoke exposure for wildland firefighters (a1fb85fd)	article/10.1080/15459620490442500
Health Risks	isMentionedIn	Tropical cyclone hazards in the USA (91c3ced0)	article/10.1111/j.1749-8198.2011.00439.x
Health Risks	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Health Risks	isMentionedIn	Neither rain nor hail nor sleet nor snow: Provider perspectives on the challenges of weather for home and community care (53acdf32)	article/10.1016/j.socscimed.2008.11.022
Health Risks	isMentionedIn	Lights Out (dd072932)	article/10.1097/EDE.0b013e318245c61c
Health Risks	isMentionedIn	Health impact in New York City during the Northeastern blackout of 2003 (9a6c7a87)	article/health-impact-new-york-city-during-northeastern-blackout-2003
Health Risks	isMentionedIn	An outbreak of carbon monoxide poisoning after a major ice storm in Maine (ad3c4329)	article/10.1016/S0736-4679(99)00184-5
Health Risks	isMentionedIn	A review of disaster-related carbon monoxide poisoning: Surveillance, epidemiology, and opportunities for prevention (eec8bc7b)	article/10.2105/ajph.2012.300674
Health Risks	isMentionedIn	Carbon monoxide poisoning after an ice storm in Kentucky, 2009 (d887debf)	article/carbon-monoxide-poisoning-after-an-ice-storm-kentucky-2009
Health Risks	isMentionedIn	Providing shelter to nursing home evacuees in disasters: Lessons from Hurricane Katrina (81e4da11)	article/10.2105/ajph.2006.107748
Health Risks	isMentionedIn	Climate change and occupational safety and health: Establishing a preliminary framework (e3439854)	article/10.1080/15459620903066008
Health Risks	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Health Risks	isMentionedIn	Hurricane Katrina's first responders: The struggle to protect and serve in the aftermath of the disaster (895a462d)	article/10.1001/dmp.2011.53
Health Risks	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Health Risks	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Health Risks	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Resulting Medical Conditions	isMentionedIn	When Every Drop Counts: Protecting Public Health During Drought Conditions—A Guide for Public Health Professionals	reference/792a6471-f6d3-4e85-bdb8-0e6efe9a24a9
Resulting Medical Conditions	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Resulting Medical Conditions	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Resulting Medical Conditions	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season (c43fa066)	article/10.1007/s00484-010-0370-9
Resulting Medical Conditions	isMentionedIn	The health impacts of windstorms: A systematic literature review (aa29148e)	article/10.1016/j.puhe.2013.09.022
Resulting Medical Conditions	isMentionedIn	Providing continuity of care for chronic diseases in the aftermath of Katrina: From field experience to policy recommendations (858d9e98)	article/10.1097/DMP.0b013e3181b66ae4
Resulting Medical Conditions	isMentionedIn	Missed dialysis sessions and hospitalization in hemodialysis patients after Hurricane Katrina (692dfb63)	article/10.1038/ki.2009.5
Resulting Medical Conditions	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Resulting Medical Conditions	isMentionedIn	Health impacts of floods (60be18ee)	article/10.1017/S1049023X00008141
Resulting Medical Conditions	isMentionedIn	Driving blind: Weather-related vision hazards and fatal motor vehicle crashes (bc6db90e)	article/10.1175/BAMS-D-14-00026.1
Resulting Medical Conditions	isMentionedIn	Woodsmoke health effects: A review (35bb9e8b)	article/10.1080/08958370600985875
Resulting Medical Conditions	isMentionedIn	Health impacts of fire smoke inhalation (9cdc89b2)	article/10.1080/08958370801975311
Resulting Medical Conditions	isMentionedIn	Birth Weight following Pregnancy during the 2003 Southern California Wildfires (d2b28363)	article/10.1289/ehp.1104515
Resulting Medical Conditions	isMentionedIn	Extreme air pollution events from bushfires and dust storms and their association with mortality in Sydney, Australia 1994�2007 (a31388fc)	article/10.1016/j.envres.2011.05.007
Resulting Medical Conditions	isMentionedIn	Time series analysis of fine particulate matter and asthma reliever dispensations in populations affected by forest fires (8a6d6f43)	article/10.1186/1476-069X-12-11
Resulting Medical Conditions	isMentionedIn	Three Measures of Forest Fire Smoke Exposure and Their Associations with Respiratory and Cardiovascular Health Outcomes in a Population-Based Cohort (250b4ec3)	article/10.1289/ehp.1002288
Resulting Medical Conditions	isMentionedIn	Measures of forest fire smoke exposure and their associations with respiratory health outcomes (3f73c3f1)	article/10.1097/ACI.0b013e328353351f
Resulting Medical Conditions	isMentionedIn	Communicating about smoke from wildland fire: Challenges and opportunities for managers (c8a01a08)	article/10.1007/s00267-014-0312-0
Resulting Medical Conditions	isMentionedIn	The hidden cost of wildfires: Economic valuation of health effects of wildfire smoke exposure in Southern California (4ee18e43)	article/10.1016/j.jfe.2011.05.002
Resulting Medical Conditions	isMentionedIn	Smoke-impacted regional haze in California during the summer of 2002 (d0bcbc01)	article/10.1016/j.agrformet.2006.01.011
Resulting Medical Conditions	isMentionedIn	Non-accidental health impacts of wildfire smoke (bf639de9)	article/10.3390/ijerph111111772
Resulting Medical Conditions	isMentionedIn	Particle size-dependent radical generation from wildland fire smoke (107c077e)	article/10.1016/j.tox.2007.04.008
Resulting Medical Conditions	isMentionedIn	Medical events during the 2009 Los Angeles County Station fire: Lessons for wildfire EMS planning (064a28ed)	article/10.3109/10903127.2011.598607
Resulting Medical Conditions	isMentionedIn	A screening-level assessment of the health risks of chronic smoke exposure for wildland firefighters (a1fb85fd)	article/10.1080/15459620490442500
Resulting Medical Conditions	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Traumatic Injury	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Traumatic Injury	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Traumatic Injury	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Frost Bite	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Frost Bite	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Frost Bite	isMentionedIn	Are we prepared yet for the extremes of weather changes? Emergence of several severe frostbite cases in Louisiana	reference/a9273613-8dc2-42d4-a6ff-5b9a32e5d59e
Frost Bite	isMentionedIn	Hypothermia fatalities in a temperate climate: Sydney, Australia	reference/a2d2f868-aa28-4f99-b3c0-6f5bc9c8c2fc
Hypothermia	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Hypothermia	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Hypothermia	isMentionedIn	Are we prepared yet for the extremes of weather changes? Emergence of several severe frostbite cases in Louisiana	reference/a9273613-8dc2-42d4-a6ff-5b9a32e5d59e
Hypothermia	isMentionedIn	Hypothermia fatalities in a temperate climate: Sydney, Australia	reference/a2d2f868-aa28-4f99-b3c0-6f5bc9c8c2fc
Hypothermia	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Hypothermia	isMentionedIn	Floods and human health: A systematic review	reference/57f88e8c-2e4f-4e00-91e8-aea256ca3128
Hypothermia	isMentionedIn	Health impacts of floods	reference/60be18ee-b5bc-4503-8f77-102561b193fb
Asphyxiation			
Carbon Monoxide Poisoning	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Carbon Monoxide Poisoning	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Carbon Monoxide Poisoning	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Carbon Monoxide Poisoning	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season	reference/c43fa066-6d7b-481b-9a85-22da8c27243a
Carbon Monoxide Poisoning	isMentionedIn	The health impacts of windstorms: A systematic literature review (aa29148e)	reference/aa29148e-c86c-443d-9c1d-5a1d7fbc3437
Carbon Monoxide Poisoning	isMentionedIn	An outbreak of carbon monoxide poisoning after a major ice storm in Maine	reference/ad3c4329-eac0-47ea-8342-be6ca602610c
Carbon Monoxide Poisoning	isMentionedIn	A review of disaster-related carbon monoxide poisoning: Surveillance, epidemiology, and opportunities for prevention	reference/eec8bc7b-93a6-4b99-92e7-18bf3e25bc9d
Carbon Monoxide Poisoning	isMentionedIn	Carbon monoxide poisoning after an ice storm in Kentucky, 2009	reference/d887debf-59d6-423b-8f0f-433b49f9c9ca
Respiratory Impacts	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Respiratory Impacts	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Respiratory Impacts	isMentionedIn	Non-accidental health impacts of wildfire smoke	reference/bf639de9-c45a-40d0-a115-5b1a5e45e5ee
Respiratory Impacts	isMentionedIn	Particle size-dependent radical generation from wildland fire smoke	reference/107c077e-4d44-49d7-99a5-84a81f62b7e0
Respiratory Impacts	isMentionedIn	Fate and effects of acrolein	reference/0b6fe967-f0e2-4827-9fd3-2019caf5b4b9
Respiratory Impacts	isMentionedIn	Medical events during the 2009 Los Angeles County Station fire: Lessons for wildfire EMS planning	reference/064a28ed-78a7-4e9c-b27f-052db874e800
Respiratory Impacts	isMentionedIn	A screening-level assessment of the health risks of chronic smoke exposure for wildland firefighters	reference/a1fb85fd-306f-4b7a-8eb1-13925bc31f94
Respiratory Impacts	isMentionedIn	Hospital admissions for asthma and acute bronchitis in El Paso, Texas: Do age, sex, and insurance status modify the effects of dust and low wind events?	reference/f8e45aeb-8abe-4834-93f1-cfd656f62493
Respiratory Impacts	isMentionedIn	Surveillance for dust storms and respiratory diseases in Washington State, 1991	reference/bc026ba5-a282-4ad2-9fa0-396bb407012f
Respiratory Impacts	isMentionedIn	Multilobar lung infiltrates after exposure to dust storm: The haboob lung syndrome	reference/ee7b5baa-9199-4319-8391-b6f05cbf1748
Respiratory Impacts	isMentionedIn	When Every Drop Counts: Protecting Public Health During Drought Conditions—A Guide for Public Health Professionals	reference/792a6471-f6d3-4e85-bdb8-0e6efe9a24a9
Respiratory Impacts	isMentionedIn	Woodsmoke health effects: A review	reference/35bb9e8b-e26b-4d68-85a3-c6fcbf8a7e6f
Respiratory Impacts	isMentionedIn	Health impacts of fire smoke inhalation	reference/9cdc89b2-5f7e-4739-9bf6-788268921e03
Respiratory Impacts	isMentionedIn	Birth Weight following Pregnancy during the 2003 Southern California Wildfires	reference/d2b28363-411c-4444-9b05-8204ff607e36
Respiratory Impacts	isMentionedIn	Extreme air pollution events from bushfires and dust storms and their association with mortality in Sydney, Australia 1994�2007	reference/a31388fc-07fd-4ca6-a6a4-7dc7b207e14a
Respiratory Impacts	isMentionedIn	Time series analysis of fine particulate matter and asthma reliever dispensations in populations affected by forest fires	reference/8a6d6f43-acbf-4127-8912-10071eda9093
Respiratory Impacts	isMentionedIn	Three Measures of Forest Fire Smoke Exposure and Their Associations with Respiratory and Cardiovascular Health Outcomes in a Population-Based Cohort	reference/250b4ec3-1264-4570-8417-c00e6d8752a8
Respiratory Impacts	isMentionedIn	Measures of forest fire smoke exposure and their associations with respiratory health outcomes	reference/3f73c3f1-422d-44f0-8b31-889628464021
Respiratory Impacts	isMentionedIn	Changes in weather and climate extremes: State of knowledge relevant to air and water quality in the United States	reference/eec73554-f1d8-4ab5-a618-c395429c086d
Respiratory Impacts	isMentionedIn	Responses of wind erosion to climate-induced vegetation changes on the Colorado Plateau	reference/ea9e8c20-fe7c-4a4e-b628-91ac3d300fb8
Respiratory Impacts	isMentionedIn	Integrated Science Assessment for Particulate Matter	reference/f7ffc8dd-70ec-4779-817a-b2985c0779e7
Respiratory Impacts	isMentionedIn	The role of airborne mineral dusts in human disease	reference/89988c29-d249-437e-a15b-be7f1c03ab30
Respiratory Impacts	isMentionedIn	Chronic particulate exposure, mortality, and coronary heart disease in the Nurses' Health Study	reference/652d2c45-8a4c-43e5-bc6e-fd3d4b120be9
Disease Spread	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Disease Spread	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Disease Spread	isMentionedIn	Global warming will bring new fungal diseases for mammals	reference/64d84ae7-e105-485a-907b-52a9ba985039
Burns	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Burns	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Burns	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Burns	isMentionedIn	Floods and human health: A systematic review	reference/57f88e8c-2e4f-4e00-91e8-aea256ca3128
Burns	isMentionedIn	Health impacts of floods	reference/60be18ee-b5bc-4503-8f77-102561b193fb
Burns	isMentionedIn	Non-accidental health impacts of wildfire smoke	reference/bf639de9-c45a-40d0-a115-5b1a5e45e5ee
Burns	isMentionedIn	Particle size-dependent radical generation from wildland fire smoke	reference/107c077e-4d44-49d7-99a5-84a81f62b7e0
Burns	isMentionedIn	Fate and effects of acrolein	reference/0b6fe967-f0e2-4827-9fd3-2019caf5b4b9
Burns	isMentionedIn	Medical events during the 2009 Los Angeles County Station fire: Lessons for wildfire EMS planning	reference/064a28ed-78a7-4e9c-b27f-052db874e800
Burns	isMentionedIn	A screening-level assessment of the health risks of chronic smoke exposure for wildland firefighters	reference/a1fb85fd-306f-4b7a-8eb1-13925bc31f94
Burns	isMentionedIn	Woodsmoke health effects: A review	reference/35bb9e8b-e26b-4d68-85a3-c6fcbf8a7e6f
Drowning	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Drowning	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Drowning	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Drowning	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Drowning	isMentionedIn	Floods and human health: A systematic review	reference/57f88e8c-2e4f-4e00-91e8-aea256ca3128
Drowning	isMentionedIn	Health impacts of floods	reference/60be18ee-b5bc-4503-8f77-102561b193fb
Drowning	isMentionedIn	Fatalities in the United States from Atlantic tropical cyclones: New data and interpretation	reference/f5411bf4-3e63-48b1-8dfa-1db41f90cf4d
Drowning	isMentionedIn	Atlantic hurricane season of 2005	reference/cc6cb487-ba29-472e-bcd9-8b0354ddcf29
Drowning	isMentionedIn	Hurricane Katrina deaths, Louisiana, 2005	reference/80a8c9f1-d21b-4ee0-a6c0-37131b84c269
Drowning	isMentionedIn	Deaths associated with Hurricane Sandy - October-November 2012	reference/972db4a7-c717-47fc-9996-6c1a419c776e
Drowning	isMentionedIn	Service Assessment: Hurricane/Post-Tropical Cyclone Sandy, October 22–29, 2012	reference/54b7a268-2389-4bc6-b0c5-543d583c7f68
Wound Infection	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Wound Infection	isMentionedIn	Floods and human health: A systematic review	reference/57f88e8c-2e4f-4e00-91e8-aea256ca3128
Existing Medical Conditions	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Existing Medical Conditions	isMentionedIn	Preventing cold-related morbidity and mortality in a changing climate	reference/33bdc93c-e333-4694-af8e-f982e9396ef8
Existing Medical Conditions	isMentionedIn	Disaster management and populations with special needs	reference/61b95c91-09b7-4f17-b551-dce616662ae6
Existing Medical Conditions	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods	reference/c4dc57e5-707f-4967-ab31-2b6e2b94fde5
Existing Medical Conditions	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Existing Medical Conditions	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season (c43fa066)	article/10.1007/s00484-010-0370-9
Existing Medical Conditions	isMentionedIn	The health impacts of windstorms: A systematic literature review (aa29148e)	article/10.1016/j.puhe.2013.09.022
Existing Medical Conditions	isMentionedIn	Providing continuity of care for chronic diseases in the aftermath of Katrina: From field experience to policy recommendations (858d9e98)	article/10.1097/DMP.0b013e3181b66ae4
Existing Medical Conditions	isMentionedIn	Missed dialysis sessions and hospitalization in hemodialysis patients after Hurricane Katrina (692dfb63)	article/10.1038/ki.2009.5
Existing Medical Conditions	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Existing Medical Conditions	isMentionedIn	Health impacts of floods (60be18ee)	article/10.1017/S1049023X00008141
Existing Medical Conditions	isMentionedIn	Three Measures of Forest Fire Smoke Exposure and Their Associations with Respiratory and Cardiovascular Health Outcomes in a Population-Based Cohort (250b4ec3)	article/10.1289/ehp.1002288
Existing Medical Conditions	isMentionedIn	The relationship of respiratory and cardiovascular hospital admissions to the southern California wildfires of 2003 (1a72beb2)	article/10.1136/oem.2008.041376
Existing Medical Conditions	isMentionedIn	Peat bog wildfire smoke exposure in rural North Carolina is associated with cardiopulmonary emergency department visits assessed through syndromic surveillance (47451452)	article/10.1289/ehp.1003206
Existing Medical Conditions	isMentionedIn	Disaster Management Handbook (61b95c91)	book/2b3cd768-5f2e-4ed4-b75a-df1f2675ecfe
Existing Medical Conditions	isMentionedIn	Heat Stress and Public Health: A Critical Review (b00a1349)	article/10.1146/annurev.publhealth.29.020907.090843
Existing Medical Conditions	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Existing Medical Conditions	isMentionedIn	Lights Out (dd072932)	article/10.1097/EDE.0b013e318245c61c
Existing Medical Conditions	isMentionedIn	Providing shelter to nursing home evacuees in disasters: Lessons from Hurricane Katrina (81e4da11)	article/10.2105/ajph.2006.107748
Existing Medical Conditions	isMentionedIn	Health of the homeless and climate change (6a74b0ff)	article/10.1007/s11524-009-9354-7
Existing Medical Conditions	isMentionedIn	Fuel poverty and human health: A review of recent evidence (fd7edbac)	article/10.1016/j.enpol.2010.01.037
Existing Medical Conditions	isMentionedIn	Heat or eat? Cold-weather shocks and nutrition in poor american families (8204e372)	article/10.2105/AJPH.93.7.1149
Mental Illness	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Mental Illness	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Mental Illness	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season (c43fa066)	article/10.1007/s00484-010-0370-9
Mental Illness	isMentionedIn	The health impacts of windstorms: A systematic literature review (aa29148e)	article/10.1016/j.puhe.2013.09.022
Mental Illness	isMentionedIn	Providing continuity of care for chronic diseases in the aftermath of Katrina: From field experience to policy recommendations (858d9e98)	article/10.1097/DMP.0b013e3181b66ae4
Mental Illness	isMentionedIn	Missed dialysis sessions and hospitalization in hemodialysis patients after Hurricane Katrina (692dfb63)	article/10.1038/ki.2009.5
Mental Illness	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Mental Illness	isMentionedIn	Health impacts of floods (60be18ee)	article/10.1017/S1049023X00008141
Mental Illness	isMentionedIn	Health effects of drought: A systematic review of the evidence (cd642a0a)	article/10.1371/currents.dis.7a2cee9e980f91ad7697b570bcc4b004
Mental Illness	isMentionedIn	Hope, despair and transformation: climate change and the promotion of mental health and wellbeing (9845a991)	article/10.1186/1752-4458-2-13
Mental Illness	isMentionedIn	Drought as a mental health exposure (e24d8f4b)	article/10.1016/j.envres.2014.03.014
Mental Illness	isMentionedIn	In their own words: Young people's mental health in drought-affected rural and remote NSW (dcb9ec60)	article/10.1111/j.1440-1584.2011.01224.x
Mental Illness	isMentionedIn	Suicide and drought in New South Wales, Australia, 1970�2007 (c22caf01)	article/10.1073/pnas.1112965109
Mental Illness	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Mental Illness	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Mental Illness	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Mental Illness	isMentionedIn	Six climate change-related events in the United States accounted for about $14 billion in lost lives and health costs	reference/21f384a2-0dcf-4c1a-b1c0-add8b0e7506c
Mental Illness	isMentionedIn	The hidden cost of wildfires: Economic valuation of health effects of wildfire smoke exposure in Southern California	reference/4ee18e43-0d8d-4276-ad51-b87db1d8b7bc
Mental Illness	isMentionedIn	Respiratory and mental health effects of wildfires: An ecological study in Galician municipalities (north-west Spain)	reference/a2d07119-7558-405f-a9f5-d60377d86fa9
Mental Illness	isMentionedIn	Psychological impact of fire disaster on children and their parents	reference/6c12241f-e08a-45dc-a625-c0317dece21e
Stress Disorders			
Chronic Disease			
Asthma	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Asthma	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Asthma	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Asthma	isMentionedIn	Floods and human health: A systematic review	reference/57f88e8c-2e4f-4e00-91e8-aea256ca3128
Asthma	isMentionedIn	Health impacts of floods	reference/60be18ee-b5bc-4503-8f77-102561b193fb
Asthma	isMentionedIn	Ariborne mold and endotoxin concentrations in New Orleans, Louisiana, after flooding, October through November 2005	reference/a018e131-9ae9-4a2f-9fb8-064a5190e9f3
Asthma	isMentionedIn	Three Measures of Forest Fire Smoke Exposure and Their Associations with Respiratory and Cardiovascular Health Outcomes in a Population-Based Cohort	reference/250b4ec3-1264-4570-8417-c00e6d8752a8
Asthma	isMentionedIn	The relationship of respiratory and cardiovascular hospital admissions to the southern California wildfires of 2003	reference/1a72beb2-f4a0-4db9-bac8-eac55cbf676d
Asthma	isMentionedIn	Peat bog wildfire smoke exposure in rural North Carolina is associated with cardiopulmonary emergency department visits assessed through syndromic surveillance	reference/47451452-d69e-4cd8-9565-7151ba299836
Asthma	isMentionedIn	Wildfire smoke and respiratory symptoms in patients with chronic obstructive pulmonary disease	reference/d3d2c446-5226-4d2d-86e3-715ef904949c
Asthma	isMentionedIn	Fields and forests in flames: Vegetation smoke and human health	reference/395ba272-7543-4f62-b731-f0d0c933ae51
Populations at Risk	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Populations at Risk	isMentionedIn	Disaster management and populations with special needs	reference/61b95c91-09b7-4f17-b551-dce616662ae6
Populations at Risk	isMentionedIn	Fields and forests in flames: Vegetation smoke and human health	reference/395ba272-7543-4f62-b731-f0d0c933ae51
Populations at Risk	isMentionedIn	Hispanic health disparities after a flood disaster: Results of a population-based survey of individuals experiencing home site damage in El Paso (Texas, USA)	reference/f9399ac9-ce3e-43fc-9b99-654a5786f2e9
Populations at Risk	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Populations at Risk	isMentionedIn	Disaster Management Handbook (61b95c91)	book/2b3cd768-5f2e-4ed4-b75a-df1f2675ecfe
Populations at Risk	isMentionedIn	Heat Stress and Public Health: A Critical Review (b00a1349)	article/10.1146/annurev.publhealth.29.020907.090843
Populations at Risk	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Populations at Risk	isMentionedIn	Lights Out (dd072932)	article/10.1097/EDE.0b013e318245c61c
Populations at Risk	isMentionedIn	Providing shelter to nursing home evacuees in disasters: Lessons from Hurricane Katrina (81e4da11)	article/10.2105/ajph.2006.107748
Populations at Risk	isMentionedIn	Health of the homeless and climate change (6a74b0ff)	article/10.1007/s11524-009-9354-7
Populations at Risk	isMentionedIn	Fuel poverty and human health: A review of recent evidence (fd7edbac)	article/10.1016/j.enpol.2010.01.037
Populations at Risk	isMentionedIn	Heat or eat? Cold-weather shocks and nutrition in poor american families (8204e372)	article/10.2105/AJPH.93.7.1149
Populations at Risk	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods (c4dc57e5)	article/10.3390/ijerph10127015
Populations at Risk	isMentionedIn	Climate change and occupational safety and health: Establishing a preliminary framework (e3439854)	article/10.1080/15459620903066008
Populations at Risk	isMentionedIn	Hurricane Katrina's first responders: The struggle to protect and serve in the aftermath of the disaster (895a462d)	article/10.1001/dmp.2011.53
Populations at Risk	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Populations at Risk	isMentionedIn	The relationship of respiratory and cardiovascular hospital admissions to the southern California wildfires of 2003	reference/1a72beb2-f4a0-4db9-bac8-eac55cbf676d
Populations at Risk	isMentionedIn	Non-accidental health impacts of wildfire smoke	reference/bf639de9-c45a-40d0-a115-5b1a5e45e5ee
Populations at Risk	isMentionedIn	Health effects of the 2003 southern California wildfires on children	reference/5d3a9428-c81f-4c38-bda4-0b475b07d947
Populations at Risk	isMentionedIn	Hospital admissions for asthma and acute bronchitis in El Paso, Texas: Do age, sex, and insurance status modify the effects of dust and low wind events?	reference/f8e45aeb-8abe-4834-93f1-cfd656f62493
Populations at Risk	isMentionedIn	Surveillance for dust storms and respiratory diseases in Washington State, 1991	reference/bc026ba5-a282-4ad2-9fa0-396bb407012f
Populations at Risk	isMentionedIn	Multilobar lung infiltrates after exposure to dust storm: The haboob lung syndrome	reference/ee7b5baa-9199-4319-8391-b6f05cbf1748
Populations at Risk	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Medication Dependent	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Medication Dependent	isMentionedIn	Disaster preparedness and the chronic disease needs of vulnerable older adults	reference/ff8e7640-84e8-4d99-96d4-d32339a9263f
Medication Dependent	isMentionedIn	Disaster management and populations with special needs	reference/61b95c91-09b7-4f17-b551-dce616662ae6
Medication Dependent	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Medication Dependent	isMentionedIn	Disaster Management Handbook (61b95c91)	book/2b3cd768-5f2e-4ed4-b75a-df1f2675ecfe
Medication Dependent	isMentionedIn	Heat Stress and Public Health: A Critical Review (b00a1349)	article/10.1146/annurev.publhealth.29.020907.090843
Medication Dependent	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Medication Dependent	isMentionedIn	Lights Out (dd072932)	article/10.1097/EDE.0b013e318245c61c
Medication Dependent	isMentionedIn	Providing shelter to nursing home evacuees in disasters: Lessons from Hurricane Katrina (81e4da11)	article/10.2105/ajph.2006.107748
Medication Dependent	isMentionedIn	Health of the homeless and climate change (6a74b0ff)	article/10.1007/s11524-009-9354-7
Medication Dependent	isMentionedIn	Fuel poverty and human health: A review of recent evidence (fd7edbac)	article/10.1016/j.enpol.2010.01.037
Medication Dependent	isMentionedIn	Heat or eat? Cold-weather shocks and nutrition in poor american families (8204e372)	article/10.2105/AJPH.93.7.1149
Medication Dependent	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Age	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Age	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Age	isMentionedIn	Disaster Management Handbook (61b95c91)	book/2b3cd768-5f2e-4ed4-b75a-df1f2675ecfe
Age	isMentionedIn	Heat Stress and Public Health: A Critical Review (b00a1349)	article/10.1146/annurev.publhealth.29.020907.090843
Age	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Age	isMentionedIn	Lights Out (dd072932)	article/10.1097/EDE.0b013e318245c61c
Age	isMentionedIn	Providing shelter to nursing home evacuees in disasters: Lessons from Hurricane Katrina (81e4da11)	article/10.2105/ajph.2006.107748
Age	isMentionedIn	Health of the homeless and climate change (6a74b0ff)	article/10.1007/s11524-009-9354-7
Age	isMentionedIn	Fuel poverty and human health: A review of recent evidence (fd7edbac)	article/10.1016/j.enpol.2010.01.037
Age	isMentionedIn	Heat or eat? Cold-weather shocks and nutrition in poor american families (8204e372)	article/10.2105/AJPH.93.7.1149
Age	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Chronic Medical Conditions	isMentionedIn	Disaster preparedness and the chronic disease needs of vulnerable older adults	reference/ff8e7640-84e8-4d99-96d4-d32339a9263f
Chronic Medical Conditions	isMentionedIn	Disaster management and populations with special needs	reference/61b95c91-09b7-4f17-b551-dce616662ae6
Assistance Needed	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Assistance Needed	isMentionedIn	Disaster preparedness and the chronic disease needs of vulnerable older adults	reference/ff8e7640-84e8-4d99-96d4-d32339a9263f
Assistance Needed	isMentionedIn	Disaster management and populations with special needs	reference/61b95c91-09b7-4f17-b551-dce616662ae6
Assistance Needed	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Assistance Needed	isMentionedIn	Disaster Management Handbook (61b95c91)	book/2b3cd768-5f2e-4ed4-b75a-df1f2675ecfe
Assistance Needed	isMentionedIn	Heat Stress and Public Health: A Critical Review (b00a1349)	article/10.1146/annurev.publhealth.29.020907.090843
Assistance Needed	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Assistance Needed	isMentionedIn	Lights Out (dd072932)	article/10.1097/EDE.0b013e318245c61c
Assistance Needed	isMentionedIn	Providing shelter to nursing home evacuees in disasters: Lessons from Hurricane Katrina (81e4da11)	article/10.2105/ajph.2006.107748
Assistance Needed	isMentionedIn	Health of the homeless and climate change (6a74b0ff)	article/10.1007/s11524-009-9354-7
Assistance Needed	isMentionedIn	Fuel poverty and human health: A review of recent evidence (fd7edbac)	article/10.1016/j.enpol.2010.01.037
Assistance Needed	isMentionedIn	Heat or eat? Cold-weather shocks and nutrition in poor american families (8204e372)	article/10.2105/AJPH.93.7.1149
Adaptive Capacity	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Adaptive Capacity	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Adaptive Capacity	isMentionedIn	Disaster Resilience: A National Imperative	reference/d0ca25ff-c211-4ac3-bea8-0dede9fe1a70
Adaptive Capacity	isMentionedIn	Creating healthy communities, healthy homes, healthy people: Initiating a research agenda on the built environment and public health	reference/1ebfdcac-9323-4232-9b1a-db5a13b09fd5
Adaptive Capacity	isMentionedIn	Home is where the harm is: Inadequate housing as a public health crisis	reference/de2bf070-6b2f-4e2e-8bc5-c6af9167ac1d
Adaptive Capacity	isMentionedIn	Poor people, poor places, and poor health: The mediating role of social networks and social capital	reference/aab82d57-06ca-4862-8597-ef2fff0d9269
Adaptive Capacity	isMentionedIn	Distribution of impacts of natural disasters across income groups: A case study of New Orleans	reference/0e4ab3aa-1ad5-40ba-a3f4-ff706330d3a5
Adaptive Capacity	isMentionedIn	Building human resilience: The role of public health preparedness and response as an adaptation to climate change	reference/a33f021d-b087-44d9-8fac-fb9507f789e8
Adaptive Capacity	isMentionedIn	A place-based model for understanding community resilience to natural disasters	reference/19bc2dd3-6c09-4427-82e0-81858eda7c0e
Adaptive Capacity	isMentionedIn	Integrating climate change adaptation into public health practice: Using adaptive management to increase adaptive capacity and build resilience	reference/7f9ac45f-e1d5-4bd5-b55d-c92ef8dcbaaa
Adaptive Capacity	isMentionedIn	Adaptive capacity and its assessment	reference/611d5fd8-8410-485d-a27d-7b9f961778d9
Adaptive Capacity	isMentionedIn	A place-based model for understanding community resilience to natural disasters	reference/19bc2dd3-6c09-4427-82e0-81858eda7c0e
Adaptive Capacity	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Adaptive Capacity	isMentionedIn	Disaster management and populations with special needs	reference/61b95c91-09b7-4f17-b551-dce616662ae6
Adaptive Capacity	isMentionedIn	Heat Stress and Public Health: A Critical Review	reference/b00a1349-fb5f-4e2d-b1bc-cfceb0863de2
Resilience	isMentionedIn	Disaster Resilience: A National Imperative	reference/d0ca25ff-c211-4ac3-bea8-0dede9fe1a70
Resilience	isMentionedIn	Distribution of impacts of natural disasters across income groups: A case study of New Orleans	reference/0e4ab3aa-1ad5-40ba-a3f4-ff706330d3a5
Resilience	isMentionedIn	Building human resilience: The role of public health preparedness and response as an adaptation to climate change	reference/a33f021d-b087-44d9-8fac-fb9507f789e8
Resilience	isMentionedIn	Extreme weather events and the critical importance of anticipatory adaptation and organizational resilience in responding to impacts	reference/266c7d9e-02ce-4ecf-929f-37a25aa07eea
Resilience	isMentionedIn	Adaptation to Climate Change: Linking Disaster Risk Reduction and Insurance	reference/1f4f3b0a-9fcf-4369-9857-2e3bade59a5b
Cognitive Impairments	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Cognitive Impairments	isMentionedIn	Disaster management and populations with special needs	reference/61b95c91-09b7-4f17-b551-dce616662ae6
Cognitive Impairments	isMentionedIn	Heat Stress and Public Health: A Critical Review	reference/b00a1349-fb5f-4e2d-b1bc-cfceb0863de2
Mobility Impairments	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Mobility Impairments	isMentionedIn	Disaster management and populations with special needs	reference/61b95c91-09b7-4f17-b551-dce616662ae6
Mobility Impairments	isMentionedIn	Heat Stress and Public Health: A Critical Review	reference/b00a1349-fb5f-4e2d-b1bc-cfceb0863de2
Chemical Dependence	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Chemical Dependence	isMentionedIn	Disaster management and populations with special needs	reference/61b95c91-09b7-4f17-b551-dce616662ae6
Chemical Dependence	isMentionedIn	Heat Stress and Public Health: A Critical Review	reference/b00a1349-fb5f-4e2d-b1bc-cfceb0863de2
Medical Dependence	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Medical Dependence	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods	reference/c4dc57e5-707f-4967-ab31-2b6e2b94fde5
Medical Dependence	isMentionedIn	Disaster management and populations with special needs	reference/61b95c91-09b7-4f17-b551-dce616662ae6
Medical Dependence	isMentionedIn	Heat Stress and Public Health: A Critical Review	reference/b00a1349-fb5f-4e2d-b1bc-cfceb0863de2
Medical Dependence	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	reference/13d048c9-77d7-4bbb-beeb-ee49842d2719
Medical Dependence	isMentionedIn	Lights out: Impact of the August 2003 power outage on mortality in New York, NY	reference/dd072932-2da1-4e6c-b18a-6f7649969625
Exposure	isMentionedIn	Climate Change: The Public Health Response (3f2402c5)	article/10.2105/AJPH.2007.119362
Exposure	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods (c4dc57e5)	article/10.3390/ijerph10127015
Exposure	isMentionedIn	chapter nca3 chapter 9 : Human Health (61fd6e32)	report/nca3/chapter/human-health
Exposure	isMentionedIn	chapter nca3 chapter 20 : Southwest (99baa64e)	report/nca3/chapter/southwest
Exposure	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Exposure	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Exposure	isMentionedIn	Interdependencies of urban climate change impacts and adaptation strategies: a case study of Metropolitan Boston USA (df8dbdfc)	article/10.1007/s10584-007-9252-5
Exposure	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Exposure	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Exposure	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season (c43fa066)	article/10.1007/s00484-010-0370-9
Exposure	isMentionedIn	The health impacts of windstorms: A systematic literature review (aa29148e)	article/10.1016/j.puhe.2013.09.022
Exposure	isMentionedIn	Providing continuity of care for chronic diseases in the aftermath of Katrina: From field experience to policy recommendations (858d9e98)	article/10.1097/DMP.0b013e3181b66ae4
Exposure	isMentionedIn	Missed dialysis sessions and hospitalization in hemodialysis patients after Hurricane Katrina (692dfb63)	article/10.1038/ki.2009.5
Exposure	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Exposure	isMentionedIn	Health impacts of floods (60be18ee)	article/10.1017/S1049023X00008141
Exposure	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Exposure	isMentionedIn	The role of airborne mineral dusts in human disease	reference/89988c29-d249-437e-a15b-be7f1c03ab30
Exposure	isMentionedIn	Impact of the 2002 Canadian forest fires on particulate matter air quality in Baltimore City	reference/3bfcb39e-f3ee-4d20-8f53-77c8487599b4
Exposure	isMentionedIn	Quantifying wildfires exposure for investigating health-related effects	reference/3302738c-9f7e-46da-8b72-4cb833c37080
Exposure	isMentionedIn	Association of long-term PM2.5 exposure with mortality using different air pollution exposure models: Impacts in rural and urban California	reference/bef7bfab-586e-4b45-91f1-6f42c1409075
Exposure	isMentionedIn	Ambient pollution and heart rate variability	reference/d5324d05-976d-49e4-a928-9f942c2cc9c9
Exposure	isMentionedIn	Relationships Between Fine Particulate Air Pollution, Cardiometabolic Disorders, and Cardiovascular Mortality	reference/3b3ef9ac-3b80-4a9a-9ce3-a7809e5b0862
Exposure	isMentionedIn	Cardiovascular Mortality and Long-Term Exposure to Particulate Air Pollution: Epidemiological Evidence of General Pathophysiological Pathways of Disease	reference/1a0f5be0-ebe9-4984-a376-871b5ace8b12
Exposure	isMentionedIn	Integrated Science Assessment for Particulate Matter	reference/f7ffc8dd-70ec-4779-817a-b2985c0779e7
Exposure	isMentionedIn	Vulnerable populations: Hurricane Katrina as a case study	reference/4ca41ec8-3947-4b36-8a89-79f51e1d7989
Exposure	isMentionedIn	Tropical cyclone hazards in the USA	reference/91c3ced0-65bc-43f7-b50c-11742eb657d5
Exposure	isMentionedIn	Impact of the Red River catastrophic flood on women giving birth in North Dakota, 1994–2000	reference/e0b99ff4-67d8-476e-a2c8-b80cfd53b498
Exposure	isMentionedIn	Exposure to Hurricane Katrina, post-traumatic stress disorder and birth outcomes	reference/515b09d9-e540-4cc5-ab3a-16fbd1d1d52d
Exposure	isMentionedIn	When Every Drop Counts: Protecting Public Health During Drought Conditions—A Guide for Public Health Professionals	reference/792a6471-f6d3-4e85-bdb8-0e6efe9a24a9
Exposure	isMentionedIn	Health effects of drought: A systematic review of the evidence	reference/cd642a0a-9d8e-4c25-a56d-a64260553be6
Exposure	isMentionedIn	Drought-induced amplification and epidemic transmission of West Nile virus in southern Florida	reference/b043eeb2-18ba-4344-b574-9e59aacd6547
Exposure	isMentionedIn	Emergence and persistence of hantaviruses	reference/d774237d-5d86-4dde-91ca-8b51dabf6106
Exposure	isMentionedIn	Factors driving hantavirus emergence in Europe	reference/c0076f84-2a19-435c-a326-efb6f0aa09c6
Exposure	isMentionedIn	Epidemiology of Hantavirus infections in humans: A comprehensive, global overview	reference/f895c7bb-2487-4b77-96e9-0fa249f36002
Exposure	isMentionedIn	Woodsmoke health effects: A review	reference/35bb9e8b-e26b-4d68-85a3-c6fcbf8a7e6f
Exposure	isMentionedIn	Health impacts of fire smoke inhalation	reference/9cdc89b2-5f7e-4739-9bf6-788268921e03
Exposure	isMentionedIn	Birth Weight following Pregnancy during the 2003 Southern California Wildfires	reference/d2b28363-411c-4444-9b05-8204ff607e36
Exposure	isMentionedIn	Extreme air pollution events from bushfires and dust storms and their association with mortality in Sydney, Australia 1994�2007	reference/a31388fc-07fd-4ca6-a6a4-7dc7b207e14a
Exposure	isMentionedIn	Time series analysis of fine particulate matter and asthma reliever dispensations in populations affected by forest fires	reference/8a6d6f43-acbf-4127-8912-10071eda9093
Exposure	isMentionedIn	Three Measures of Forest Fire Smoke Exposure and Their Associations with Respiratory and Cardiovascular Health Outcomes in a Population-Based Cohort	reference/250b4ec3-1264-4570-8417-c00e6d8752a8
Exposure	isMentionedIn	Measures of forest fire smoke exposure and their associations with respiratory health outcomes	reference/3f73c3f1-422d-44f0-8b31-889628464021
Exposure	isMentionedIn	Hospital admissions for asthma and acute bronchitis in El Paso, Texas: Do age, sex, and insurance status modify the effects of dust and low wind events?	reference/f8e45aeb-8abe-4834-93f1-cfd656f62493
Exposure	isMentionedIn	Surveillance for dust storms and respiratory diseases in Washington State, 1991	reference/bc026ba5-a282-4ad2-9fa0-396bb407012f
Exposure	isMentionedIn	Multilobar lung infiltrates after exposure to dust storm: The haboob lung syndrome	reference/ee7b5baa-9199-4319-8391-b6f05cbf1748
Exposure	isMentionedIn	Non-accidental health impacts of wildfire smoke	reference/bf639de9-c45a-40d0-a115-5b1a5e45e5ee
Exposure	isMentionedIn	Particle size-dependent radical generation from wildland fire smoke	reference/107c077e-4d44-49d7-99a5-84a81f62b7e0
Exposure	isMentionedIn	Fate and effects of acrolein	reference/0b6fe967-f0e2-4827-9fd3-2019caf5b4b9
Exposure	isMentionedIn	Medical events during the 2009 Los Angeles County Station fire: Lessons for wildfire EMS planning	reference/064a28ed-78a7-4e9c-b27f-052db874e800
Exposure	isMentionedIn	A screening-level assessment of the health risks of chronic smoke exposure for wildland firefighters	reference/a1fb85fd-306f-4b7a-8eb1-13925bc31f94
Exposure	isMentionedIn	Health of the homeless and climate change	reference/6a74b0ff-705b-433e-8b26-59b7284cca88
Contaminants	isMentionedIn	When Every Drop Counts: Protecting Public Health During Drought Conditions�A Guide for Public Health Professionals (792a6471)	report/epa-wheneverydrop-2010
Contaminants	isMentionedIn	A review of the potential impacts of climate change on surface water quality	reference/f60a6281-fa30-444d-9acd-0d132a6d1683
Contaminants	isMentionedIn	Water quality parameters of a Nebraska reservoir differ between drought and normal conditions	reference/54b0ebb2-d56b-4863-b32f-b8722abc2d32
Contaminants	isMentionedIn	Impact of summer droughts on water quality of the Rhine River - a preview of climate change?	reference/6a9eaa35-c30c-4059-9b6b-331950df3f79
Contaminants	isMentionedIn	Impacts of climate change on surface water quality in relation to drinking water production	reference/8c50c794-b09b-4215-b46c-6c24931faf6e
Contaminants	isMentionedIn	Impact of summer droughts on the water quality of the Meuse river	reference/b6607393-a0f4-47fb-8269-94bd378b6d61
Contaminants	isMentionedIn	Vulnerability of waterborne diseases to climate change in Canada: A review	reference/3b1803a8-da7d-4b78-8ea8-605336acf55b
Contaminants	isMentionedIn	Potential effects of global environmental changes on cryptosporidiosis and giardiasis transmission	reference/2cc8c197-bbfc-4687-a425-8536784a15a1
Contaminants	isMentionedIn	Changes in weather and climate extremes: State of knowledge relevant to air and water quality in the United States (eec73554)	article/10.1080/10962247.2013.851044
Contaminants	isMentionedIn	Responses of wind erosion to climate-induced vegetation changes on the Colorado Plateau (ea9e8c20)	article/10.1073/pnas.1014947108
Contaminants	isMentionedIn	West Nile virus and drought (52d82168)	article/10.1023/a:1015089901425
Contaminants	isMentionedIn	Drought-induced amplification of local and regional West Nile virus infection rates in New Jersey (6c4943e6)	article/10.1603/me12035
Contaminants	isMentionedIn	Hydrologic conditions describe West Nile virus risk in Colorado (c8b9489e)	article/10.3390/ijerph7020494
Contaminants	isMentionedIn	Inter-annual associations between precipitation and human incidence of West Nile Virus in the United States (79d19ab8)	article/10.1089/vbz.2006.0590
Contaminants	isMentionedIn	Dry weather induces outbreaks of human West Nile virus infections (f86c2421)	article/10.1186/1471-2334-10-38
Illness	isMentionedIn	A review of the potential impacts of climate change on surface water quality (f60a6281)	article/10.1623/hysj.54.1.101
Illness	isMentionedIn	Water quality parameters of a Nebraska reservoir differ between drought and normal conditions (54b0ebb2)	article/10.1080/07438141.2011.601401
Illness	isMentionedIn	Impact of summer droughts on water quality of the Rhine River - a preview of climate change? (6a9eaa35)	article/10.2166/wst.2007.535
Illness	isMentionedIn	Impacts of climate change on surface water quality in relation to drinking water production (8c50c794)	article/10.1016/j.envint.2009.07.001
Illness	isMentionedIn	Impact of summer droughts on the water quality of the Meuse river (b6607393)	article/10.1016/j.jhydrol.2008.01.001
Illness	isMentionedIn	When Every Drop Counts: Protecting Public Health During Drought Conditions�A Guide for Public Health Professionals (792a6471)	report/epa-wheneverydrop-2010
Illness	isMentionedIn	Changes in weather and climate extremes: State of knowledge relevant to air and water quality in the United States (eec73554)	article/10.1080/10962247.2013.851044
Illness	isMentionedIn	Responses of wind erosion to climate-induced vegetation changes on the Colorado Plateau (ea9e8c20)	article/10.1073/pnas.1014947108
Illness	isMentionedIn	West Nile virus and drought (52d82168)	article/10.1023/a:1015089901425
Illness	isMentionedIn	Drought-induced amplification of local and regional West Nile virus infection rates in New Jersey (6c4943e6)	article/10.1603/me12035
Illness	isMentionedIn	Hydrologic conditions describe West Nile virus risk in Colorado (c8b9489e)	article/10.3390/ijerph7020494
Illness	isMentionedIn	Inter-annual associations between precipitation and human incidence of West Nile Virus in the United States (79d19ab8)	article/10.1089/vbz.2006.0590
Illness	isMentionedIn	Dry weather induces outbreaks of human West Nile virus infections (f86c2421)	article/10.1186/1471-2334-10-38
Disease Exposure	isMentionedIn	West Nile virus and drought (52d82168)	article/10.1023/a:1015089901425
Disease Exposure	isMentionedIn	Drought-induced amplification and epidemic transmission of West Nile virus in southern Florida	reference/b043eeb2-18ba-4344-b574-9e59aacd6547
Disease Exposure	isMentionedIn	Emergence and persistence of hantaviruses	reference/d774237d-5d86-4dde-91ca-8b51dabf6106
Disease Exposure	isMentionedIn	Factors driving hantavirus emergence in Europe	reference/c0076f84-2a19-435c-a326-efb6f0aa09c6
Disease Exposure	isMentionedIn	Epidemiology of Hantavirus infections in humans: A comprehensive, global overview	reference/f895c7bb-2487-4b77-96e9-0fa249f36002
Disease Exposure	isMentionedIn	Drought-induced amplification of local and regional West Nile virus infection rates in New Jersey (6c4943e6)	article/10.1603/me12035
Disease Exposure	isMentionedIn	Hydrologic conditions describe West Nile virus risk in Colorado (c8b9489e)	article/10.3390/ijerph7020494
Disease Exposure	isMentionedIn	Inter-annual associations between precipitation and human incidence of West Nile Virus in the United States (79d19ab8)	article/10.1089/vbz.2006.0590
Disease Exposure	isMentionedIn	Dry weather induces outbreaks of human West Nile virus infections (f86c2421)	article/10.1186/1471-2334-10-38
Gases and Particulates	isMentionedIn	Toward a more physical representation of precipitation scavenging in global chemistry models: Cloud overlap and ice physics and their impact on tropospheric ozone	reference/b33a1767-eafa-4c24-a1a3-001ba39eb319
Carbon Monoxide	isMentionedIn	Woodsmoke health effects: A review	reference/35bb9e8b-e26b-4d68-85a3-c6fcbf8a7e6f
Carbon Monoxide	isMentionedIn	Health impacts of fire smoke inhalation	reference/9cdc89b2-5f7e-4739-9bf6-788268921e03
Toxic Smoke	isMentionedIn	Woodsmoke health effects: A review	reference/35bb9e8b-e26b-4d68-85a3-c6fcbf8a7e6f
Toxic Smoke	isMentionedIn	Health impacts of fire smoke inhalation	reference/9cdc89b2-5f7e-4739-9bf6-788268921e03
Location	isMentionedIn	Climate Change: The Public Health Response (3f2402c5)	article/10.2105/AJPH.2007.119362
Location	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods (c4dc57e5)	article/10.3390/ijerph10127015
Location	isMentionedIn	chapter nca3 chapter 9 : Human Health (61fd6e32)	report/nca3/chapter/human-health
Location	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Location	isMentionedIn	chapter nca3 chapter 20 : Southwest (99baa64e)	report/nca3/chapter/southwest
Location	isMentionedIn	Interdependencies of urban climate change impacts and adaptation strategies: a case study of Metropolitan Boston USA (df8dbdfc)	article/10.1007/s10584-007-9252-5
Location	isMentionedIn	Sea Level Rise and Nuisance Flood Frequency Changes around the United States (bbf3043e)	report/sea-level-rise-nuisance-flood-frequency-changes-around-united
Location	isMentionedIn	Projected Increases in Very Large Fires	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/projected-increases-in-very-large-fires
Location	isMentionedIn	Climate change presents increased potential for very large fires in the contiguous United States (ca5c4b38)	article/10.1071/WF15083
Rural Communities	isMentionedIn	chapter nca3 chapter 14 : Rural Communities (d57129df)	report/nca3/chapter/rural
Urban Areas	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Urban Areas	isMentionedIn	Interdependencies of urban climate change impacts and adaptation strategies: a case study of Metropolitan Boston USA (df8dbdfc)	article/10.1007/s10584-007-9252-5
Urban Areas	isMentionedIn	chapter nca3 chapter 14 : Rural Communities (d57129df)	report/nca3/chapter/rural
Urban Areas	isMentionedIn	Analysis of flash flood parameters and human impacts in the US from 2006 to 2012	reference/3f57831b-3c94-4ca9-863b-594a81f51b20
Building Locations	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Infrastructure	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Infrastructure	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change	reference/089d8050-f4c8-4d07-bc35-25bf61691be3
Infrastructure	isMentionedIn	Primary Protection: Enhancing Health Care Resilience for a Changing Climate	reference/05ee299b-0f67-41b4-98c8-7f06718799fc
Infrastructure	isMentionedIn	Impact of flood damaged critical infrastructure on communities and industries	reference/28cd1db6-3801-448c-8d00-6cf7e94470d3
Infrastructure	isMentionedIn	Biodiversity, climate change, and ecosystem services	reference/0f26e22b-ce22-4484-8ecf-e5dc36adc654
Infrastructure	isMentionedIn	Infrastructure interdependency and the creation of a normal disaster: The case of Hurricane Katrina and the City of New Orleans	reference/bb739352-eaf8-47ec-907f-8b895198eef9
Infrastructure	isMentionedIn	Climate Change and Infrastructure, Urban Systems, and Vulnerabilities. Technical Report for the U.S. Department of Energy in Support of the National Climate Assessment	reference/15ce66a5-76bd-4c13-8e99-4c08a44380c7
Infrastructure	isMentionedIn	Natech risk and management: An assessment of the state of the art	reference/75c3c01d-a3a3-405c-af4d-7e95fa71d61c
Infrastructure	isMentionedIn	Six climate change-related events in the United States accounted for about $14 billion in lost lives and health costs	reference/21f384a2-0dcf-4c1a-b1c0-add8b0e7506c
Infrastructure	isMentionedIn	Impact of 2003 power outages on public health and emergency response	reference/31b82903-cff5-4f29-8f21-ef6b13a0cbd2
Infrastructure	isMentionedIn	Effects of the August 2003 blackout on the New York City healthcare delivery system: A lesson for disaster preparedness	reference/08f72697-7679-499a-b211-40cc080cb5ec
Infrastructure	isMentionedIn	Impact of Citywide Blackout on an Urban Emergency Medical Services System	reference/9d80ee92-5d59-4dd5-858f-8818b9d692b4
Infrastructure	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods	reference/c4dc57e5-707f-4967-ab31-2b6e2b94fde5
Infrastructure	isMentionedIn	Ch. 3: Water Resources	reference/3ff0e30a-c5ee-4ed9-8034-288be428125b
Infrastructure	isMentionedIn	Hurricane Katrina's first responders: The struggle to protect and serve in the aftermath of the disaster	reference/895a462d-2faa-44e3-a888-31efb349f44d
Infrastructure	isMentionedIn	chapter nca3 chapter 4 : Energy Supply and Use (686dd899)	report/nca3/chapter/energy-supply-and-use
Infrastructure	isMentionedIn	chapter nca3 chapter 11 : Urban Systems, Infrastructure, and Vulnerability (5a79e12b)	report/nca3/chapter/urban-systems-infrastructure-vulnerability
Infrastructure	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Infrastructure	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Infrastructure	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Infrastructure	isMentionedIn	Tropical cyclone hazards in the USA (91c3ced0)	article/10.1111/j.1749-8198.2011.00439.x
Infrastructure	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season (c43fa066)	article/10.1007/s00484-010-0370-9
Infrastructure	isMentionedIn	Neither rain nor hail nor sleet nor snow: Provider perspectives on the challenges of weather for home and community care (53acdf32)	article/10.1016/j.socscimed.2008.11.022
Infrastructure	isMentionedIn	Lights Out (dd072932)	article/10.1097/EDE.0b013e318245c61c
Infrastructure	isMentionedIn	Health impact in New York City during the Northeastern blackout of 2003 (9a6c7a87)	article/health-impact-new-york-city-during-northeastern-blackout-2003
Infrastructure	isMentionedIn	The health impacts of windstorms: A systematic literature review (aa29148e)	article/10.1016/j.puhe.2013.09.022
Infrastructure	isMentionedIn	An outbreak of carbon monoxide poisoning after a major ice storm in Maine (ad3c4329)	article/10.1016/S0736-4679(99)00184-5
Infrastructure	isMentionedIn	A review of disaster-related carbon monoxide poisoning: Surveillance, epidemiology, and opportunities for prevention (eec8bc7b)	article/10.2105/ajph.2012.300674
Infrastructure	isMentionedIn	Carbon monoxide poisoning after an ice storm in Kentucky, 2009 (d887debf)	article/carbon-monoxide-poisoning-after-an-ice-storm-kentucky-2009
Infrastructure	isMentionedIn	Providing continuity of care for chronic diseases in the aftermath of Katrina: From field experience to policy recommendations (858d9e98)	article/10.1097/DMP.0b013e3181b66ae4
Infrastructure	isMentionedIn	Missed dialysis sessions and hospitalization in hemodialysis patients after Hurricane Katrina (692dfb63)	article/10.1038/ki.2009.5
Infrastructure	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Infrastructure	isMentionedIn	Providing shelter to nursing home evacuees in disasters: Lessons from Hurricane Katrina (81e4da11)	article/10.2105/ajph.2006.107748
Infrastructure	isMentionedIn	Health impacts of floods (60be18ee)	article/10.1017/S1049023X00008141
Infrastructure	isMentionedIn	Climate change and occupational safety and health: Establishing a preliminary framework (e3439854)	article/10.1080/15459620903066008
Infrastructure	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Infrastructure	isMentionedIn	Interdependencies of urban climate change impacts and adaptation strategies: a case study of Metropolitan Boston USA (df8dbdfc)	article/10.1007/s10584-007-9252-5
Infrastructure	isMentionedIn	Army Corps of Engineers Efforts to Assess the Impact of Extreme Weather Events (a31abb74)	report/gao-15-660
Infrastructure	isMentionedIn	Sea Level Rise and Nuisance Flood Frequency Changes around the United States (bbf3043e)	report/sea-level-rise-nuisance-flood-frequency-changes-around-united
Infrastructure	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Infrastructure	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Infrastructure	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Water Treatment	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Water Treatment	isMentionedIn	chapter nca3 chapter 4 : Energy Supply and Use (686dd899)	report/nca3/chapter/energy-supply-and-use
Water Treatment	isMentionedIn	chapter nca3 chapter 11 : Urban Systems, Infrastructure, and Vulnerability (5a79e12b)	report/nca3/chapter/urban-systems-infrastructure-vulnerability
Water Treatment	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Water Treatment	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Water Quality/ Water Quantity	isMentionedIn	A review of the potential impacts of climate change on surface water quality (f60a6281)	article/10.1623/hysj.54.1.101
Water Quality/ Water Quantity	isMentionedIn	Water quality parameters of a Nebraska reservoir differ between drought and normal conditions (54b0ebb2)	article/10.1080/07438141.2011.601401
Water Quality/ Water Quantity	isMentionedIn	Impact of summer droughts on water quality of the Rhine River - a preview of climate change? (6a9eaa35)	article/10.2166/wst.2007.535
Water Quality/ Water Quantity	isMentionedIn	Impacts of climate change on surface water quality in relation to drinking water production (8c50c794)	article/10.1016/j.envint.2009.07.001
Water Quality/ Water Quantity	isMentionedIn	Impact of summer droughts on the water quality of the Meuse river (b6607393)	article/10.1016/j.jhydrol.2008.01.001
Water Quality/ Water Quantity	isMentionedIn	Extreme water-related weather events and waterborne disease (067c087d)	article/10.1017/s0950268812001653
Water Quality/ Water Quantity	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Water Quality/ Water Quantity	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Water Quality/ Water Quantity	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Water Quality/ Water Quantity	isMentionedIn	When Every Drop Counts: Protecting Public Health During Drought Conditions�A Guide for Public Health Professionals	reference/792a6471-f6d3-4e85-bdb8-0e6efe9a24a9
Water Quality/ Water Quantity	isMentionedIn	Ch. 9: Human Health	reference/61fd6e32-63d0-4f5a-bbbb-f68262376a37
Water Quality/ Water Quantity	isMentionedIn	Effects of Wildfire on Drinking Water Utilities and Best Practices for Wildfire Risk Reduction and Mitigation	reference/0a9f1787-eafd-46c9-b7fb-037f0753f384
Water Quality/ Water Quantity	isMentionedIn	Wildfire Effects on Source-Water Quality: Lessons from Fourmile Canyon Fire, Colorado, and Implications for Drinking-Water Treatment	reference/c4867dd0-2760-43d8-9de4-169489829c28
Water Quality/ Water Quantity	isMentionedIn	Water quality effects following a severe fire	reference/1a79450e-5a3e-4eed-8f8f-09b7b16592f5
Electrical Grids	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Electrical Grids	isMentionedIn	chapter nca3 chapter 4 : Energy Supply and Use (686dd899)	report/nca3/chapter/energy-supply-and-use
Electrical Grids	isMentionedIn	chapter nca3 chapter 11 : Urban Systems, Infrastructure, and Vulnerability (5a79e12b)	report/nca3/chapter/urban-systems-infrastructure-vulnerability
Electrical Grids	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Electrical Grids	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Public Health Systems	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Public Health Systems	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Public Health Systems	isMentionedIn	Integrating climate change adaptation into public health practice: Using adaptive management to increase adaptive capacity and build resilience	reference/7f9ac45f-e1d5-4bd5-b55d-c92ef8dcbaaa
Public Health Systems	isMentionedIn	Impact of 2003 power outages on public health and emergency response	reference/31b82903-cff5-4f29-8f21-ef6b13a0cbd2
Public Health Systems	isMentionedIn	Effects of the August 2003 blackout on the New York City healthcare delivery system: A lesson for disaster preparedness	reference/08f72697-7679-499a-b211-40cc080cb5ec
Public Health Systems	isMentionedIn	Impact of Citywide Blackout on an Urban Emergency Medical Services System	reference/9d80ee92-5d59-4dd5-858f-8818b9d692b4
Public Health Systems	isMentionedIn	Demand for poison control center services “surged” during the 2003 blackout	reference/4a66e935-a734-47e5-a4ec-2e9c491a574a
Public Health Systems	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Public Health Systems	isMentionedIn	Tropical cyclone hazards in the USA (91c3ced0)	article/10.1111/j.1749-8198.2011.00439.x
Public Health Systems	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season (c43fa066)	article/10.1007/s00484-010-0370-9
Public Health Systems	isMentionedIn	Neither rain nor hail nor sleet nor snow: Provider perspectives on the challenges of weather for home and community care (53acdf32)	article/10.1016/j.socscimed.2008.11.022
Public Health Systems	isMentionedIn	Lights Out (dd072932)	article/10.1097/EDE.0b013e318245c61c
Public Health Systems	isMentionedIn	Health impact in New York City during the Northeastern blackout of 2003 (9a6c7a87)	article/health-impact-new-york-city-during-northeastern-blackout-2003
Public Health Systems	isMentionedIn	The health impacts of windstorms: A systematic literature review (aa29148e)	article/10.1016/j.puhe.2013.09.022
Public Health Systems	isMentionedIn	An outbreak of carbon monoxide poisoning after a major ice storm in Maine (ad3c4329)	article/10.1016/S0736-4679(99)00184-5
Public Health Systems	isMentionedIn	A review of disaster-related carbon monoxide poisoning: Surveillance, epidemiology, and opportunities for prevention (eec8bc7b)	article/10.2105/ajph.2012.300674
Public Health Systems	isMentionedIn	Carbon monoxide poisoning after an ice storm in Kentucky, 2009 (d887debf)	article/carbon-monoxide-poisoning-after-an-ice-storm-kentucky-2009
Public Health Systems	isMentionedIn	Providing continuity of care for chronic diseases in the aftermath of Katrina: From field experience to policy recommendations (858d9e98)	article/10.1097/DMP.0b013e3181b66ae4
Public Health Systems	isMentionedIn	Missed dialysis sessions and hospitalization in hemodialysis patients after Hurricane Katrina (692dfb63)	article/10.1038/ki.2009.5
Public Health Systems	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Public Health Systems	isMentionedIn	Providing shelter to nursing home evacuees in disasters: Lessons from Hurricane Katrina (81e4da11)	article/10.2105/ajph.2006.107748
Public Health Systems	isMentionedIn	Health impacts of floods (60be18ee)	article/10.1017/S1049023X00008141
Public Health Systems	isMentionedIn	Climate change and occupational safety and health: Establishing a preliminary framework (e3439854)	article/10.1080/15459620903066008
Public Health Systems	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Cascading Failure	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012	reference/13d048c9-77d7-4bbb-beeb-ee49842d2719
Cascading Failure	isMentionedIn	Ch. 11: Urban Systems, Infrastructure, and Vulnerability	reference/5a79e12b-b65c-40ef-8f80-7bcb04d57a1d
Cascading Failure	isMentionedIn	Infrastructure interdependency and the creation of a normal disaster: The case of Hurricane Katrina and the City of New Orleans	reference/bb739352-eaf8-47ec-907f-8b895198eef9
Cascading Failure	isMentionedIn	Climate Change and Infrastructure, Urban Systems, and Vulnerabilities. Technical Report for the U.S. Department of Energy in Support of the National Climate Assessment	reference/15ce66a5-76bd-4c13-8e99-4c08a44380c7
Cascading Failure	isMentionedIn	Six climate change-related events in the United States accounted for about $14 billion in lost lives and health costs	reference/21f384a2-0dcf-4c1a-b1c0-add8b0e7506c
Climate Indicators	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Climate Indicators	isMentionedIn	Valley fever: Finding new places for an old disease: Coccidioides immitis found in Washington State soil associated with recent human infection	reference/e43a4da1-824b-4d42-b4f5-8bf2cb571f20
Climate Indicators	isMentionedIn	chapter nca3 chapter 4 : Energy Supply and Use (686dd899)	report/nca3/chapter/energy-supply-and-use
Climate Indicators	isMentionedIn	Army Corps of Engineers Efforts to Assess the Impact of Extreme Weather Events (a31abb74)	report/gao-15-660
Climate Indicators	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Intensity	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Intensity	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Intensity	isMentionedIn	chapter nca3 chapter 4 : Energy Supply and Use (686dd899)	report/nca3/chapter/energy-supply-and-use
Intensity	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Intensity	isMentionedIn	chapter nca3 chapter 11 : Urban Systems, Infrastructure, and Vulnerability (5a79e12b)	report/nca3/chapter/urban-systems-infrastructure-vulnerability
Intensity	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Frequency	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Frequency	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Frequency	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Frequency	isMentionedIn	chapter nca3 chapter 4 : Energy Supply and Use (686dd899)	report/nca3/chapter/energy-supply-and-use
Frequency	isMentionedIn	chapter nca3 chapter 11 : Urban Systems, Infrastructure, and Vulnerability (5a79e12b)	report/nca3/chapter/urban-systems-infrastructure-vulnerability
Frequency	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
High Tide	isMentionedIn	Sea Level Rise and Nuisance Flood Frequency Changes around the United States (bbf3043e)	report/sea-level-rise-nuisance-flood-frequency-changes-around-united
High Tide	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
High Tide	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Rising Temperature	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Rising Temperature	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Duration	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Drier Summers	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Drier Summers	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Sea Level Rise	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Sea Level Rise	isMentionedIn	Sea Level Rise and Nuisance Flood Frequency Changes around the United States (bbf3043e)	report/sea-level-rise-nuisance-flood-frequency-changes-around-united
Sea Level Rise	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Trends	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Trends	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Warning	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Warning	isMentionedIn	Disaster Resilience: A National Imperative	reference/d0ca25ff-c211-4ac3-bea8-0dede9fe1a70
Warning	isMentionedIn	A place-based model for understanding community resilience to natural disasters	reference/19bc2dd3-6c09-4427-82e0-81858eda7c0e
Warning	isMentionedIn	Persons with communication disabilities in natural disasters, war, and/or conflict	reference/a8fb12df-a0fc-4d01-9be6-c8b27bb60a52
Warning	isMentionedIn	Analysis of flash flood parameters and human impacts in the US from 2006 to 2012	reference/3f57831b-3c94-4ca9-863b-594a81f51b20
Extreme Weather	isMentionedIn	A review of the potential impacts of climate change on surface water quality (f60a6281)	article/10.1623/hysj.54.1.101
Extreme Weather	isMentionedIn	Impact of flood damaged critical infrastructure on communities and industries	reference/28cd1db6-3801-448c-8d00-6cf7e94470d3
Extreme Weather	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Extreme Weather	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Extreme Weather	isMentionedIn	chapter nca3 chapter 4 : Energy Supply and Use (686dd899)	report/nca3/chapter/energy-supply-and-use
Extreme Weather	isMentionedIn	chapter nca3 chapter 11 : Urban Systems, Infrastructure, and Vulnerability (5a79e12b)	report/nca3/chapter/urban-systems-infrastructure-vulnerability
Extreme Weather	isMentionedIn	Power outages, extreme events and health: A systematic review of the literature from 2011-2012 (13d048c9)	article/10.1371/currents.dis.04eb1dc5e73dd1377e05a10e9edde673
Extreme Weather	isMentionedIn	Interdependencies of urban climate change impacts and adaptation strategies: a case study of Metropolitan Boston USA (df8dbdfc)	article/10.1007/s10584-007-9252-5
Extreme Weather	isMentionedIn	Estimated Deaths and Billion Dollar Losses from Extreme Weather Events in the U.S. 2004-2013	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/estimated-deaths-and-billion-dollar-losses-from-extreme-weather-events-in-the-us-2004-2013
Extreme Weather	isMentionedIn	webpage Weather Fatalities (a1b08f2f)	webpage/f1a61f43-0119-4163-8c7a-36e2dc787687
Extreme Weather	isMentionedIn	US billion-dollar weather and climate disasters: Data sources, trends, accuracy and biases (4fe32146)	article/10.1007/s11069-013-0566-5
Extreme Weather	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Extreme Weather	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Flooding	isMentionedIn	Climate Change: The Public Health Response (3f2402c5)	article/10.2105/AJPH.2007.119362
Flooding	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods (c4dc57e5)	article/10.3390/ijerph10127015
Flooding	isMentionedIn	chapter nca3 chapter 9 : Human Health (61fd6e32)	report/nca3/chapter/human-health
Flooding	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Flooding	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Flooding	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season (c43fa066)	article/10.1007/s00484-010-0370-9
Flooding	isMentionedIn	The health impacts of windstorms: A systematic literature review (aa29148e)	article/10.1016/j.puhe.2013.09.022
Flooding	isMentionedIn	Providing continuity of care for chronic diseases in the aftermath of Katrina: From field experience to policy recommendations (858d9e98)	article/10.1097/DMP.0b013e3181b66ae4
Flooding	isMentionedIn	Missed dialysis sessions and hospitalization in hemodialysis patients after Hurricane Katrina (692dfb63)	article/10.1038/ki.2009.5
Flooding	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Flooding	isMentionedIn	Health impacts of floods (60be18ee)	article/10.1017/S1049023X00008141
Flooding	isMentionedIn	Deaths associated with Hurricane Sandy - October-November 2012	reference/972db4a7-c717-47fc-9996-6c1a419c776e
Flooding	isMentionedIn	Service Assessment: Hurricane/Post-Tropical Cyclone Sandy, October 22–29, 2012	reference/54b7a268-2389-4bc6-b0c5-543d583c7f68
Flooding	isMentionedIn	An outbreak of carbon monoxide poisoning after a major ice storm in Maine	reference/ad3c4329-eac0-47ea-8342-be6ca602610c
Flooding	isMentionedIn	A review of disaster-related carbon monoxide poisoning: Surveillance, epidemiology, and opportunities for prevention	reference/eec8bc7b-93a6-4b99-92e7-18bf3e25bc9d
Flooding	isMentionedIn	Carbon monoxide poisoning after an ice storm in Kentucky, 2009	reference/d887debf-59d6-423b-8f0f-433b49f9c9ca
Flooding	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Flooding	isMentionedIn	Ariborne mold and endotoxin concentrations in New Orleans, Louisiana, after flooding, October through November 2005	reference/a018e131-9ae9-4a2f-9fb8-064a5190e9f3
Flooding	isMentionedIn	Analysis of flash flood parameters and human impacts in the US from 2006 to 2012	reference/3f57831b-3c94-4ca9-863b-594a81f51b20
Flooding	isMentionedIn	Impact of the Red River catastrophic flood on women giving birth in North Dakota, 1994–2000	reference/e0b99ff4-67d8-476e-a2c8-b80cfd53b498
Flooding	isMentionedIn	Exposure to Hurricane Katrina, post-traumatic stress disorder and birth outcomes	reference/515b09d9-e540-4cc5-ab3a-16fbd1d1d52d
Flooding	isMentionedIn	Children with disabilities in the context of disaster: A social vulnerability perspective	reference/65d8158c-557b-4144-9732-59d49ef5a0ee
Flooding	isMentionedIn	Operation Child-ID: Reunifying children with their legal guardians after Hurricane Katrina	reference/fb2826fe-a70d-45d4-bcb0-a45cdb3e7522
Flooding	isMentionedIn	Social Vulnerability to Disasters	reference/d283d4ed-304b-4f2f-a863-a993a6ff8e4e
Flooding	isMentionedIn	Current research issues related to post-wildfire runoff and erosion processes	reference/d73c04cf-a340-4ac0-81b8-6ec586ec106b
Flooding	isMentionedIn	Storm rainfall conditions for floods and debris flows from recently burned areas in southwestern Colorado and southern California	reference/b27bf60e-d34a-4b8f-b2e2-71ccd0839704
Flooding	isMentionedIn	The increasing wildfire and post-fire debris-flow threat in western USA, and implications for consequences of climate change	reference/17781ee0-ed89-412d-b192-ed59ee650740
Flooding	isMentionedIn	Developing a risk analysis procedure for post-wildfire mass movement and flooding in British Columbia	reference/884af7b8-8e72-498a-8b43-8362314595ae
Flooding	isMentionedIn	Managing the Risks of Extreme Events and Disasters to Advance Climate Change Adaptation. A Special Report of Working Groups I and II of the Intergovernmental Panel on Climate Change (089d8050)	report/ipcc-srex
Flooding	isMentionedIn	Sea Level Rise and Nuisance Flood Frequency Changes around the United States (bbf3043e)	report/sea-level-rise-nuisance-flood-frequency-changes-around-united
Flooding	isMentionedIn	Climate change and occupational safety and health: Establishing a preliminary framework (e3439854)	article/10.1080/15459620903066008
Flooding	isMentionedIn	Hurricane Katrina's first responders: The struggle to protect and serve in the aftermath of the disaster (895a462d)	article/10.1001/dmp.2011.53
Flooding	isMentionedIn	Estimated Deaths and Billion Dollar Losses from Extreme Weather Events in the U.S. 2004-2013	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/estimated-deaths-and-billion-dollar-losses-from-extreme-weather-events-in-the-us-2004-2013
Flooding	isMentionedIn	webpage Weather Fatalities (a1b08f2f)	webpage/f1a61f43-0119-4163-8c7a-36e2dc787687
Flooding	isMentionedIn	US billion-dollar weather and climate disasters: Data sources, trends, accuracy and biases (4fe32146)	article/10.1007/s11069-013-0566-5
Flooding	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Flooding	isMentionedIn	North Atlantic tropical cyclones and U.S. flooding	article/10.1175/bams-d-13-00060.1
Flooding	isMentionedIn	Hurricane-Induced Flood Effects in Eastern and Central United States	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/hurricane-induced-flood-effects-in-eastern-and-central-united-states
Flooding	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Flooding	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Storm Surge	isMentionedIn	Sea Level Rise and Nuisance Flood Frequency Changes around the United States (bbf3043e)	report/sea-level-rise-nuisance-flood-frequency-changes-around-united
Storm Surge	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Storm Surge	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Storm Surge	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Extreme Precipitation	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Extreme Precipitation	isMentionedIn	Climate Change: The Public Health Response (3f2402c5)	article/10.2105/AJPH.2007.119362
Extreme Precipitation	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods (c4dc57e5)	article/10.3390/ijerph10127015
Extreme Precipitation	isMentionedIn	chapter nca3 chapter 9 : Human Health (61fd6e32)	report/nca3/chapter/human-health
Extreme Precipitation	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Coastal Storms	isMentionedIn	Climate Change: The Public Health Response (3f2402c5)	article/10.2105/AJPH.2007.119362
Coastal Storms	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods (c4dc57e5)	article/10.3390/ijerph10127015
Coastal Storms	isMentionedIn	chapter nca3 chapter 9 : Human Health (61fd6e32)	report/nca3/chapter/human-health
Coastal Storms	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Coastal Storms	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Coastal Storms	isMentionedIn	Fatalities in the United States from Atlantic tropical cyclones: New data and interpretation	reference/f5411bf4-3e63-48b1-8dfa-1db41f90cf4d
Drought	isMentionedIn	A review of the potential impacts of climate change on surface water quality (f60a6281)	article/10.1623/hysj.54.1.101
Drought	isMentionedIn	When Every Drop Counts: Protecting Public Health During Drought Conditions—A Guide for Public Health Professionals	reference/792a6471-f6d3-4e85-bdb8-0e6efe9a24a9
Drought	isMentionedIn	Health effects of drought: A systematic review of the evidence	reference/cd642a0a-9d8e-4c25-a56d-a64260553be6
Drought	isMentionedIn	Ground Water in Freshwater-Saltwater Environments of the Atlantic Coast	reference/bdf736ee-bbce-4486-9add-d0718c5e22e6
Drought	isMentionedIn	Impact of Anthropogenic Development on Coastal Ground-Water Hydrology in Southeastern Florida, 1900-2000	reference/fec5847d-912a-40a2-ab9d-af741496b80c
Drought	isMentionedIn	Movement of the Saltwater Interface in the Surficial Aquifer System in Response to Hydrologic Stresses and Water-Management Practices, Broward County, Florida	reference/27df9637-d8ef-498a-8c68-45761ebca010
Drought	isMentionedIn	Ch. 9: Human Health	reference/61fd6e32-63d0-4f5a-bbbb-f68262376a37
Drought	isMentionedIn	Vulnerability of waterborne diseases to climate change in Canada: A review	reference/3b1803a8-da7d-4b78-8ea8-605336acf55b
Drought	isMentionedIn	Potential effects of global environmental changes on cryptosporidiosis and giardiasis transmission	reference/2cc8c197-bbfc-4687-a425-8536784a15a1
Drought	isMentionedIn	West Nile virus and drought	reference/52d82168-d4c8-41b0-a318-501dcefb5ff8
Drought	isMentionedIn	Drought-induced amplification of local and regional West Nile virus infection rates in New Jersey	reference/6c4943e6-2a76-4989-b80e-8b4d9bacd78a
Drought	isMentionedIn	Hydrologic conditions describe West Nile virus risk in Colorado	reference/c8b9489e-b737-4806-8685-4ebda89c8568
Drought	isMentionedIn	Inter-annual associations between precipitation and human incidence of West Nile Virus in the United States	reference/79d19ab8-4961-4f28-b678-78b213cdbdf3
Drought	isMentionedIn	Dry weather induces outbreaks of human West Nile virus infections	reference/f86c2421-ca6f-4634-822b-73de01b5168f
Drought	isMentionedIn	Hantaviruses in the Americas and their role as emerging pathogens	reference/f22cab41-537e-4eee-b11f-088052a7928e
Drought	isMentionedIn	Relating increasing hantavirus incidences to the changing climate: The mast connection	reference/e76ac40a-1b89-497e-be9c-83d7b1a636a1
Drought	isMentionedIn	Brush mouse (Peromyscus boylii) population dynamics and hantavirus infection during a warm, drought period in southern Arizona	reference/4f18488f-9d6a-475e-bc59-d46ead7dbfe7
Drought	isMentionedIn	Responses of wind erosion to climate-induced vegetation changes on the Colorado Plateau	reference/ea9e8c20-fe7c-4a4e-b628-91ac3d300fb8
Drought	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Drought	isMentionedIn	chapter nca3 chapter 20 : Southwest (99baa64e)	report/nca3/chapter/southwest
Drought	isMentionedIn	Water quality parameters of a Nebraska reservoir differ between drought and normal conditions (54b0ebb2)	article/10.1080/07438141.2011.601401
Drought	isMentionedIn	Impact of summer droughts on water quality of the Rhine River - a preview of climate change? (6a9eaa35)	article/10.2166/wst.2007.535
Drought	isMentionedIn	Impacts of climate change on surface water quality in relation to drinking water production (8c50c794)	article/10.1016/j.envint.2009.07.001
Drought	isMentionedIn	Impact of summer droughts on the water quality of the Meuse river (b6607393)	article/10.1016/j.jhydrol.2008.01.001
Drought	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Severe Thunderstorms	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Severe Thunderstorms	isMentionedIn	Nontornadic convective wind fatalities in the United States	reference/8b968b37-ed22-4ffd-95a2-d8d4c2ea5634
Severe Thunderstorms	isMentionedIn	Derecho hazards in the United States	reference/72a90ea0-20cc-43a9-bc13-dbcb51657e1d
Severe Thunderstorms	isMentionedIn	Health of the homeless and climate change	reference/6a74b0ff-705b-433e-8b26-59b7284cca88
Severe Thunderstorms	isMentionedIn	Fatal work injuries involving natural disasters, 1992–2006	reference/ce9790d9-36c1-483d-a5c8-e8f21bf4e07d
Severe Thunderstorms	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Hail	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Hail	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Tornadoes	isMentionedIn	Estimated Deaths and Billion Dollar Losses from Extreme Weather Events in the U.S. 2004-2013	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/estimated-deaths-and-billion-dollar-losses-from-extreme-weather-events-in-the-us-2004-2013
Tornadoes	isMentionedIn	webpage Weather Fatalities (a1b08f2f)	webpage/f1a61f43-0119-4163-8c7a-36e2dc787687
Tornadoes	isMentionedIn	US billion-dollar weather and climate disasters: Data sources, trends, accuracy and biases (4fe32146)	article/10.1007/s11069-013-0566-5
Tornadoes	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Tornadoes	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Tornadoes	isMentionedIn	Prevalence and predictors of PTSD and depression among adolescent victims of the Spring 2011 tornado outbreak	reference/9b8feb57-74bc-4142-8bf5-36bc349b0591
Winter Storms	isMentionedIn	Estimated Deaths and Billion Dollar Losses from Extreme Weather Events in the U.S. 2004-2013	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/estimated-deaths-and-billion-dollar-losses-from-extreme-weather-events-in-the-us-2004-2013
Winter Storms	isMentionedIn	webpage Weather Fatalities (a1b08f2f)	webpage/f1a61f43-0119-4163-8c7a-36e2dc787687
Winter Storms	isMentionedIn	US billion-dollar weather and climate disasters: Data sources, trends, accuracy and biases (4fe32146)	article/10.1007/s11069-013-0566-5
Winter Storms	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Winter Storms	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Winter Storms	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment	reference/3be13957-eae2-4796-8504-ef2597b91b09
Winter Storms	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season	reference/c43fa066-6d7b-481b-9a85-22da8c27243a
Winter Storms	isMentionedIn	The health impacts of windstorms: A systematic literature review	reference/aa29148e-c86c-443d-9c1d-5a1d7fbc3437
Winter Storms	isMentionedIn	An outbreak of carbon monoxide poisoning after a major ice storm in Maine	reference/ad3c4329-eac0-47ea-8342-be6ca602610c
Winter Storms	isMentionedIn	A review of disaster-related carbon monoxide poisoning: Surveillance, epidemiology, and opportunities for prevention	reference/eec8bc7b-93a6-4b99-92e7-18bf3e25bc9d
Winter Storms	isMentionedIn	Carbon monoxide poisoning after an ice storm in Kentucky, 2009	reference/d887debf-59d6-423b-8f0f-433b49f9c9ca
Winter Storms	isMentionedIn	Health of the homeless and climate change	reference/6a74b0ff-705b-433e-8b26-59b7284cca88
Winter Storms	isMentionedIn	Are we prepared yet for the extremes of weather changes? Emergence of several severe frostbite cases in Louisiana	reference/a9273613-8dc2-42d4-a6ff-5b9a32e5d59e
Winter Storms	isMentionedIn	Hypothermia fatalities in a temperate climate: Sydney, Australia	reference/a2d2f868-aa28-4f99-b3c0-6f5bc9c8c2fc
Winter Storms	isMentionedIn	Preventing cold-related morbidity and mortality in a changing climate	reference/33bdc93c-e333-4694-af8e-f982e9396ef8
Wind	isMentionedIn	Estimated Deaths and Billion Dollar Losses from Extreme Weather Events in the U.S. 2004-2013	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/estimated-deaths-and-billion-dollar-losses-from-extreme-weather-events-in-the-us-2004-2013
Wind	isMentionedIn	webpage Weather Fatalities (a1b08f2f)	webpage/f1a61f43-0119-4163-8c7a-36e2dc787687
Wind	isMentionedIn	US billion-dollar weather and climate disasters: Data sources, trends, accuracy and biases (4fe32146)	article/10.1007/s11069-013-0566-5
Wind	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Wind	isMentionedIn	Driving blind: Weather-related vision hazards and fatal motor vehicle crashes	reference/bc6db90e-3e83-4c12-8270-83da70318f67
Wind	isMentionedIn	Human fatalities from wind-related tree failures in the United States, 1995�2007	reference/1257d220-b58d-46fb-b7aa-7420d46b6297
Wind	isMentionedIn	Are we prepared yet for the extremes of weather changes? Emergence of several severe frostbite cases in Louisiana	reference/a9273613-8dc2-42d4-a6ff-5b9a32e5d59e
Wind	isMentionedIn	Hypothermia fatalities in a temperate climate: Sydney, Australia	reference/a2d2f868-aa28-4f99-b3c0-6f5bc9c8c2fc
Wind	isMentionedIn	Derecho hazards in the United States	reference/72a90ea0-20cc-43a9-bc13-dbcb51657e1d
Derecho			
Storms	isMentionedIn	Health effects of coastal storms and flooding in urban areas: A review and vulnerability assessment (3be13957)	article/10.1155/2013/913064
Storms	isMentionedIn	Floods and human health: A systematic review (57f88e8c)	article/10.1016/j.envint.2012.06.003
Storms	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season (c43fa066)	article/10.1007/s00484-010-0370-9
Storms	isMentionedIn	The health impacts of windstorms: A systematic literature review (aa29148e)	article/10.1016/j.puhe.2013.09.022
Storms	isMentionedIn	Providing continuity of care for chronic diseases in the aftermath of Katrina: From field experience to policy recommendations (858d9e98)	article/10.1097/DMP.0b013e3181b66ae4
Storms	isMentionedIn	Missed dialysis sessions and hospitalization in hemodialysis patients after Hurricane Katrina (692dfb63)	article/10.1038/ki.2009.5
Storms	isMentionedIn	Disaster preparedness for dialysis patients (3a569dc6)	article/10.2215/cjn.08690811
Storms	isMentionedIn	Health impacts of floods (60be18ee)	article/10.1017/S1049023X00008141
Storms	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods (c4dc57e5)	article/10.3390/ijerph10127015
Storms	isMentionedIn	Climate change and occupational safety and health: Establishing a preliminary framework (e3439854)	article/10.1080/15459620903066008
Storms	isMentionedIn	Hurricane Katrina's first responders: The struggle to protect and serve in the aftermath of the disaster (895a462d)	article/10.1001/dmp.2011.53
Hurricanes	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Hurricanes	isMentionedIn	Fatalities in the United States from Atlantic tropical cyclones: New data and interpretation	reference/f5411bf4-3e63-48b1-8dfa-1db41f90cf4d
Hurricanes	isMentionedIn	Direct and indirect mortality in Florida during the 2004 hurricane season	reference/c43fa066-6d7b-481b-9a85-22da8c27243a
Hurricanes	isMentionedIn	The health impacts of windstorms: A systematic literature review	reference/aa29148e-c86c-443d-9c1d-5a1d7fbc3437
Hurricanes	isMentionedIn	An outbreak of carbon monoxide poisoning after a major ice storm in Maine	reference/ad3c4329-eac0-47ea-8342-be6ca602610c
Hurricanes	isMentionedIn	A review of disaster-related carbon monoxide poisoning: Surveillance, epidemiology, and opportunities for prevention	reference/eec8bc7b-93a6-4b99-92e7-18bf3e25bc9d
Hurricanes	isMentionedIn	Carbon monoxide poisoning after an ice storm in Kentucky, 2009	reference/d887debf-59d6-423b-8f0f-433b49f9c9ca
Hurricanes	isMentionedIn	Climate Change: The Public Health Response (3f2402c5)	article/10.2105/AJPH.2007.119362
Hurricanes	isMentionedIn	Factors increasing vulnerability to health effects before, during and after floods (c4dc57e5)	article/10.3390/ijerph10127015
Hurricanes	isMentionedIn	chapter nca3 chapter 9 : Human Health (61fd6e32)	report/nca3/chapter/human-health
Hurricanes	isMentionedIn	Estimated Deaths and Billion Dollar Losses from Extreme Weather Events in the U.S. 2004-2013	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/estimated-deaths-and-billion-dollar-losses-from-extreme-weather-events-in-the-us-2004-2013
Hurricanes	isMentionedIn	webpage Weather Fatalities (a1b08f2f)	webpage/f1a61f43-0119-4163-8c7a-36e2dc787687
Hurricanes	isMentionedIn	US billion-dollar weather and climate disasters: Data sources, trends, accuracy and biases (4fe32146)	article/10.1007/s11069-013-0566-5
Hurricanes	isMentionedIn	Climate Change and Health--Flooding	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/climate-change-and-health-flooding
Hurricanes	isMentionedIn	North Atlantic tropical cyclones and U.S. flooding	article/10.1175/bams-d-13-00060.1
Hurricanes	isMentionedIn	Flooding associated with predecessor rain events over the Midwest United States	reference/0134b98b-b9c6-480d-9f40-b9007aa854cc
Hurricanes	isMentionedIn	Moisture transport into midlatitudes ahead of recurving tropical cyclones and its relevance in two predecessor rain events	reference/c038793a-037f-4538-96f0-630545076166
Hurricanes	isMentionedIn	Hurricane-Induced Flood Effects in Eastern and Central United States	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/hurricane-induced-flood-effects-in-eastern-and-central-united-states
Hurricanes	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Hurricanes	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
Wildfires	isMentionedIn	Climate Change Impacts in the United States: The Third National Climate Assessment (dd5b893d)	report/nca3
Wildfires	isMentionedIn	Fields and forests in flames: Vegetation smoke and human health	reference/395ba272-7543-4f62-b731-f0d0c933ae51
Wildfires	isMentionedIn	Areas of the U.S. wildland–urban interface threatened by wildfire during the 2001–2010 decade	reference/a33149d2-8676-4f12-a5d5-7e48d9dfb115
Wildfires	isMentionedIn	Wildfire hazard mapping: Exploring site conditions in eastern US wildland�urban interfaces	reference/025ed106-60c0-4e81-8ab4-f6c40083640f
Wildfires	isMentionedIn	The wildland-urban interface in the United States	reference/6a9e5620-f3ff-44cf-9de0-fda978846b8b
Wildfires	isMentionedIn	Wildfire effects on water quality in forest catchments: A review with implications for water supply	reference/0672db18-6b8a-4ab4-8b21-0f62dcdcc3e2
Wildfires	isMentionedIn	Implications of land disturbance on drinking water treatability in a changing climate: Demonstrating the need for "source water supply and protection" strategies	reference/243f4b3b-7596-469f-ac11-3610ddb033f8
Wildfires	isMentionedIn	Impact of the 2002 Canadian forest fires on particulate matter air quality in Baltimore City	reference/3bfcb39e-f3ee-4d20-8f53-77c8487599b4
Wildfires	isMentionedIn	Air quality impacts of the October 2003 southern California wildfires	reference/fa199f73-54e2-4fd7-8d1a-586ddaa46023
Wildfires	isMentionedIn	chapter nca3 chapter 9 : Human Health (61fd6e32)	report/nca3/chapter/human-health
Wildfires	isMentionedIn	chapter nca3 chapter 20 : Southwest (99baa64e)	report/nca3/chapter/southwest
Wildfires	isMentionedIn	Driving blind: Weather-related vision hazards and fatal motor vehicle crashes (bc6db90e)	article/10.1175/BAMS-D-14-00026.1
Wildfires	isMentionedIn	Woodsmoke health effects: A review (35bb9e8b)	article/10.1080/08958370600985875
Wildfires	isMentionedIn	Health impacts of fire smoke inhalation (9cdc89b2)	article/10.1080/08958370801975311
Wildfires	isMentionedIn	Birth Weight following Pregnancy during the 2003 Southern California Wildfires (d2b28363)	article/10.1289/ehp.1104515
Wildfires	isMentionedIn	Extreme air pollution events from bushfires and dust storms and their association with mortality in Sydney, Australia 1994�2007 (a31388fc)	article/10.1016/j.envres.2011.05.007
Wildfires	isMentionedIn	Time series analysis of fine particulate matter and asthma reliever dispensations in populations affected by forest fires (8a6d6f43)	article/10.1186/1476-069X-12-11
Wildfires	isMentionedIn	Three Measures of Forest Fire Smoke Exposure and Their Associations with Respiratory and Cardiovascular Health Outcomes in a Population-Based Cohort (250b4ec3)	article/10.1289/ehp.1002288
Wildfires	isMentionedIn	Measures of forest fire smoke exposure and their associations with respiratory health outcomes (3f73c3f1)	article/10.1097/ACI.0b013e328353351f
Wildfires	isMentionedIn	Communicating about smoke from wildland fire: Challenges and opportunities for managers (c8a01a08)	article/10.1007/s00267-014-0312-0
Wildfires	isMentionedIn	The hidden cost of wildfires: Economic valuation of health effects of wildfire smoke exposure in Southern California (4ee18e43)	article/10.1016/j.jfe.2011.05.002
Wildfires	isMentionedIn	Smoke-impacted regional haze in California during the summer of 2002 (d0bcbc01)	article/10.1016/j.agrformet.2006.01.011
Wildfires	isMentionedIn	Non-accidental health impacts of wildfire smoke (bf639de9)	article/10.3390/ijerph111111772
Wildfires	isMentionedIn	Particle size-dependent radical generation from wildland fire smoke (107c077e)	article/10.1016/j.tox.2007.04.008
Wildfires	isMentionedIn	Medical events during the 2009 Los Angeles County Station fire: Lessons for wildfire EMS planning (064a28ed)	article/10.3109/10903127.2011.598607
Wildfires	isMentionedIn	A screening-level assessment of the health risks of chronic smoke exposure for wildland firefighters (a1fb85fd)	article/10.1080/15459620490442500
Wildfires	isMentionedIn	Projected Increases in Very Large Fires	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/figure/projected-increases-in-very-large-fires
Wildfires	isMentionedIn	Climate change presents increased potential for very large fires in the contiguous United States (ca5c4b38)	article/10.1071/WF15083
Wildfires	isMentionedIn	Health Impacts of Extreme Events	report/usgcrp-climate-human-health-assessment-2016/chapter/extreme-events/table/health-impacts-extreme-events
