#!perl -w
use feature qw/ say /;
use Data::Dumper;
use JSON;
$F1 = "C:\\temp\\xyzzy.json";
open (IN,"<",$F1) || die "Choke on open $F1:$!\n";
$data=(<IN>);
#!/usr/bin/perl


my $obj = from_json( $data );
my @names;
my @ids;

say Dumper $obj;
# $obj is an anonymous hash with one key, 'items'

my @items = @{ $obj->{'items'} };
# The value of the key 'items' is an anonymous array.
# Here for simplicity we copy it into a new array.
# We access it by deferencing it using @{  }

foreach my $item ( @items ) { 
  # Each element of the anonymous array is a hashref.
  # So $item is a hashref, not a scalar
  my $name = $item->{'name'};
  my $id   = $item->{'name'};

  push @names, $name;
  push @ids,   $id;
}

say 'Names: ' . join ', ', @names;
say 'IDs: ' . join ', ', @ids;

__END__
