$Num=2280;
while(<DATA>){
	chomp;
	$In=$_;
	print"mv $In \t $Num" . "_$In\n";
	$Num+=10;
}
#load-term
#load relationship
#load cmap
#load term-map
#load term-map-crt
#load term-map-GCIS

__DATA__
2270_VB-term.sql
2280_VB-load-rship.sql
2290_VB-load-cmap.sql
2300_VB-load-term-map.sql
2310_VB-load-term-map-crt.sql
2320_VB-load-term-map-gcis.sql
2330_WI-term.sql
2340_WI-load-cmap.sql
2350_WI-load-term-map.sql
2360_WI-load-term-map-crt.sql
2370_WI-load-term-map-gcis.sql
2380_WI-Descriptions.sql
