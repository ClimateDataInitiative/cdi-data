<?php
$date=date_create("",timezone_open("America/New_York"));
$DTG2= date_format($date,"ymd_His");
$DTG1= date_format($date,"ymd");

$Rep1 = strtoupper(isset($_GET["rep"]) ? $_GET["rep"] : "ALL");


$LogFileName= "/home/content/w/i/n/wincingdevil/html/CDI/CombinedLog.txt";
$TempFileName = "/home/content/w/i/n/wincingdevil/tmp/$DTG2.log";
if ($Rep1 == "ALL" ) {$Doit = "/usr/bin/tail -256 $LogFileName>$TempFileName";}
if ($Rep1 == "DTG" ) {$Doit = "/bin/grep \"^$DTG1\" $LogFileName>$TempFileName";}
if ($Rep1 == "USER" ) {$Doit = "/bin/grep -i user $LogFileName>$TempFileName";}
if ($Rep1 == "NM" ) {$Doit = "/bin/grep -v \"169.154.128.90\" $LogFileName>$TempFileName";}
if ($Rep1 == "MAY" ) {$Doit = "/bin/grep \"^1605\" $LogFileName>$TempFileName";}

print $Doit;
// exit;
system ($Doit);
$LogFile = fopen($TempFileName,"r");

$MaxLen = 45;
print<<<EOM
<!doctype html>
<html lang="en">
<head>
  <title>Log $DTG2</title>
  <meta charset="UTF-8">
  <meta name="Author" content="Vince Wilding">
  <meta name="Keywords" content="HOA, Condo Association, Ellicott City, Gatherings at Ellicott Mills, G@EM Home">
  <meta name="Description" content="Access Log, Gatherings at Ellicott Mills">
</head>
<h1>Access Log as of $DTG2</h1>
<table border=1><thead><th>DTG</th><th>Page</th><th>IP</th><th>Hostname</th><th>Ref</th></thead>
EOM;
$hostname=".";
while(! feof($LogFile)) {
	$InLine = fgets($LogFile);
	list($DTG, $Page, $Ref, $IP, $Browser) = explode("\t", $InLine);
	if ($DTG != "") {
	if (($Ref != "?") && ($Ref != "")) {
		$Ref1 = $Ref;		
		$Len1= strlen($Ref1);
		if ($Len1 > $MaxLen) {
			$Ref1 = substr($Ref,0,$MaxLen) . "...";
		}
		$Ref = "<a href=\"$Ref\">$Ref1</a>"; 
	}
	if ($Ref == "?") {$Ref = "&nbsp";}
	$HostOut = "";
	if (1) { // ( ($IP != "169.154.128.90") && ($IP != "198.119.56.43") ) {  // && ($IP != "169.154.128.90")) {
		if ($IP != "") {
			$NewHost = "";
			$X=0;
			if ($IParr[$IP] == "") {
				$IParr[$IP] = gethostbyaddr($IP); // need to cull redundant entries
				$NewHost=" *";
			} 
			$HostOut .= $IParr[$IP] . $NewHost;
		}
		print<<<EOM
<tr>
<td>$DTG</td>
<td>$Page</td>
<td>$IP</td>
<td>$HostOut</td>
<td><font face=courier>$Ref</font></td>
</tr>
EOM;
	}
}
}
print<<<EOM
</table>
<hr>
<a name="bottom">$DTG2</a>
<hr>
EOM;

fclose ($LogFile);
?>
