\o spool.txt
\! echo make sure that you do a hypnotoad -s ~/gcis/bin/tuba to stop the server
\connect postgres
DROP DATABASE gcis;
CREATE DATABASE gcis WITH TEMPLATE = template0 ENCODING = 'SQL_ASCII' LC_COLLATE = 'C' LC_CTYPE = 'C';
ALTER DATABASE gcis OWNER TO postgres;
\connect gcis
\i GCIS_Latest_Dump.txt
\i 2190_context_relationship_term.sql
insert into lexicon values ('cdi', 'Climate Data Initiative');
insert into lexicon values ('concept-map', 'Concept Map');
insert into lexicon values ('mesh', 'MeSH');
insert into context (lexicon_identifier, identifier) values ('cdi', 'health');
insert into context (lexicon_identifier, identifier) values ('mesh', 'resource');
insert into context (lexicon_identifier, identifier) values ('concept-map', 'vectorBorneDisease');
insert into context (lexicon_identifier, identifier) values ('concept-map', 'foodSafety');
insert into context (lexicon_identifier, identifier) values ('concept-map', 'waterIllness');
insert into context (lexicon_identifier, identifier) values ('concept-map', 'airQuality');
\! echo -- -- -- Here is VB -- -- --
\! echo load-term
\i VB-term.sql
\! echo load relationship
\i VB-load-rship.sql
\! echo load cmap
\i VB-load-cmap.sql
\! echo load term-map
\i VB-load-term-map.sql 
\! echo load term-map-crt
\i VB-load-term-map-crt.sql
\! echo load term-map-GCIS
\i VB-load-term-map-gcis.sql
\! echo -- -- Here is Water Illness -- -- --
\! echo load-term
\i WI-term.sql
\! echo load cmap
\i WI-load-cmap.sql
\! echo load term-map
\i WI-load-term-map.sql 
\! echo load term-map-crt
\i WI-load-term-map-crt.sql
\! echo load term-map-GCIS
\i WI-load-term-map-gcis.sql
\! echo Following must be LAST file loaded
\i 2200_convert_uuid_to_varchar.sql
\o

