INSERT INTO relationship (relationship) VALUES ('isDeterminedBy');
INSERT INTO relationship (relationship) VALUES ('isDoneFor');
INSERT INTO relationship (relationship) VALUES ('isInfluencedBy');
INSERT INTO relationship (relationship) VALUES ('isResultOf');
INSERT INTO relationship (relationship) VALUES ('skos:narrower');
INSERT INTO relationship (relationship) VALUES ('isMentionedIn');
INSERT INTO relationship (relationship) VALUES ('hasAnalysisTool');
INSERT INTO relationship (relationship) VALUES ('hasCaseStudy');
INSERT INTO relationship (relationship) VALUES ('N/A');

